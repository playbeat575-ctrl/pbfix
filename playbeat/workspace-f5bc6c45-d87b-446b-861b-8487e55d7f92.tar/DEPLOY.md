# 🚀 Deploying Playbeat.Digital to Vercel

> **🪟 On Windows?** See **[DEPLOY-WINDOWS.md](./DEPLOY-WINDOWS.md)** instead — it's a no-command-line guide using GitHub Desktop. The Vercel build now auto-creates tables and seeds data, so you don't need to run any local database commands.


This guide takes you from this sandbox app to a live, HTTPS-secured site at `playbeat.digital` (or your `*.vercel.app` preview URL) in about **15 minutes**.

---

## ⚠️ Why we need a database change

This app currently uses **SQLite** (a local file at `db/custom.db`). That's perfect for the sandbox, but **Vercel's filesystem is read-only/ephemeral** — a SQLite file gets wiped on every cold start. So for production we switch to **PostgreSQL** hosted free on **Neon** (or Supabase).

The switch is one command thanks to the helper script included here.

---

## ✅ Prerequisites

- A **GitHub** account (free) — [github.com](https://github.com)
- A **Vercel** account (free, sign in with GitHub) — [vercel.com](https://vercel.com)
- A **Neon** account (free, sign in with GitHub) — [neon.tech](https://neon.tech)
- **Git** installed on your computer — [git-scm.com](https://git-scm.com)

That's it. No credit card required for any of the free tiers.

---

## 📋 Step-by-step

### Step 1 — Create a free PostgreSQL database on Neon

1. Go to **[neon.tech](https://neon.tech)** → Sign up with GitHub
2. Click **"New Project"** → name it `playbeat` → region: closest to your users (e.g. `AWS Asia Southeast (Singapore)` for Pakistan)
3. On the project dashboard, click **"Connection string"** → copy it. It looks like:
   ```
   postgresql://playbeat_owner:npg_xxxxxxx@ep-xxxxx-pooler.ap-southeast-1.aws.neon.tech/playbeat?sslmode=require
   ```
4. **Save this string** — you'll paste it into Vercel in Step 4.

> 💡 Neon's free tier: 0.5 GB storage, unlimited projects, autoscaling to zero. Perfect for this admin panel.

---

### Step 2 — Download your code from this sandbox

This sandbox is a dev environment. You need the code on your own computer to push it to GitHub.

**Option A — Clone via git** (if you've connected this sandbox to a git remote):
```bash
git clone https://github.com/YOUR_USERNAME/playbeat-admin.git
cd playbeat-admin
```

**Option B — Copy files manually**: Download the project folder as a ZIP from your sandbox UI, extract it on your computer, then:
```bash
cd path/to/playbeat-admin
git init
git add -A
git commit -m "Playbeat.Digital admin panel — initial commit"
git branch -M main
```

---

### Step 3 — Switch the database to PostgreSQL

From your project root on your computer:
```bash
bun install                      # install dependencies (or npm install)
bun scripts/switch-db.sh prod    # switch Prisma from SQLite → PostgreSQL
```
This updates `prisma/schema.prisma` to use `provider = "postgresql"`. (To switch back to SQLite for local dev later, run `bun scripts/switch-db.sh dev`.)

Now create the tables in your Neon database and seed them:
```bash
# Create a .env file with your Neon connection string
echo 'DATABASE_URL="postgresql://playbeat_owner:npg_xxx@ep-xxxxx.neon.tech/playbeat?sslmode=require"' > .env

bun run db:push     # creates all 15 tables in Postgres
bun run db:seed     # loads 38 products, 120 orders, 48 customers, etc.
```
Verify on the Neon dashboard → **Tables** that you can see `Product`, `Order`, `Customer`, etc.

> 💡 To run the app locally against Postgres: `bun run dev` → open `http://localhost:3000`. Everything should work exactly like the sandbox, now backed by Postgres.

---

### Step 4 — Push to GitHub

Create an empty repo on GitHub first (don't add a README): **[github.com/new](https://github.com/new)** — name it `playbeat-admin`.

Then:
```bash
git remote add origin https://github.com/YOUR_USERNAME/playbeat-admin.git
git push -u origin main
```

> 🔒 Your `.env` and `db/custom.db` are already in `.gitignore`, so secrets and the dev database never get pushed.

---

### Step 5 — Deploy on Vercel

1. Go to **[vercel.com/new](https://vercel.com/new)**
2. Click **"Import Git Repository"** → find `playbeat-admin` → **Import**
3. Vercel auto-detects Next.js. Leave the defaults:
   - Framework Preset: **Next.js**
   - Build Command: `prisma generate && next build` (from `vercel.json`)
   - Install Command: `bun install`
4. **Open "Environment Variables"** and add:
   | Name | Value |
   |------|-------|
   | `DATABASE_URL` | *(paste your Neon connection string from Step 1)* |
5. Click **Deploy** ⚡

Vercel will build (~2–3 min) and give you a live URL like:
```
https://playbeat-admin-xxxxx.vercel.app
```
Open it — your admin panel is now live on the internet! 🎉

Every future `git push` to `main` auto-deploys.

---

### Step 6 — Connect your custom domain (`playbeat.digital`)

1. In Vercel: **Project → Settings → Domains → Add** → enter `playbeat.digital`
2. Vercel shows you DNS records to add. Go to your **domain registrar** (where you bought `playbeat.digital` — e.g. Namecheap, GoDaddy, Cloudflare):
   - Add an **A record**: `@ → 76.76.21.21` (Vercel's IP)
   - Add a **CNAME record**: `www → cname.vercel-dns.com`
3. Wait 5–30 min for DNS to propagate. Vercel automatically provisions a **free SSL certificate** (Let's Encrypt).
4. Visit `https://playbeat.digital` — it's live! 🔒

---

## 🛠 Common operations after deploy

### Re-seed the production database
If you ever want to reset the demo data:
```bash
# On your computer, with .env pointing to the Neon prod DB
bun run db:push --accept-data-loss   # wipes & recreates tables
bun run db:seed                      # reloads demo data
```

### Add environment variables for payment gateways
When you're ready to integrate live payments, add these in **Vercel → Settings → Environment Variables**:
```
STRIPE_SECRET_KEY=sk_live_...
STRIPE_PUBLISHABLE_KEY=pk_live_...
PAYPAL_CLIENT_ID=...
JAZZCASH_MERCHANT_ID=...
EASYPAISA_MERCHANT_ID=...
NEXTAUTH_SECRET=<run: openssl rand -base64 32>
```
Then redeploy (push any commit, or click "Redeploy" in Vercel).

### View production logs
**Vercel → Project → Logs** — see real-time request logs, errors, and build output.

---

## 🆘 Troubleshooting

| Problem | Fix |
|---------|-----|
| **Build fails: "Prisma can't reach database"** | Make sure `DATABASE_URL` is set in Vercel env vars (not just `.env`). Re-deploy after adding. |
| **Build fails: "prisma generate not found"** | The `postinstall` script in `package.json` handles this. If it still fails, the `vercel.json` `buildCommand` also runs `prisma generate`. |
| **Runtime error: "PrismaClientInitializationError"** | Your Neon DB is paused (free tier autoscales to zero). Visit the Neon dashboard to wake it, or upgrade to always-on. |
| **Page loads but no data** | You forgot to run `bun run db:seed` against the prod DB. See "Re-seed" above. |
| **"Type error" during build** | `next.config.ts` has `typescript.ignoreBuildErrors: true` so this shouldn't block. If it does, run `bun run lint` locally and fix. |
| **Custom domain not working** | DNS propagation can take up to 24h. Check `https://dnschecker.org` for your domain. |
| **Want to switch back to SQLite locally** | Run `bun scripts/switch-db.sh dev` |

---

## 📦 What's included in this repo for deployment

| File | Purpose |
|------|---------|
| `.gitignore` | Excludes `node_modules`, `.env`, `db/*.db`, `.next/`, logs |
| `.env.example` | Documents all env vars you need |
| `vercel.json` | Tells Vercel to run `prisma generate` before building |
| `package.json` `postinstall` | Auto-regenerates Prisma client on every install (Vercel needs this) |
| `prisma/schema.prisma` | Current schema (SQLite for sandbox) |
| `prisma/schema.prod.prisma` | Same schema but `provider = "postgresql"` for production |
| `scripts/switch-db.sh` | One-command switch between SQLite ↔ Postgres |
| `DEPLOY.md` | This file |

---

## 🎯 TL;DR — fastest path

```bash
# On your computer:
bun install
bun scripts/switch-db.sh prod
echo 'DATABASE_URL="postgresql://...neon.tech/playbeat?sslmode=require"' > .env
bun run db:push && bun run db:seed

# Push to GitHub:
git init && git add -A && git commit -m "init" && git branch -M main
git remote add origin https://github.com/YOU/playbeat-admin.git
git push -u origin main

# Then on vercel.com/new → import repo → add DATABASE_URL env var → Deploy ✅
```

You're live in ~10 minutes. 🚀
