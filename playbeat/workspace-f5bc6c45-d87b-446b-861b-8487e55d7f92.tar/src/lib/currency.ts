// Playbeat.Digital — Currency utility
// Default local currency is PKR (Pakistani Rupee), region: Pakistan.
// Prices stored in DB are in PKR.

export const CURRENCY_CODE = 'PKR'
export const CURRENCY_SYMBOL = 'Rs'
export const DEFAULT_REGION = 'Pakistan'
export const DEFAULT_TIMEZONE = 'Asia/Karachi'

/** Format a number as PKR, e.g. formatPKR(14500) => "Rs 14,500" */
export function formatPKR(amount: number | string | undefined | null, opts?: { decimals?: boolean }): string {
  const n = typeof amount === 'number' ? amount : parseFloat(String(amount ?? '0'))
  if (isNaN(n) || !isFinite(n)) return `${CURRENCY_SYMBOL} 0`
  const decimals = opts?.decimals ? 2 : 0
  const formatted = n.toLocaleString('en-PK', {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  })
  return `${CURRENCY_SYMBOL} ${formatted}`
}

/** Compact format for large numbers, e.g. formatPKRCompact(1450000) => "Rs 1.45M" */
export function formatPKRCompact(amount: number | string | undefined | null): string {
  const n = typeof amount === 'number' ? amount : parseFloat(String(amount ?? '0'))
  if (isNaN(n) || !isFinite(n)) return `${CURRENCY_SYMBOL} 0`
  if (n >= 1_000_000) return `${CURRENCY_SYMBOL} ${(n / 1_000_000).toFixed(2)}M`
  if (n >= 1_000) return `${CURRENCY_SYMBOL} ${(n / 1_000).toFixed(1)}k`
  return `${CURRENCY_SYMBOL} ${n.toFixed(0)}`
}
