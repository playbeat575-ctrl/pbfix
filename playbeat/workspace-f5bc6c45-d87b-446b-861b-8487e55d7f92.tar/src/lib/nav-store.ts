import { create } from 'zustand'

export type ViewKey =
  | 'dashboard'
  | 'products'
  | 'homepage'
  | 'orders'
  | 'customers'
  | 'payments'
  | 'inventory'
  | 'marketing'
  | 'reports'
  | 'users'
  | 'security'
  | 'settings'

interface NavState {
  view: ViewKey
  setView: (v: ViewKey) => void
  sidebarCollapsed: boolean
  toggleSidebar: () => void
  setSidebarCollapsed: (v: boolean) => void
  mobileSidebarOpen: boolean
  setMobileSidebarOpen: (v: boolean) => void
  commandOpen: boolean
  setCommandOpen: (v: boolean) => void
  // optional sub-context (e.g. open product editor with id)
  contextId: string | null
  setContextId: (id: string | null) => void
  globalSearch: string
  setGlobalSearch: (s: string) => void
}

export const useNav = create<NavState>((set) => ({
  view: 'dashboard',
  setView: (view) => set({ view, contextId: null }),
  sidebarCollapsed: false,
  toggleSidebar: () => set((s) => ({ sidebarCollapsed: !s.sidebarCollapsed })),
  setSidebarCollapsed: (sidebarCollapsed) => set({ sidebarCollapsed }),
  mobileSidebarOpen: false,
  setMobileSidebarOpen: (mobileSidebarOpen) => set({ mobileSidebarOpen }),
  commandOpen: false,
  setCommandOpen: (commandOpen) => set({ commandOpen }),
  contextId: null,
  setContextId: (contextId) => set({ contextId }),
  globalSearch: '',
  setGlobalSearch: (globalSearch) => set({ globalSearch }),
}))

export const VIEW_META: Record<ViewKey, { label: string; group: string }> = {
  dashboard: { label: 'Dashboard', group: 'Overview' },
  products: { label: 'Products', group: 'Catalog' },
  homepage: { label: 'Homepage Builder', group: 'Catalog' },
  orders: { label: 'Orders', group: 'Sales' },
  customers: { label: 'Customers', group: 'Sales' },
  payments: { label: 'Payments', group: 'Sales' },
  inventory: { label: 'Inventory', group: 'Operations' },
  marketing: { label: 'Marketing', group: 'Operations' },
  reports: { label: 'Reports', group: 'Insights' },
  users: { label: 'User Roles', group: 'System' },
  security: { label: 'Security', group: 'System' },
  settings: { label: 'Settings', group: 'System' },
}
