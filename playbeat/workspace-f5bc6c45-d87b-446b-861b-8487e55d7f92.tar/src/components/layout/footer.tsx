'use client'

import { Gamepad2, Heart, Github, Twitter, Linkedin } from 'lucide-react'
import { useNav } from '@/lib/nav-store'

export function Footer() {
  const { setView } = useNav()
  return (
    <footer className="mt-auto border-t border-border pb-glass">
      <div className="flex flex-col items-center justify-between gap-4 px-6 py-5 sm:flex-row">
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <div className="flex h-7 w-7 items-center justify-center rounded-lg pb-gradient-brand text-white">
            <Gamepad2 className="h-4 w-4" />
          </div>
          <span>© {new Date().getFullYear()} <span className="font-semibold pb-gradient-text">Playbeat.Digital</span>. All rights reserved.</span>
        </div>

        <nav className="flex flex-wrap items-center justify-center gap-x-5 gap-y-2 text-sm">
          {['Dashboard', 'Products', 'Orders', 'Reports', 'Settings'].map((l) => {
            const key = l.toLowerCase() as any
            return (
              <button key={l} onClick={() => setView(key === 'products' ? 'products' : key === 'orders' ? 'orders' : key === 'reports' ? 'reports' : key === 'settings' ? 'settings' : 'dashboard')} className="text-muted-foreground transition hover:text-primary">
                {l}
              </button>
            )
          })}
        </nav>

        <div className="flex items-center gap-3">
          <a href="#" className="text-muted-foreground transition hover:text-primary" aria-label="Twitter"><Twitter className="h-4 w-4" /></a>
          <a href="#" className="text-muted-foreground transition hover:text-primary" aria-label="GitHub"><Github className="h-4 w-4" /></a>
          <a href="#" className="text-muted-foreground transition hover:text-primary" aria-label="LinkedIn"><Linkedin className="h-4 w-4" /></a>
          <span className="ml-2 hidden items-center gap-1 text-xs text-muted-foreground sm:flex">
            Made with <Heart className="h-3 w-3 fill-red-500 text-red-500" /> for digital sellers
          </span>
        </div>
      </div>
    </footer>
  )
}
