'use client'

import { useNav, VIEW_META } from '@/lib/nav-store'
import { useTheme } from 'next-themes'
import { useEffect, useState } from 'react'
import {
  Menu, Search, Bell, Sun, Moon, Command, ChevronRight, Check, LogOut, UserCircle, Settings as SettingsIcon, Wallet,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { ScrollArea } from '@/components/ui/scroll-area'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { cn } from '@/lib/utils'
import { motion } from 'framer-motion'

type Notif = { id: string; title: string; message: string; type: string; read: boolean; createdAt: string }

const NOTIF_ICON: Record<string, string> = {
  success: '✅', warning: '⚠️', error: '⛔', info: 'ℹ️',
}

export function Header() {
  const { view, setMobileSidebarOpen, setCommandOpen, setView } = useNav()
  const { theme, setTheme } = useTheme()
  const [mounted, setMounted] = useState(false)
  const qc = useQueryClient()
  // Canonical next-themes mounted gate to avoid hydration mismatch.
  // eslint-disable-next-line react-hooks/set-state-in-effect
  useEffect(() => setMounted(true), [])

  const meta = VIEW_META[view]

  const { data: notifData } = useQuery<{ notifications: Notif[] }>({
    queryKey: ['notifications'],
    queryFn: () => fetch('/api/notifications').then((r) => r.json()),
  })
  const notifications = notifData?.notifications || []
  const unread = notifications.filter((n) => !n.read).length

  const markAll = useMutation({
    mutationFn: () => fetch('/api/notifications', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ markAllRead: true }) }).then((r) => r.json()),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['notifications'] }),
  })

  return (
    <header className="sticky top-0 z-30 border-b border-border pb-glass">
      <div className="flex h-16 items-center gap-3 px-4 sm:px-6">
        {/* Mobile menu */}
        <Button variant="ghost" size="icon" className="lg:hidden" onClick={() => setMobileSidebarOpen(true)}>
          <Menu className="h-5 w-5" />
        </Button>

        {/* Breadcrumb */}
        <nav className="hidden items-center gap-1.5 text-sm sm:flex">
          <span className="text-muted-foreground">{meta.group}</span>
          <ChevronRight className="h-3.5 w-3.5 text-muted-foreground/60" />
          <span className="font-semibold text-foreground">{meta.label}</span>
        </nav>

        {/* Search (desktop) */}
        <div className="relative ml-auto hidden max-w-md flex-1 md:block">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Search products, orders, customers..."
            className="h-9 rounded-xl border-border bg-background/60 pl-9 pr-16 text-sm"
            onFocus={() => setCommandOpen(true)}
            readOnly
          />
          <kbd className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 rounded bg-muted px-1.5 py-0.5 text-[10px] font-semibold">⌘K</kbd>
        </div>

        <div className="ml-auto flex items-center gap-1.5 md:ml-3">
          {/* Command trigger (mobile) */}
          <Button variant="ghost" size="icon" className="md:hidden" onClick={() => setCommandOpen(true)}>
            <Search className="h-5 w-5" />
          </Button>

          {/* Theme toggle */}
          <Button variant="ghost" size="icon" onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')} aria-label="Toggle theme">
            {mounted && theme === 'dark' ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
          </Button>

          {/* Notifications */}
          <Popover>
            <PopoverTrigger asChild>
              <Button variant="ghost" size="icon" className="relative" aria-label="Notifications">
                <Bell className="h-5 w-5" />
                {unread > 0 && (
                  <span className="absolute -right-0.5 -top-0.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-primary px-1 text-[9px] font-bold text-primary-foreground">
                    {unread}
                  </span>
                )}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-80 p-0" align="end">
              <div className="flex items-center justify-between border-b px-4 py-3">
                <p className="text-sm font-semibold">Notifications</p>
                <button onClick={() => markAll.mutate()} className="text-xs font-medium text-primary hover:underline">
                  Mark all read
                </button>
              </div>
              <ScrollArea className="h-80">
                <div className="divide-y">
                  {notifications.length === 0 && (
                    <p className="p-6 text-center text-sm text-muted-foreground">No notifications</p>
                  )}
                  {notifications.map((n) => (
                    <div key={n.id} className={cn('flex gap-3 px-4 py-3 transition hover:bg-accent/50', !n.read && 'bg-primary/5')}>
                      <span className="text-lg">{NOTIF_ICON[n.type] || '🔔'}</span>
                      <div className="min-w-0 flex-1">
                        <p className="text-sm font-semibold leading-tight">{n.title}</p>
                        <p className="mt-0.5 line-clamp-2 text-xs text-muted-foreground">{n.message}</p>
                        <p className="mt-1 text-[10px] text-muted-foreground/70">{timeAgo(n.createdAt)}</p>
                      </div>
                      {!n.read && <span className="mt-1 h-2 w-2 shrink-0 rounded-full bg-primary" />}
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </PopoverContent>
          </Popover>

          <div className="mx-1 hidden h-6 w-px bg-border sm:block" />

          {/* Profile */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button className="flex items-center gap-2 rounded-xl px-1.5 py-1 transition hover:bg-accent">
                <Avatar className="h-8 w-8 ring-2 ring-primary/20">
                  <AvatarImage src="https://i.pravatar.cc/150?u=daniyal@playbeat.digital" />
                  <AvatarFallback className="pb-gradient-brand text-xs font-bold text-white">DS</AvatarFallback>
                </Avatar>
                <div className="hidden text-left sm:block">
                  <p className="text-xs font-semibold leading-tight">Daniyal S.</p>
                  <p className="text-[10px] text-muted-foreground">Super Admin</p>
                </div>
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-56">
              <DropdownMenuLabel>
                <div className="flex flex-col">
                  <span className="text-sm font-semibold">Daniyal Sheikh</span>
                  <span className="text-xs font-normal text-muted-foreground">daniyal@playbeat.digital</span>
                </div>
              </DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => setView('settings')}>
                <UserCircle className="mr-2 h-4 w-4" /> My Profile
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setView('settings')}>
                <Wallet className="mr-2 h-4 w-4" /> Wallet & Billing
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setView('settings')}>
                <SettingsIcon className="mr-2 h-4 w-4" /> Settings
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem className="text-red-600 focus:text-red-600">
                <LogOut className="mr-2 h-4 w-4" /> Sign Out
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </header>
  )
}

function timeAgo(d: string) {
  const diff = Date.now() - new Date(d).getTime()
  const m = Math.floor(diff / 60000)
  if (m < 1) return 'just now'
  if (m < 60) return `${m}m ago`
  const h = Math.floor(m / 60)
  if (h < 24) return `${h}h ago`
  return `${Math.floor(h / 24)}d ago`
}
