'use client'

import { useNav, type ViewKey } from '@/lib/nav-store'
import { CommandDialog, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList, CommandSeparator } from '@/components/ui/command'
import {
  LayoutDashboard, Package, LayoutTemplate, ShoppingCart, Users, CreditCard, Boxes, Megaphone,
  BarChart3, ShieldCheck, Settings, UserCog, Gamepad2, Gift, Bot, Film, Cloud, Coins,
} from 'lucide-react'

const NAV: { key: ViewKey; label: string; icon: any; desc: string }[] = [
  { key: 'dashboard', label: 'Dashboard', icon: LayoutDashboard, desc: 'View live statistics & analytics' },
  { key: 'products', label: 'Products', icon: Package, desc: 'Manage your digital catalog' },
  { key: 'homepage', label: 'Homepage Builder', icon: LayoutTemplate, desc: 'Drag-and-drop storefront editor' },
  { key: 'orders', label: 'Orders', icon: ShoppingCart, desc: 'Process and fulfill orders' },
  { key: 'customers', label: 'Customers', icon: Users, desc: 'Customer profiles & history' },
  { key: 'payments', label: 'Payments', icon: CreditCard, desc: 'Gateways & transactions' },
  { key: 'inventory', label: 'Inventory', icon: Boxes, desc: 'Stock & license keys' },
  { key: 'marketing', label: 'Marketing', icon: Megaphone, desc: 'Coupons, campaigns & loyalty' },
  { key: 'reports', label: 'Reports', icon: BarChart3, desc: 'Revenue & sales reports' },
  { key: 'users', label: 'User Roles', icon: UserCog, desc: 'Role-based permissions' },
  { key: 'security', label: 'Security', icon: ShieldCheck, desc: 'Audit logs & sessions' },
  { key: 'settings', label: 'Settings', icon: Settings, desc: 'General configuration' },
]

const QUICK = [
  { label: 'Add new product', icon: Package, view: 'products' as ViewKey },
  { label: 'Create coupon', icon: Gift, view: 'marketing' as ViewKey },
  { label: 'View pending orders', icon: ShoppingCart, view: 'orders' as ViewKey },
  { label: 'Export sales report', icon: BarChart3, view: 'reports' as ViewKey },
  { label: 'Manage AI Tools', icon: Bot, view: 'products' as ViewKey },
  { label: 'Game Top-Ups', icon: Coins, view: 'products' as ViewKey },
]

export function CommandPalette() {
  const { commandOpen, setCommandOpen, setView } = useNav()

  const go = (v: ViewKey) => {
    setView(v)
    setCommandOpen(false)
  }

  return (
    <CommandDialog open={commandOpen} onOpenChange={setCommandOpen}>
      <CommandInput placeholder="Search modules, actions, products..." />
      <CommandList className="pb-scroll">
        <CommandEmpty>No results found.</CommandEmpty>
        <CommandGroup heading="Navigation">
          {NAV.map((n) => (
            <CommandItem key={n.key} value={`${n.label} ${n.desc}`} onSelect={() => go(n.key)}>
              <n.icon className="mr-2 h-4 w-4 text-primary" />
              <div className="flex flex-col">
                <span>{n.label}</span>
                <span className="text-xs text-muted-foreground">{n.desc}</span>
              </div>
            </CommandItem>
          ))}
        </CommandGroup>
        <CommandSeparator />
        <CommandGroup heading="Quick Actions">
          {QUICK.map((q) => (
            <CommandItem key={q.label} value={q.label} onSelect={() => go(q.view)}>
              <q.icon className="mr-2 h-4 w-4 text-orange-500" />
              <span>{q.label}</span>
            </CommandItem>
          ))}
        </CommandGroup>
        <CommandSeparator />
        <CommandGroup heading="Product Types">
          {[
            { label: 'Games', icon: Gamepad2 },
            { label: 'Gift Cards', icon: Gift },
            { label: 'AI Tools', icon: Bot },
            { label: 'Subscriptions', icon: Film },
            { label: 'Accounts', icon: Cloud },
            { label: 'Top-Up', icon: Coins },
          ].map((p) => (
            <CommandItem key={p.label} value={`product type ${p.label}`} onSelect={() => go('products')}>
              <p.icon className="mr-2 h-4 w-4 text-blue-500" />
              <span>Browse {p.label}</span>
            </CommandItem>
          ))}
        </CommandGroup>
      </CommandList>
    </CommandDialog>
  )
}
