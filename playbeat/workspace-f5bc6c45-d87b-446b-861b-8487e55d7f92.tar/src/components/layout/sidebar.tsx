'use client'

import { useNav, type ViewKey } from '@/lib/nav-store'
import { cn } from '@/lib/utils'
import {
  LayoutDashboard, Package, LayoutTemplate, ShoppingCart, Users, CreditCard,
  Boxes, Megaphone, BarChart3, ShieldCheck, Settings, UserCog, Search, ChevronLeft,
  Gamepad2, X, Sparkles,
} from 'lucide-react'
import { motion, AnimatePresence } from 'framer-motion'

interface NavItem {
  key: ViewKey
  label: string
  icon: any
}

const NAV_GROUPS: { title: string; items: NavItem[] }[] = [
  { title: 'Overview', items: [{ key: 'dashboard', label: 'Dashboard', icon: LayoutDashboard }] },
  { title: 'Catalog', items: [
    { key: 'products', label: 'Products', icon: Package },
    { key: 'homepage', label: 'Homepage Builder', icon: LayoutTemplate },
  ]},
  { title: 'Sales', items: [
    { key: 'orders', label: 'Orders', icon: ShoppingCart },
    { key: 'customers', label: 'Customers', icon: Users },
    { key: 'payments', label: 'Payments', icon: CreditCard },
  ]},
  { title: 'Operations', items: [
    { key: 'inventory', label: 'Inventory', icon: Boxes },
    { key: 'marketing', label: 'Marketing', icon: Megaphone },
  ]},
  { title: 'Insights', items: [{ key: 'reports', label: 'Reports', icon: BarChart3 }] },
  { title: 'System', items: [
    { key: 'users', label: 'User Roles', icon: UserCog },
    { key: 'security', label: 'Security', icon: ShieldCheck },
    { key: 'settings', label: 'Settings', icon: Settings },
  ]},
]

export function Sidebar() {
  const { view, setView, sidebarCollapsed, toggleSidebar, mobileSidebarOpen, setMobileSidebarOpen, setCommandOpen } = useNav()

  const content = (
    <div className="flex h-full flex-col">
      <div className={cn('flex items-center gap-3 px-4 py-5', sidebarCollapsed && 'justify-center px-2')}>
        <div className="relative flex h-10 w-10 shrink-0 items-center justify-center rounded-xl pb-gradient-brand text-white shadow-lg">
          <Gamepad2 className="h-5 w-5" />
          <span className="absolute -right-1 -top-1 flex h-3 w-3 items-center justify-center rounded-full bg-blue-500 ring-2 ring-background">
            <Sparkles className="h-2 w-2" />
          </span>
        </div>
        {!sidebarCollapsed && (
          <div className="min-w-0">
            <p className="truncate text-sm font-extrabold leading-tight pb-gradient-text">Playbeat.Digital</p>
            <p className="truncate text-[10px] font-medium uppercase tracking-wider text-muted-foreground">Admin Panel</p>
          </div>
        )}
      </div>

      {!sidebarCollapsed && (
        <div className="px-3 pb-2">
          <button
            onClick={() => setCommandOpen(true)}
            className="flex w-full items-center gap-2 rounded-xl border border-border bg-background/60 px-3 py-2 text-xs text-muted-foreground transition hover:border-primary/40 hover:bg-accent"
          >
            <Search className="h-3.5 w-3.5" />
            <span>Quick search...</span>
            <kbd className="ml-auto rounded bg-muted px-1.5 py-0.5 text-[9px] font-semibold">⌘K</kbd>
          </button>
        </div>
      )}

      <nav className="flex-1 space-y-4 overflow-y-auto pb-scroll px-3 py-2">
        {NAV_GROUPS.map((group) => (
          <div key={group.title}>
            {!sidebarCollapsed && (
              <p className="mb-1.5 px-2 text-[10px] font-bold uppercase tracking-wider text-muted-foreground/70">{group.title}</p>
            )}
            <div className="space-y-0.5">
              {group.items.map((item) => {
                const active = view === item.key
                const Icon = item.icon
                return (
                  <button
                    key={item.key}
                    onClick={() => { setView(item.key); setMobileSidebarOpen(false) }}
                    title={sidebarCollapsed ? item.label : undefined}
                    className={cn(
                      'group relative flex w-full items-center gap-3 rounded-xl px-3 py-2 text-sm font-medium transition-all',
                      sidebarCollapsed && 'justify-center',
                      active
                        ? 'bg-gradient-to-r from-primary to-orange-500 text-white shadow-md shadow-primary/25'
                        : 'text-foreground/75 hover:bg-accent hover:text-foreground'
                    )}
                  >
                    <Icon className={cn('h-[18px] w-[18px] shrink-0', active && 'drop-shadow')} />
                    {!sidebarCollapsed && <span className="truncate">{item.label}</span>}
                    {active && !sidebarCollapsed && (
                      <span className="ml-auto h-1.5 w-1.5 rounded-full bg-white" />
                    )}
                  </button>
                )
              })}
            </div>
          </div>
        ))}
      </nav>

      <div className="hidden border-t border-border p-3 lg:block">
        <button
          onClick={toggleSidebar}
          className="flex w-full items-center justify-center gap-2 rounded-xl px-3 py-2 text-xs font-medium text-muted-foreground transition hover:bg-accent hover:text-foreground"
        >
          <ChevronLeft className={cn('h-4 w-4 transition-transform', sidebarCollapsed && 'rotate-180')} />
          {!sidebarCollapsed && <span>Collapse</span>}
        </button>
      </div>

      {!sidebarCollapsed && (
        <div className="m-3 hidden overflow-hidden rounded-2xl pb-gradient-brand p-4 text-white shadow-lg lg:block">
          <p className="text-sm font-bold">Enterprise Plan</p>
          <p className="mt-1 text-xs text-white/80">Unlock advanced analytics & unlimited products.</p>
          <button className="mt-3 w-full rounded-lg bg-white/20 px-3 py-1.5 text-xs font-semibold backdrop-blur transition hover:bg-white/30">
            Upgrade Now
          </button>
        </div>
      )}
    </div>
  )

  return (
    <>
      <aside
        className={cn(
          'hidden lg:flex shrink-0 flex-col pb-glass border-r border-border transition-all duration-300',
          sidebarCollapsed ? 'w-[76px]' : 'w-[260px]'
        )}
      >
        {content}
      </aside>

      <AnimatePresence>
        {mobileSidebarOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setMobileSidebarOpen(false)}
              className="fixed inset-0 z-40 bg-black/50 backdrop-blur-sm lg:hidden"
            />
            <motion.aside
              initial={{ x: -300 }}
              animate={{ x: 0 }}
              exit={{ x: -300 }}
              transition={{ type: 'spring', damping: 26, stiffness: 240 }}
              className="fixed inset-y-0 left-0 z-50 w-[280px] pb-glass border-r border-border lg:hidden"
            >
              <button
                onClick={() => setMobileSidebarOpen(false)}
                className="absolute right-3 top-4 rounded-lg p-1.5 text-muted-foreground hover:bg-accent"
              >
                <X className="h-4 w-4" />
              </button>
              {content}
            </motion.aside>
          </>
        )}
      </AnimatePresence>
    </>
  )
}
