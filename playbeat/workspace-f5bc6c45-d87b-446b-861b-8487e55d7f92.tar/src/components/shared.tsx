'use client'

import { cn } from '@/lib/utils'
import { Card } from '@/components/ui/card'
import { motion } from 'framer-motion'
import type { LucideIcon } from 'lucide-react'
import { TrendingUp, TrendingDown } from 'lucide-react'
import { useEffect, useRef } from 'react'

/* ---------- Glass Card ---------- */
export function GlassCard({
  className,
  children,
  hover = false,
  ...props
}: React.HTMLAttributes<HTMLDivElement> & { hover?: boolean }) {
  return (
    <div
      className={cn('pb-glass rounded-2xl shadow-sm', hover && 'pb-lift', className)}
      {...props}
    >
      {children}
    </div>
  )
}

/* ---------- Stat Card (animated) ---------- */
export function StatCard({
  title,
  value,
  icon: Icon,
  delta,
  deltaLabel,
  gradient,
  delay = 0,
  prefix = '',
  suffix = '',
}: {
  title: string
  value: string | number
  icon: LucideIcon
  delta?: number
  deltaLabel?: string
  gradient: string
  delay?: number
  prefix?: string
  suffix?: string
}) {
  const up = (delta ?? 0) >= 0
  return (
    <motion.div
      initial={{ opacity: 0, y: 14 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay }}
      className="pb-glass rounded-2xl p-5 pb-lift relative overflow-hidden"
    >
      <div className={cn('absolute -right-6 -top-6 h-24 w-24 rounded-full opacity-20 blur-2xl', gradient)} />
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">{title}</p>
          <p className="mt-2 text-2xl font-bold pb-count text-foreground sm:text-3xl">
            {prefix}
            <AnimatedNumber value={typeof value === 'number' ? value : 0} display={String(value)} />
            {suffix}
          </p>
          {delta !== undefined && (
            <div className="mt-2 flex items-center gap-1.5 text-xs">
              <span
                className={cn(
                  'inline-flex items-center gap-0.5 rounded-full px-1.5 py-0.5 font-semibold',
                  up ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400' : 'bg-red-500/10 text-red-600 dark:text-red-400'
                )}
              >
                {up ? <TrendingUp className="h-3 w-3" /> : <TrendingDown className="h-3 w-3" />}
                {Math.abs(delta)}%
              </span>
              {deltaLabel && <span className="text-muted-foreground">{deltaLabel}</span>}
            </div>
          )}
        </div>
        <div className={cn('flex h-11 w-11 shrink-0 items-center justify-center rounded-xl text-white shadow-lg', gradient)}>
          <Icon className="h-5 w-5" />
        </div>
      </div>
    </motion.div>
  )
}

/* Animated number using rAF + direct DOM updates (no setState-in-effect) */
function AnimatedNumber({ value, display }: { value: number; display: string }) {
  const ref = useRef<HTMLSpanElement>(null)
  useEffect(() => {
    const el = ref.current
    if (!el) return
    if (isNaN(value) || !isFinite(value)) {
      el.textContent = display
      return
    }
    const target = value
    const duration = 900
    let raf = 0
    const t0 = performance.now()
    const tick = (t: number) => {
      const p = Math.min(1, (t - t0) / duration)
      const eased = 1 - Math.pow(1 - p, 3)
      const current = target * eased
      const isInt = Number.isInteger(target)
      el.textContent = isInt
        ? Math.round(current).toLocaleString()
        : current.toLocaleString(undefined, { maximumFractionDigits: 2 })
      if (p < 1) raf = requestAnimationFrame(tick)
    }
    raf = requestAnimationFrame(tick)
    return () => cancelAnimationFrame(raf)
  }, [value, display])
  return <span ref={ref}>{display}</span>
}

/* ---------- Section header ---------- */
export function SectionHeader({
  title,
  subtitle,
  icon: Icon,
  action,
}: {
  title: string
  subtitle?: string
  icon?: LucideIcon
  action?: React.ReactNode
}) {
  return (
    <div className="mb-5 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
      <div className="flex items-center gap-3">
        {Icon && (
          <div className="flex h-10 w-10 items-center justify-center rounded-xl pb-gradient-brand text-white shadow-md">
            <Icon className="h-5 w-5" />
          </div>
        )}
        <div>
          <h1 className="text-xl font-bold tracking-tight text-foreground sm:text-2xl">{title}</h1>
          {subtitle && <p className="text-sm text-muted-foreground">{subtitle}</p>}
        </div>
      </div>
      {action && <div className="flex flex-wrap items-center gap-2">{action}</div>}
    </div>
  )
}

/* ---------- Status pill ---------- */
const STATUS_STYLES: Record<string, string> = {
  active: 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 ring-emerald-500/20',
  completed: 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 ring-emerald-500/20',
  paid: 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 ring-emerald-500/20',
  success: 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 ring-emerald-500/20',
  approved: 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 ring-emerald-500/20',
  available: 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 ring-emerald-500/20',
  resolved: 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 ring-emerald-500/20',
  pending: 'bg-amber-500/10 text-amber-600 dark:text-amber-400 ring-amber-500/20',
  processing: 'bg-blue-500/10 text-blue-600 dark:text-blue-400 ring-blue-500/20',
  open: 'bg-blue-500/10 text-blue-600 dark:text-blue-400 ring-blue-500/20',
  scheduled: 'bg-blue-500/10 text-blue-600 dark:text-blue-400 ring-blue-500/20',
  draft: 'bg-slate-500/10 text-slate-600 dark:text-slate-300 ring-slate-500/20',
  failed: 'bg-red-500/10 text-red-600 dark:text-red-400 ring-red-500/20',
  cancelled: 'bg-red-500/10 text-red-600 dark:text-red-400 ring-red-500/20',
  refunded: 'bg-orange-500/10 text-orange-600 dark:text-orange-400 ring-orange-500/20',
  partial: 'bg-orange-500/10 text-orange-600 dark:text-orange-400 ring-orange-500/20',
  unpaid: 'bg-red-500/10 text-red-600 dark:text-red-400 ring-red-500/20',
  blocked: 'bg-red-500/10 text-red-600 dark:text-red-400 ring-red-500/20',
  rejected: 'bg-red-500/10 text-red-600 dark:text-red-400 ring-red-500/20',
  out_of_stock: 'bg-red-500/10 text-red-600 dark:text-red-400 ring-red-500/20',
  'out-of-stock': 'bg-red-500/10 text-red-600 dark:text-red-400 ring-red-500/20',
  used: 'bg-slate-500/10 text-slate-600 dark:text-slate-300 ring-slate-500/20',
  assigned: 'bg-orange-500/10 text-orange-600 dark:text-orange-400 ring-orange-500/20',
  urgent: 'bg-red-500/10 text-red-600 dark:text-red-400 ring-red-500/20',
  high: 'bg-orange-500/10 text-orange-600 dark:text-orange-400 ring-orange-500/20',
  medium: 'bg-blue-500/10 text-blue-600 dark:text-blue-400 ring-blue-500/20',
  low: 'bg-slate-500/10 text-slate-600 dark:text-slate-300 ring-slate-500/20',
}

export function StatusPill({ status, className }: { status: string; className?: string }) {
  const key = status.toLowerCase().replace(/\s+/g, '_')
  const style = STATUS_STYLES[key] || STATUS_STYLES[status.toLowerCase()] || 'bg-slate-500/10 text-slate-600 dark:text-slate-300 ring-slate-500/20'
  return (
    <span className={cn('inline-flex items-center gap-1 rounded-full px-2.5 py-0.5 text-xs font-semibold capitalize ring-1 ring-inset', style, className)}>
      {status.replace(/_/g, ' ')}
    </span>
  )
}

/* ---------- Empty state ---------- */
export function EmptyState({ icon: Icon, title, description, action }: { icon: LucideIcon; title: string; description?: string; action?: React.ReactNode }) {
  return (
    <div className="flex flex-col items-center justify-center gap-3 rounded-2xl border border-dashed border-border p-10 text-center">
      <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-muted text-muted-foreground">
        <Icon className="h-7 w-7" />
      </div>
      <div>
        <p className="font-semibold text-foreground">{title}</p>
        {description && <p className="mt-1 text-sm text-muted-foreground">{description}</p>}
      </div>
      {action}
    </div>
  )
}

/* ---------- Loading skeleton grid ---------- */
export function TableSkeleton({ rows = 6, cols = 5 }: { rows?: number; cols?: number }) {
  return (
    <div className="space-y-3">
      {Array.from({ length: rows }).map((_, i) => (
        <div key={i} className="flex items-center gap-4">
          {Array.from({ length: cols }).map((_, j) => (
            <div key={j} className="h-8 flex-1 rounded-lg bg-muted pb-shimmer" style={{ animationDelay: `${i * 80 + j * 40}ms` }} />
          ))}
        </div>
      ))}
    </div>
  )
}

export { Card, motion }
