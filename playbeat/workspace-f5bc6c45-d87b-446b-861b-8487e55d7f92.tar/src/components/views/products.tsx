'use client'

import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { GlassCard, SectionHeader, StatusPill, TableSkeleton, EmptyState } from '@/components/shared'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogTrigger } from '@/components/ui/dialog'
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog'
import { ScrollArea } from '@/components/ui/scroll-area'
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu'
import {
  Package, Plus, Search, Filter, Download, Upload, MoreHorizontal, Pencil, Trash2, Star, Flame, Eye, Copy, Tag, Key, FileImage,
} from 'lucide-react'
import { useState } from 'react'
import { toast } from 'sonner'
import { formatPKR } from '@/lib/currency'

const TYPES = ['Games', 'Gift Cards', 'Software', 'AI Tools', 'Accounts', 'Subscriptions', 'Top-Up', 'Game Items']
const STATUSES = ['active', 'draft', 'out-of-stock']

type Product = any

export function ProductsView() {
  const qc = useQueryClient()
  const [type, setType] = useState('')
  const [status, setStatus] = useState('')
  const [search, setSearch] = useState('')
  const [filterFeatured, setFilterFeatured] = useState(false)
  const [filterTrending, setFilterTrending] = useState(false)
  const [editorOpen, setEditorOpen] = useState(false)
  const [editing, setEditing] = useState<Product | null>(null)
  const [deleteId, setDeleteId] = useState<string | null>(null)

  const qs = new URLSearchParams()
  if (type) qs.set('type', type)
  if (status) qs.set('status', status)
  if (search) qs.set('search', search)
  if (filterFeatured) qs.set('featured', 'true')
  if (filterTrending) qs.set('trending', 'true')

  const { data, isLoading } = useQuery<{ products: Product[] }>({
    queryKey: ['products', type, status, search, filterFeatured, filterTrending],
    queryFn: () => fetch(`/api/products?${qs}`).then((r) => r.json()),
  })
  const products = data?.products || []

  const createMut = useMutation({
    mutationFn: (body: any) => fetch('/api/products', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }).then((r) => r.json()),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['products'] }); toast.success('Product created'); setEditorOpen(false) },
    onError: () => toast.error('Failed to create product'),
  })
  const updateMut = useMutation({
    mutationFn: ({ id, body }: { id: string; body: any }) => fetch(`/api/products/${id}`, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }).then((r) => r.json()),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['products'] }); toast.success('Product updated'); setEditorOpen(false); setEditing(null) },
    onError: () => toast.error('Failed to update product'),
  })
  const deleteMut = useMutation({
    mutationFn: (id: string) => fetch(`/api/products/${id}`, { method: 'DELETE' }).then((r) => r.json()),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['products'] }); toast.success('Product deleted'); setDeleteId(null) },
  })

  const openNew = () => { setEditing(null); setEditorOpen(true) }
  const openEdit = (p: Product) => { setEditing(p); setEditorOpen(true) }

  const exportCsv = () => {
    const rows = [['Name', 'Type', 'Category', 'SKU', 'Price', 'Stock', 'Status', 'Sales']]
    for (const p of products) rows.push([p.name, p.type, p.category, p.sku, p.price, p.stock, p.status, p.salesCount])
    const csv = rows.map((r) => r.map((c) => `"${c}"`).join(',')).join('\n')
    const url = URL.createObjectURL(new Blob([csv], { type: 'text/csv' }))
    const a = document.createElement('a'); a.href = url; a.download = 'playbeat-products.csv'; a.click()
    URL.revokeObjectURL(url)
    toast.success('Exported CSV')
  }

  return (
    <div className="space-y-6">
      <SectionHeader
        title="Product Management"
        subtitle="Manage your digital catalog — games, gift cards, software, AI tools & more"
        icon={Package}
        action={
          <>
            <Button variant="outline" size="sm" onClick={() => toast.info('Bulk import: upload a CSV to add products in batch')}>
              <Upload className="mr-2 h-4 w-4" /> Import
            </Button>
            <Button variant="outline" size="sm" onClick={exportCsv}>
              <Download className="mr-2 h-4 w-4" /> Export
            </Button>
            <Button size="sm" className="pb-gradient-brand" onClick={openNew}>
              <Plus className="mr-2 h-4 w-4" /> Add Product
            </Button>
          </>
        }
      />

      {/* Type tabs */}
      <Tabs value={type} onValueChange={(v) => setType(v === 'all' ? '' : v)}>
        <ScrollArea className="w-full whitespace-nowrap">
          <TabsList className="h-auto">
            <TabsTrigger value="all" className="text-xs">All</TabsTrigger>
            {TYPES.map((t) => (
              <TabsTrigger key={t} value={t} className="text-xs">{t}</TabsTrigger>
            ))}
          </TabsList>
        </ScrollArea>
      </Tabs>

      {/* Filters */}
      <GlassCard className="p-4">
        <div className="flex flex-wrap items-center gap-3">
          <div className="relative min-w-[220px] flex-1">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input placeholder="Search by name, SKU, brand..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-9" />
          </div>
          <Select value={status} onValueChange={(v) => setStatus(v === 'all' ? '' : v)}>
            <SelectTrigger className="w-[160px]"><SelectValue placeholder="Status" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All status</SelectItem>
              {STATUSES.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}
            </SelectContent>
          </Select>
          <Button variant={filterFeatured ? 'default' : 'outline'} size="sm" onClick={() => setFilterFeatured((v) => !v)}>
            <Star className="mr-1.5 h-3.5 w-3.5" /> Featured
          </Button>
          <Button variant={filterTrending ? 'default' : 'outline'} size="sm" onClick={() => setFilterTrending((v) => !v)}>
            <Flame className="mr-1.5 h-3.5 w-3.5" /> Trending
          </Button>
          <Badge variant="secondary" className="ml-auto">{products.length} products</Badge>
        </div>
      </GlassCard>

      {/* Table */}
      <GlassCard className="overflow-hidden">
        {isLoading ? (
          <div className="p-5"><TableSkeleton /></div>
        ) : products.length === 0 ? (
          <div className="p-5"><EmptyState icon={Package} title="No products found" description="Try adjusting filters or add a new product." action={<Button className="pb-gradient-brand" onClick={openNew}><Plus className="mr-2 h-4 w-4" /> Add Product</Button>} /></div>
        ) : (
          <div className="overflow-x-auto pb-scroll">
            <table className="w-full min-w-[860px] text-sm">
              <thead>
                <tr className="border-b border-border bg-muted/40 text-left text-xs uppercase tracking-wide text-muted-foreground">
                  <th className="px-4 py-3 font-semibold">Product</th>
                  <th className="px-4 py-3 font-semibold">Type</th>
                  <th className="px-4 py-3 font-semibold">Price</th>
                  <th className="px-4 py-3 font-semibold">Stock</th>
                  <th className="px-4 py-3 font-semibold">Sales</th>
                  <th className="px-4 py-3 font-semibold">Status</th>
                  <th className="px-4 py-3 font-semibold">Tags</th>
                  <th className="px-4 py-3 text-right font-semibold">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {products.map((p) => {
                  const images = JSON.parse(p.images || '[]') as string[]
                  const tags = JSON.parse(p.tags || '[]') as string[]
                  return (
                    <tr key={p.id} className="group transition hover:bg-accent/40">
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-3">
                          <img src={images[0] || `https://picsum.photos/seed/${p.slug}/80`} alt={p.name} className="h-11 w-11 rounded-lg object-cover ring-1 ring-border" />
                          <div className="min-w-0">
                            <p className="flex items-center gap-1.5 font-medium">
                              {p.name}
                              {p.featured && <Star className="h-3 w-3 fill-amber-400 text-amber-400" />}
                              {p.trending && <Flame className="h-3 w-3 text-orange-500" />}
                            </p>
                            <p className="text-xs text-muted-foreground">{p.sku} · {p.brand}</p>
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-3"><Badge variant="outline" className="text-xs">{p.type}</Badge></td>
                      <td className="px-4 py-3">
                        <p className="font-semibold">{formatPKR(p.price)}</p>
                        {p.comparePrice && <p className="text-xs text-muted-foreground line-through">{formatPKR(p.comparePrice)}</p>}
                      </td>
                      <td className="px-4 py-3">
                        <span className={p.stock === 0 ? 'font-semibold text-red-500' : p.stock < 15 ? 'font-semibold text-amber-500' : 'font-medium'}>{p.stock}</span>
                      </td>
                      <td className="px-4 py-3 text-muted-foreground">{p.salesCount}</td>
                      <td className="px-4 py-3"><StatusPill status={p.status} /></td>
                      <td className="px-4 py-3">
                        <div className="flex flex-wrap gap-1">
                          {tags.slice(0, 2).map((t) => <Badge key={t} variant="secondary" className="text-[10px]">{t}</Badge>)}
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex items-center justify-end gap-1">
                          <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => openEdit(p)} title="Edit"><Pencil className="h-4 w-4" /></Button>
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon" className="h-8 w-8"><MoreHorizontal className="h-4 w-4" /></Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem onClick={() => openEdit(p)}><Pencil className="mr-2 h-4 w-4" /> Edit</DropdownMenuItem>
                              <DropdownMenuItem onClick={() => { setEditing(p); setEditorOpen(true) }}><Eye className="mr-2 h-4 w-4" /> View details</DropdownMenuItem>
                              <DropdownMenuItem onClick={() => navigator.clipboard?.writeText(p.id) && toast.success('ID copied')}><Copy className="mr-2 h-4 w-4" /> Copy ID</DropdownMenuItem>
                              <DropdownMenuItem className="text-red-600 focus:text-red-600" onClick={() => setDeleteId(p.id)}><Trash2 className="mr-2 h-4 w-4" /> Delete</DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </div>
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        )}
      </GlassCard>

      {/* Editor dialog */}
      <Dialog open={editorOpen} onOpenChange={(o) => { setEditorOpen(o); if (!o) setEditing(null) }}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto pb-scroll">
          <DialogHeader>
            <DialogTitle>{editing ? 'Edit Product' : 'Add New Product'}</DialogTitle>
          </DialogHeader>
          <ProductForm
            initial={editing}
            onSubmit={(body) => {
              if (editing) updateMut.mutate({ id: editing.id, body })
              else createMut.mutate(body)
            }}
            loading={createMut.isPending || updateMut.isPending}
          />
        </DialogContent>
      </Dialog>

      {/* Delete confirm */}
      <AlertDialog open={!!deleteId} onOpenChange={(o) => !o && setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete this product?</AlertDialogTitle>
            <AlertDialogDescription>This action cannot be undone. The product and its data will be permanently removed.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction className="bg-red-600 hover:bg-red-700" onClick={() => deleteId && deleteMut.mutate(deleteId)}>Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}

function ProductForm({ initial, onSubmit, loading }: { initial: Product | null; onSubmit: (b: any) => void; loading: boolean }) {
  const parseImages = (s: string) => { try { return JSON.parse(s || '[]') } catch { return [] } }
  const [form, setForm] = useState({
    name: initial?.name || '',
    type: initial?.type || 'Games',
    category: initial?.category || '',
    brand: initial?.brand || 'Playbeat',
    price: initial?.price ?? '',
    comparePrice: initial?.comparePrice ?? '',
    stock: initial?.stock ?? 0,
    sku: initial?.sku || '',
    status: initial?.status || 'active',
    description: initial?.description || '',
    featured: initial?.featured || false,
    trending: initial?.trending || false,
    hasLicenseKeys: initial?.hasLicenseKeys || false,
    videoUrl: initial?.videoUrl || '',
    seoTitle: initial?.seoTitle || '',
    seoDescription: initial?.seoDescription || '',
    tags: (initial ? parseImages(initial.tags) : []).join(', '),
    images: (initial ? parseImages(initial.images) : []).join('\n'),
  })
  const set = (k: string, v: any) => setForm((f) => ({ ...f, [k]: v }))

  const submit = () => {
    if (!form.name || !form.price) { toast.error('Name and price are required'); return }
    onSubmit({
      ...form,
      price: Number(form.price),
      comparePrice: form.comparePrice ? Number(form.comparePrice) : null,
      stock: Number(form.stock),
      tags: form.tags.split(',').map((t) => t.trim()).filter(Boolean),
      images: form.images.split('\n').map((t) => t.trim()).filter(Boolean),
      gallery: form.images.split('\n').map((t) => t.trim()).filter(Boolean),
    })
  }

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <div className="space-y-1.5 sm:col-span-2">
          <Label>Product Name *</Label>
          <Input value={form.name} onChange={(e) => set('name', e.target.value)} placeholder="e.g. Cyberpunk 2077 (PC)" />
        </div>
        <div className="space-y-1.5">
          <Label>Type</Label>
          <Select value={form.type} onValueChange={(v) => set('type', v)}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>{TYPES.map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent>
          </Select>
        </div>
        <div className="space-y-1.5">
          <Label>Category</Label>
          <Input value={form.category} onChange={(e) => set('category', e.target.value)} placeholder="e.g. PC Games" />
        </div>
        <div className="space-y-1.5">
          <Label>Brand</Label>
          <Input value={form.brand} onChange={(e) => set('brand', e.target.value)} />
        </div>
        <div className="space-y-1.5">
          <Label>SKU</Label>
          <Input value={form.sku} onChange={(e) => set('sku', e.target.value)} placeholder="Auto-generated if empty" />
        </div>
        <div className="space-y-1.5">
          <Label>Price (USD) *</Label>
          <Input type="number" step="0.01" value={form.price} onChange={(e) => set('price', e.target.value)} />
        </div>
        <div className="space-y-1.5">
          <Label>Compare-at Price</Label>
          <Input type="number" step="0.01" value={form.comparePrice} onChange={(e) => set('comparePrice', e.target.value)} placeholder="0.00" />
        </div>
        <div className="space-y-1.5">
          <Label>Stock</Label>
          <Input type="number" value={form.stock} onChange={(e) => set('stock', e.target.value)} />
        </div>
        <div className="space-y-1.5">
          <Label>Status</Label>
          <Select value={form.status} onValueChange={(v) => set('status', v)}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>{STATUSES.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
          </Select>
        </div>
      </div>

      <div className="space-y-1.5">
        <Label>Description</Label>
        <Textarea rows={3} value={form.description} onChange={(e) => set('description', e.target.value)} placeholder="Product description shown to customers..." />
      </div>

      <div className="space-y-1.5">
        <Label>Image URLs (one per line)</Label>
        <Textarea rows={3} value={form.images} onChange={(e) => set('images', e.target.value)} placeholder="https://..." />
      </div>

      <div className="space-y-1.5">
        <Label>Tags (comma separated)</Label>
        <Input value={form.tags} onChange={(e) => set('tags', e.target.value)} placeholder="digital, game, pc" />
      </div>

      <div className="space-y-1.5">
        <Label>Video Preview URL (optional)</Label>
        <Input value={form.videoUrl} onChange={(e) => set('videoUrl', e.target.value)} placeholder="https://www.youtube.com/embed/..." />
      </div>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <div className="space-y-1.5">
          <Label>SEO Title</Label>
          <Input value={form.seoTitle} onChange={(e) => set('seoTitle', e.target.value)} />
        </div>
        <div className="space-y-1.5">
          <Label>SEO Description</Label>
          <Input value={form.seoDescription} onChange={(e) => set('seoDescription', e.target.value)} />
        </div>
      </div>

      <div className="grid grid-cols-1 gap-3 rounded-xl border border-border bg-muted/30 p-4 sm:grid-cols-3">
        <div className="flex items-center justify-between gap-2">
          <div><p className="text-sm font-medium">Featured</p><p className="text-xs text-muted-foreground">Show on homepage</p></div>
          <Switch checked={form.featured} onCheckedChange={(v) => set('featured', v)} />
        </div>
        <div className="flex items-center justify-between gap-2">
          <div><p className="text-sm font-medium">Trending</p><p className="text-xs text-muted-foreground">Mark as hot</p></div>
          <Switch checked={form.trending} onCheckedChange={(v) => set('trending', v)} />
        </div>
        <div className="flex items-center justify-between gap-2">
          <div><p className="text-sm font-medium">License Keys</p><p className="text-xs text-muted-foreground">Requires keys</p></div>
          <Switch checked={form.hasLicenseKeys} onCheckedChange={(v) => set('hasLicenseKeys', v)} />
        </div>
      </div>

      <DialogFooter>
        <Button variant="outline" onClick={() => {}}>Cancel</Button>
        <Button className="pb-gradient-brand" onClick={submit} disabled={loading}>{loading ? 'Saving...' : initial ? 'Save Changes' : 'Create Product'}</Button>
      </DialogFooter>
    </div>
  )
}
