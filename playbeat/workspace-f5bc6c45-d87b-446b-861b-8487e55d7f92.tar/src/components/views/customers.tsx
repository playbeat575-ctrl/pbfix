'use client'

import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { GlassCard, SectionHeader, StatusPill, TableSkeleton, EmptyState } from '@/components/shared'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Separator } from '@/components/ui/separator'
import {
  Users, Search, Eye, Ban, CheckCircle2, Wallet, Award, ShoppingBag, Star, Heart, Mail, Phone, Globe, ShieldCheck, UserPlus,
} from 'lucide-react'
import { useState } from 'react'
import { toast } from 'sonner'
import { formatPKR } from '@/lib/currency'

type Customer = any

export function CustomersView() {
  const qc = useQueryClient()
  const [status, setStatus] = useState('')
  const [search, setSearch] = useState('')
  const [selected, setSelected] = useState<Customer | null>(null)

  const qs = new URLSearchParams()
  if (status) qs.set('status', status)
  if (search) qs.set('search', search)

  const { data, isLoading } = useQuery<{ customers: Customer[] }>({
    queryKey: ['customers', status, search],
    queryFn: () => fetch(`/api/customers?${qs}`).then((r) => r.json()),
  })
  const customers = data?.customers || []

  const updateMut = useMutation({
    mutationFn: ({ id, body }: { id: string; body: any }) => fetch(`/api/customers/${id}`, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }).then((r) => r.json()),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['customers'] }); qc.invalidateQueries({ queryKey: ['customer'] }) },
  })

  const toggleBlock = (c: Customer) => {
    const next = c.status === 'blocked' ? 'active' : 'blocked'
    updateMut.mutate({ id: c.id, body: { status: next } }, {
      onSuccess: () => toast.success(`${c.name} ${next === 'blocked' ? 'blocked' : 'unblocked'}`),
    })
  }

  return (
    <div className="space-y-6">
      <SectionHeader
        title="Customer Management"
        subtitle="Profiles, purchase history, wallets & support — all in one place"
        icon={Users}
        action={<Button size="sm" className="pb-gradient-brand" onClick={() => toast.info('Open new customer form')}><UserPlus className="mr-2 h-4 w-4" /> Add Customer</Button>}
      />

      {/* Stats */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatBox label="Total Customers" value={customers.length} icon={Users} color="from-blue-500 to-cyan-500" />
        <StatBox label="Active" value={customers.filter((c) => c.status === 'active').length} icon={CheckCircle2} color="from-emerald-500 to-teal-500" />
        <StatBox label="Blocked" value={customers.filter((c) => c.status === 'blocked').length} icon={Ban} color="from-red-500 to-rose-500" />
        <StatBox label="Total Wallet Balance" value={formatPKR(customers.reduce((s, c) => s + c.walletBalance, 0))} icon={Wallet} color="from-orange-500 to-amber-500" />
      </div>

      {/* Filters */}
      <GlassCard className="p-4">
        <div className="flex flex-wrap items-center gap-3">
          <div className="relative min-w-[220px] flex-1">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input placeholder="Search name, email, phone..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-9" />
          </div>
          <Select value={status} onValueChange={(v) => setStatus(v === 'all' ? '' : v)}>
            <SelectTrigger className="w-[160px]"><SelectValue placeholder="Status" /></SelectTrigger>
            <SelectContent><SelectItem value="all">All</SelectItem><SelectItem value="active">Active</SelectItem><SelectItem value="pending">Pending</SelectItem><SelectItem value="blocked">Blocked</SelectItem></SelectContent>
          </Select>
        </div>
      </GlassCard>

      {/* Table */}
      <GlassCard className="overflow-hidden">
        {isLoading ? <div className="p-5"><TableSkeleton /></div> : customers.length === 0 ? (
          <div className="p-5"><EmptyState icon={Users} title="No customers found" /></div>
        ) : (
          <div className="overflow-x-auto pb-scroll">
            <table className="w-full min-w-[860px] text-sm">
              <thead>
                <tr className="border-b border-border bg-muted/40 text-left text-xs uppercase tracking-wide text-muted-foreground">
                  <th className="px-4 py-3 font-semibold">Customer</th>
                  <th className="px-4 py-3 font-semibold">Contact</th>
                  <th className="px-4 py-3 font-semibold">Orders</th>
                  <th className="px-4 py-3 font-semibold">Spent</th>
                  <th className="px-4 py-3 font-semibold">Wallet</th>
                  <th className="px-4 py-3 font-semibold">Points</th>
                  <th className="px-4 py-3 font-semibold">Status</th>
                  <th className="px-4 py-3 text-right font-semibold">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {customers.map((c) => (
                  <tr key={c.id} className="transition hover:bg-accent/40">
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-3">
                        <Avatar className="h-9 w-9 ring-2 ring-primary/10"><AvatarImage src={c.avatar} /><AvatarFallback className="bg-gradient-to-br from-blue-500 to-cyan-500 text-xs font-bold text-white">{c.name.slice(0, 2)}</AvatarFallback></Avatar>
                        <div>
                          <p className="flex items-center gap-1 font-medium">{c.name}{c.verified && <ShieldCheck className="h-3 w-3 text-blue-500" />}</p>
                          <p className="text-xs text-muted-foreground">{c.country || '—'}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3"><p className="text-xs">{c.email}</p><p className="text-xs text-muted-foreground">{c.phone || '—'}</p></td>
                    <td className="px-4 py-3 font-medium">{c.totalOrders}</td>
                    <td className="px-4 py-3 font-semibold text-emerald-600">{formatPKR(c.totalSpent)}</td>
                    <td className="px-4 py-3">{formatPKR(c.walletBalance)}</td>
                    <td className="px-4 py-3"><Badge variant="secondary" className="text-xs"><Award className="mr-1 h-3 w-3" /> {c.rewardPoints}</Badge></td>
                    <td className="px-4 py-3"><StatusPill status={c.status} /></td>
                    <td className="px-4 py-3">
                      <div className="flex items-center justify-end gap-1">
                        <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => setSelected(c)} title="View"><Eye className="h-4 w-4" /></Button>
                        <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => toggleBlock(c)} title={c.status === 'blocked' ? 'Unblock' : 'Block'}>
                          {c.status === 'blocked' ? <CheckCircle2 className="h-4 w-4 text-emerald-500" /> : <Ban className="h-4 w-4 text-red-500" />}
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </GlassCard>

      {/* Detail dialog */}
      <Dialog open={!!selected} onOpenChange={(o) => !o && setSelected(null)}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto pb-scroll">
          {selected && <CustomerDetail id={selected.id} onClose={() => setSelected(null)} onToggleBlock={toggleBlock} />}
        </DialogContent>
      </Dialog>
    </div>
  )
}

function StatBox({ label, value, icon: Icon, color }: any) {
  return (
    <div className="pb-glass flex items-center gap-3 rounded-2xl p-4 pb-lift">
      <div className={`flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br ${color} text-white`}><Icon className="h-5 w-5" /></div>
      <div><p className="text-xl font-bold pb-count">{value}</p><p className="text-xs text-muted-foreground">{label}</p></div>
    </div>
  )
}

function CustomerDetail({ id, onClose, onToggleBlock }: { id: string; onClose: () => void; onToggleBlock: (c: any) => void }) {
  const { data, isLoading } = useQuery<{ customer: any; orders: any[]; reviews: any[]; tickets: any[] }>({
    queryKey: ['customer', id],
    queryFn: () => fetch(`/api/customers/${id}`).then((r) => r.json()),
  })
  const [tab, setTab] = useState('orders')
  if (isLoading) return <div className="p-6"><TableSkeleton rows={4} /></div>
  if (!data) return null
  const c = data.customer
  const loginHistory = JSON.parse(c.loginHistory || '[]') as any[]
  const wishlist = JSON.parse(c.wishlist || '[]') as string[]

  return (
    <div>
      <DialogHeader>
        <div className="flex items-center gap-4">
          <Avatar className="h-16 w-16 ring-4 ring-primary/20"><AvatarImage src={c.avatar} /><AvatarFallback className="pb-gradient-brand text-lg font-bold text-white">{c.name.slice(0, 2)}</AvatarFallback></Avatar>
          <div className="flex-1">
            <DialogTitle className="flex items-center gap-2">{c.name}{c.verified && <ShieldCheck className="h-4 w-4 text-blue-500" />}</DialogTitle>
            <p className="text-sm text-muted-foreground">{c.email}</p>
            <div className="mt-1 flex flex-wrap gap-2">
              <StatusPill status={c.status} />
              <Badge variant="outline" className="text-xs">Joined {new Date(c.createdAt).toLocaleDateString()}</Badge>
            </div>
          </div>
          <Button variant="outline" size="sm" onClick={() => onToggleBlock(c)}>
            {c.status === 'blocked' ? <><CheckCircle2 className="mr-1.5 h-4 w-4 text-emerald-500" /> Unblock</> : <><Ban className="mr-1.5 h-4 w-4 text-red-500" /> Block</>}
          </Button>
        </div>
      </DialogHeader>

      {/* Quick stats */}
      <div className="mt-5 grid grid-cols-2 gap-3 sm:grid-cols-4">
        {[
          { label: 'Orders', value: c.totalOrders, icon: ShoppingBag, color: 'from-blue-500 to-cyan-500' },
          { label: 'Total Spent', value: formatPKR(c.totalSpent), icon: Wallet, color: 'from-emerald-500 to-teal-500' },
          { label: 'Wallet', value: formatPKR(c.walletBalance), icon: Wallet, color: 'from-orange-500 to-amber-500' },
          { label: 'Reward Points', value: c.rewardPoints, icon: Award, color: 'from-violet-500 to-purple-500' },
        ].map((s) => (
          <div key={s.label} className="rounded-xl border border-border p-3">
            <div className={`mb-2 inline-flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br ${s.color} text-white`}><s.icon className="h-4 w-4" /></div>
            <p className="text-lg font-bold pb-count">{s.value}</p>
            <p className="text-xs text-muted-foreground">{s.label}</p>
          </div>
        ))}
      </div>

      {/* Contact */}
      <div className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-3">
        <div className="flex items-center gap-2 rounded-xl border border-border p-3 text-sm"><Mail className="h-4 w-4 text-muted-foreground" /> {c.email}</div>
        <div className="flex items-center gap-2 rounded-xl border border-border p-3 text-sm"><Phone className="h-4 w-4 text-muted-foreground" /> {c.phone || '—'}</div>
        <div className="flex items-center gap-2 rounded-xl border border-border p-3 text-sm"><Globe className="h-4 w-4 text-muted-foreground" /> {c.country || '—'}</div>
      </div>

      <Separator className="my-5" />

      <Tabs value={tab} onValueChange={setTab}>
        <TabsList>
          <TabsTrigger value="orders">Orders ({data.orders.length})</TabsTrigger>
          <TabsTrigger value="reviews">Reviews ({data.reviews.length})</TabsTrigger>
          <TabsTrigger value="tickets">Tickets ({data.tickets.length})</TabsTrigger>
          <TabsTrigger value="activity">Login History</TabsTrigger>
        </TabsList>
      </Tabs>

      <div className="mt-4">
        {tab === 'orders' && (
          <ScrollArea className="h-64">
            <div className="space-y-2">
              {data.orders.map((o) => (
                <div key={o.id} className="flex items-center gap-3 rounded-xl border border-border p-3">
                  <ShoppingBag className="h-4 w-4 text-blue-500" />
                  <div className="flex-1"><p className="text-sm font-medium">{o.orderNumber}</p><p className="text-xs text-muted-foreground">{new Date(o.createdAt).toLocaleDateString()}</p></div>
                  <StatusPill status={o.status} />
                  <p className="w-16 text-right text-sm font-semibold">{formatPKR(o.total)}</p>
                </div>
              ))}
              {data.orders.length === 0 && <EmptyState icon={ShoppingBag} title="No orders yet" />}
            </div>
          </ScrollArea>
        )}
        {tab === 'reviews' && (
          <ScrollArea className="h-64">
            <div className="space-y-2">
              {data.reviews.map((r) => (
                <div key={r.id} className="rounded-xl border border-border p-3">
                  <div className="flex items-center justify-between">
                    <p className="text-sm font-medium">{r.productName}</p>
                    <div className="flex">{Array.from({ length: 5 }).map((_, i) => <Star key={i} className={`h-3 w-3 ${i < r.rating ? 'fill-amber-400 text-amber-400' : 'text-muted'}`} />)}</div>
                  </div>
                  <p className="mt-1 text-xs text-muted-foreground">{r.comment}</p>
                </div>
              ))}
              {data.reviews.length === 0 && <EmptyState icon={Star} title="No reviews" />}
            </div>
          </ScrollArea>
        )}
        {tab === 'tickets' && (
          <ScrollArea className="h-64">
            <div className="space-y-2">
              {data.tickets.map((t) => (
                <div key={t.id} className="rounded-xl border border-border p-3">
                  <div className="flex items-center justify-between">
                    <p className="text-sm font-medium">{t.subject}</p>
                    <StatusPill status={t.status} />
                  </div>
                  <p className="mt-1 text-xs text-muted-foreground">{t.category} · {t.priority}</p>
                </div>
              ))}
              {data.tickets.length === 0 && <EmptyState icon={Mail} title="No support tickets" />}
            </div>
          </ScrollArea>
        )}
        {tab === 'activity' && (
          <ScrollArea className="h-64">
            <div className="space-y-2">
              {loginHistory.map((l, i) => (
                <div key={i} className="flex items-center gap-3 rounded-xl border border-border p-3 text-sm">
                  <Globe className="h-4 w-4 text-muted-foreground" />
                  <div className="flex-1"><p className="font-medium">{l.ip}</p><p className="text-xs text-muted-foreground">{l.device}</p></div>
                  <p className="text-xs text-muted-foreground">{new Date(l.time).toLocaleString()}</p>
                </div>
              ))}
              {loginHistory.length === 0 && <EmptyState icon={Users} title="No login history" />}
            </div>
          </ScrollArea>
        )}
      </div>

      {wishlist.length > 0 && (
        <div className="mt-4 flex items-center gap-2 rounded-xl border border-border bg-muted/30 p-3 text-sm">
          <Heart className="h-4 w-4 text-red-500" />
          <span className="text-muted-foreground">Wishlist:</span>
          <span className="font-medium">{wishlist.length} item(s)</span>
        </div>
      )}
    </div>
  )
}
