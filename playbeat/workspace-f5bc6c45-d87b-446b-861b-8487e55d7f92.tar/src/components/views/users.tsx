'use client'

import { useQuery } from '@tanstack/react-query'
import { GlassCard, SectionHeader, StatusPill, TableSkeleton, EmptyState } from '@/components/shared'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import { Checkbox } from '@/components/ui/checkbox'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog'
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu'
import { ScrollArea } from '@/components/ui/scroll-area'
import {
  UserCog, UserPlus, ShieldCheck, Shield, MoreHorizontal, Pencil, Ban, KeyRound, Mail, Lock, CheckCircle2, Clock, Sparkles,
  Crown, Briefcase, Headset, Wallet, Megaphone,
} from 'lucide-react'
import { useState } from 'react'
import { toast } from 'sonner'

type AdminUser = {
  id: string
  name: string
  email: string
  role: string
  status: string
  avatar: string
  lastLogin: string | null
  twoFA: boolean
  createdAt: string
}

const ROLES = [
  { key: 'Super Admin', color: 'from-red-500 to-orange-500', badge: 'bg-red-500/10 text-red-600 dark:text-red-400 ring-red-500/20', icon: Crown },
  { key: 'Admin', color: 'from-orange-500 to-amber-500', badge: 'bg-orange-500/10 text-orange-600 dark:text-orange-400 ring-orange-500/20', icon: Shield },
  { key: 'Manager', color: 'from-blue-500 to-cyan-500', badge: 'bg-blue-500/10 text-blue-600 dark:text-blue-400 ring-blue-500/20', icon: Briefcase },
  { key: 'Support', color: 'from-cyan-500 to-teal-500', badge: 'bg-cyan-500/10 text-cyan-600 dark:text-cyan-400 ring-cyan-500/20', icon: Headset },
  { key: 'Content Editor', color: 'from-violet-500 to-purple-500', badge: 'bg-violet-500/10 text-violet-600 dark:text-violet-400 ring-violet-500/20', icon: Pencil },
  { key: 'Finance', color: 'from-emerald-500 to-green-500', badge: 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 ring-emerald-500/20', icon: Wallet },
  { key: 'Marketing', color: 'from-pink-500 to-rose-500', badge: 'bg-pink-500/10 text-pink-600 dark:text-pink-400 ring-pink-500/20', icon: Megaphone },
]

const MODULES = ['Dashboard', 'Products', 'Orders', 'Customers', 'Payments', 'Inventory', 'Marketing', 'Reports', 'Users', 'Security', 'Settings']
const PERMS = ['view', 'edit', 'delete'] as const

// Mock permissions: super admin = all, others have partial
function defaultPerms(role: string): Record<string, Record<typeof PERMS[number], boolean>> {
  const all: any = {}
  for (const m of MODULES) all[m] = { view: true, edit: true, delete: true }
  if (role === 'Super Admin') return all
  const partial: any = {}
  for (const m of MODULES) {
    partial[m] = {
      view: true,
      edit: ['Products', 'Orders', 'Customers', 'Marketing'].includes(m),
      delete: ['Orders', 'Customers'].includes(m),
    }
  }
  return partial
}

export function UsersView() {
  const { data, isLoading } = useQuery<{ users: AdminUser[] }>({
    queryKey: ['admin-users'],
    queryFn: () => fetch('/api/admin-users').then((r) => r.json()),
  })
  const users = data?.users || []
  const activeNow = users.filter((u) => u.status === 'active').length
  const twoFACount = users.filter((u) => u.twoFA).length

  const [inviteOpen, setInviteOpen] = useState(false)
  const [permRole, setPermRole] = useState<string | null>(null)

  return (
    <div className="space-y-6">
      <SectionHeader
        title="User Roles & Permissions"
        subtitle="Role-based access control for every module"
        icon={UserCog}
        action={
          <>
            <Button variant="outline" size="sm" onClick={() => toast.info('Exporting team directory...')}>
              <Mail className="mr-2 h-4 w-4" /> Export
            </Button>
            <Button size="sm" className="pb-gradient-brand" onClick={() => setInviteOpen(true)}>
              <UserPlus className="mr-2 h-4 w-4" /> Invite User
            </Button>
          </>
        }
      />

      {/* Stats */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatBox label="Total Admins" value={users.length} icon={UserCog} color="from-red-500 to-orange-500" />
        <StatBox label="Active Now" value={activeNow} icon={CheckCircle2} color="from-emerald-500 to-teal-500" />
        <StatBox label="Roles Defined" value={ROLES.length} icon={Shield} color="from-blue-500 to-cyan-500" />
        <StatBox label="2FA Enabled" value={twoFACount} icon={Lock} color="from-violet-500 to-purple-500" />
      </div>

      {/* Two-column layout */}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-5">
        {/* Team members */}
        <GlassCard className="overflow-hidden lg:col-span-3">
          <div className="flex items-center justify-between border-b border-border/60 px-5 py-4">
            <div>
              <p className="text-sm font-semibold">Team Members</p>
              <p className="text-xs text-muted-foreground">All admin users with marketplace access</p>
            </div>
            <Badge variant="secondary" className="text-xs">{users.length} members</Badge>
          </div>
          {isLoading ? (
            <div className="p-5"><TableSkeleton rows={6} cols={4} /></div>
          ) : users.length === 0 ? (
            <div className="p-5"><EmptyState icon={UserCog} title="No team members" description="Invite your first admin user." /></div>
          ) : (
            <div className="max-h-[640px] overflow-y-auto pb-scroll">
              <div className="space-y-2 p-3">
                {users.map((u) => {
                  const role = ROLES.find((r) => r.key === u.role) || ROLES[1]
                  return (
                    <div key={u.id} className="flex flex-wrap items-center gap-3 rounded-xl border border-border/60 p-3 transition hover:bg-accent/40">
                      <Avatar className="h-10 w-10 ring-2 ring-primary/10">
                        <AvatarImage src={u.avatar || `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(u.name)}`} />
                        <AvatarFallback className="bg-gradient-to-br from-red-500 to-orange-500 text-xs font-bold text-white">{u.name.slice(0, 2)}</AvatarFallback>
                      </Avatar>
                      <div className="min-w-[140px] flex-1">
                        <p className="flex items-center gap-1.5 text-sm font-semibold">{u.name} {u.twoFA && <Lock className="h-3 w-3 text-emerald-500" />}</p>
                        <p className="truncate text-xs text-muted-foreground">{u.email}</p>
                      </div>
                      <Badge variant="outline" className={`text-xs ring-1 ring-inset ${role.badge}`}>
                        <span className={`mr-1 h-1.5 w-1.5 rounded-full bg-gradient-to-br ${role.color}`} />
                        {u.role}
                      </Badge>
                      <StatusPill status={u.status} />
                      <div className="hidden items-center gap-1 text-xs text-muted-foreground sm:flex">
                        <Clock className="h-3 w-3" />
                        {u.lastLogin ? new Date(u.lastLogin).toLocaleDateString() : 'never'}
                      </div>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon" className="h-8 w-8"><MoreHorizontal className="h-4 w-4" /></Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => toast.info(`Editing role for ${u.name}`)}><Pencil className="mr-2 h-4 w-4" /> Edit role</DropdownMenuItem>
                          <DropdownMenuItem onClick={() => toast.success(`Password reset link sent to ${u.email}`)}><KeyRound className="mr-2 h-4 w-4" /> Reset password</DropdownMenuItem>
                          <DropdownMenuItem onClick={() => setPermRole(u.role)}><Shield className="mr-2 h-4 w-4" /> View permissions</DropdownMenuItem>
                          <DropdownMenuItem className="text-red-600 focus:text-red-600" onClick={() => toast.error(`${u.status === 'active' ? 'Suspended' : 'Reactivated'} ${u.name}`)}>
                            <Ban className="mr-2 h-4 w-4" /> {u.status === 'active' ? 'Suspend' : 'Reactivate'}
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  )
                })}
              </div>
            </div>
          )}
        </GlassCard>

        {/* Roles & permissions */}
        <GlassCard className="lg:col-span-2">
          <div className="flex items-center justify-between border-b border-border/60 px-5 py-4">
            <div>
              <p className="text-sm font-semibold">Roles & Permissions</p>
              <p className="text-xs text-muted-foreground">{ROLES.length} role templates</p>
            </div>
            <Button variant="outline" size="sm" onClick={() => toast.info('Open new role wizard')}><Sparkles className="mr-1.5 h-3.5 w-3.5" /> Add Role</Button>
          </div>
          <ScrollArea className="max-h-[640px]">
            <div className="space-y-2 p-3">
              {ROLES.map((r) => {
                const count = users.filter((u) => u.role === r.key).length
                return (
                  <div key={r.key} className="flex items-center gap-3 rounded-xl border border-border/60 p-3 transition hover:bg-accent/40">
                    <div className={`flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br ${r.color} text-white shadow-md`}>
                      <r.icon className="h-5 w-5" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-semibold">{r.key}</p>
                      <p className="text-xs text-muted-foreground">{count} member{count === 1 ? '' : 's'}</p>
                    </div>
                    <Button variant="ghost" size="sm" onClick={() => setPermRole(r.key)}>Manage</Button>
                  </div>
                )
              })}
            </div>
          </ScrollArea>
        </GlassCard>
      </div>

      {/* Invite dialog */}
      <Dialog open={inviteOpen} onOpenChange={setInviteOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Invite team member</DialogTitle>
          </DialogHeader>
          <InviteForm onCancel={() => setInviteOpen(false)} />
        </DialogContent>
      </Dialog>

      {/* Permissions dialog */}
      <Dialog open={!!permRole} onOpenChange={(o) => !o && setPermRole(null)}>
        <DialogContent className="max-h-[90vh] max-w-3xl overflow-y-auto pb-scroll">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Shield className="h-5 w-5 text-primary" /> Permissions · {permRole}
            </DialogTitle>
          </DialogHeader>
          {permRole && <PermissionsMatrix role={permRole} />}
        </DialogContent>
      </Dialog>
    </div>
  )
}

function InviteForm({ onCancel }: { onCancel: () => void }) {
  const [email, setEmail] = useState('')
  const [name, setName] = useState('')
  const [role, setRole] = useState('Support')
  const submit = () => {
    if (!email || !/\S+@\S+\.\S+/.test(email)) { toast.error('Enter a valid email'); return }
    toast.success(`Invitation sent to ${email}`, { description: `Role: ${role}` })
    onCancel()
  }
  return (
    <div className="space-y-4">
      <div className="space-y-1.5">
        <Label>Full Name</Label>
        <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Jane Cooper" />
      </div>
      <div className="space-y-1.5">
        <Label>Email *</Label>
        <Input value={email} onChange={(e) => setEmail(e.target.value)} placeholder="jane@playbeat.digital" />
      </div>
      <div className="space-y-1.5">
        <Label>Role</Label>
        <Select value={role} onValueChange={setRole}>
          <SelectTrigger><SelectValue /></SelectTrigger>
          <SelectContent>
            {ROLES.map((r) => <SelectItem key={r.key} value={r.key}>{r.key}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>
      <div className="flex items-center justify-between rounded-xl border border-border bg-muted/30 p-3">
        <div className="flex items-center gap-2">
          <Lock className="h-4 w-4 text-emerald-500" />
          <div><p className="text-sm font-medium">Require 2FA</p><p className="text-xs text-muted-foreground">Enforce on first login</p></div>
        </div>
        <Switch defaultChecked />
      </div>
      <DialogFooter>
        <Button variant="outline" onClick={onCancel}>Cancel</Button>
        <Button className="pb-gradient-brand" onClick={submit}><Mail className="mr-2 h-4 w-4" /> Send Invite</Button>
      </DialogFooter>
    </div>
  )
}

function PermissionsMatrix({ role }: { role: string }) {
  const isSuper = role === 'Super Admin'
  const [perms, setPerms] = useState(() => defaultPerms(role))
  const toggle = (m: string, p: typeof PERMS[number]) => {
    if (isSuper) return
    setPerms((cur) => ({ ...cur, [m]: { ...cur[m], [p]: !cur[m][p] } }))
  }
  return (
    <div className="space-y-4">
      {isSuper && (
        <div className="rounded-xl border border-red-500/30 bg-red-500/5 p-3 text-xs text-red-600 dark:text-red-400">
          <ShieldCheck className="mr-1.5 inline h-4 w-4" /> Super Admin has full access to all modules and permissions are locked.
        </div>
      )}
      <div className="overflow-x-auto pb-scroll rounded-xl border border-border">
        <table className="w-full min-w-[480px] text-sm">
          <thead>
            <tr className="border-b border-border bg-muted/40 text-left text-xs uppercase tracking-wide text-muted-foreground">
              <th className="px-4 py-2.5 font-semibold">Module</th>
              {PERMS.map((p) => <th key={p} className="px-4 py-2.5 text-center font-semibold capitalize">{p}</th>)}
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {MODULES.map((m) => (
              <tr key={m} className="hover:bg-accent/30">
                <td className="px-4 py-2.5 font-medium">{m}</td>
                {PERMS.map((p) => (
                  <td key={p} className="px-4 py-2.5 text-center">
                    <Checkbox
                      checked={perms[m][p]}
                      disabled={isSuper}
                      onCheckedChange={() => toggle(m, p)}
                      className={isSuper ? 'opacity-60' : ''}
                    />
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <DialogFooter>
        <Button variant="outline" onClick={() => setPerms(defaultPerms(role))} disabled={isSuper}>Reset</Button>
        <Button className="pb-gradient-brand" disabled={isSuper} onClick={() => toast.success('Permissions updated', { description: `${role} role saved` })}>
          <CheckCircle2 className="mr-2 h-4 w-4" /> Save Permissions
        </Button>
      </DialogFooter>
    </div>
  )
}

function StatBox({ label, value, icon: Icon, color }: any) {
  return (
    <div className="pb-glass flex items-center gap-3 rounded-2xl p-4 pb-lift">
      <div className={`flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br ${color} text-white`}><Icon className="h-5 w-5" /></div>
      <div><p className="text-xl font-bold pb-count">{value}</p><p className="text-xs text-muted-foreground">{label}</p></div>
    </div>
  )
}
