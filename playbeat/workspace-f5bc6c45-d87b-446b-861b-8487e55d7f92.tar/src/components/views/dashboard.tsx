'use client'

import { useQuery } from '@tanstack/react-query'
import { GlassCard, SectionHeader, StatCard, StatusPill, TableSkeleton, EmptyState } from '@/components/shared'
import { ChartCard, GradientAreaChart, DualLineChart, DonutChart, GradientBarChart, COLORS } from '@/components/charts'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { ScrollArea } from '@/components/ui/scroll-area'
import {
  DollarSign, ShoppingBag, Users, TrendingUp, Package, AlertTriangle, Ticket, Star, Activity, Eye, RefreshCw, Download, ArrowRight,
} from 'lucide-react'
import { useState } from 'react'
import { useNav } from '@/lib/nav-store'
import { motion } from 'framer-motion'
import { formatPKR, formatPKRCompact } from '@/lib/currency'

type Dashboard = {
  stats: Record<string, number>
  deltas: Record<string, number>
  topProducts: any[]
  bestCategories: { name: string; revenue: number; orders: number }[]
  inventoryAlerts: any[]
  revenueSeries: { date: string; revenue: number; orders: number }[]
  monthlySeries: { label: string; revenue: number; orders: number }[]
  paymentDistribution: { name: string; value: number }[]
  orderStatusDistribution: { name: string; value: number }[]
  recentOrders: any[]
}

export function DashboardView() {
  const { setView } = useNav()
  const [range, setRange] = useState<'daily' | 'weekly' | 'monthly' | 'yearly'>('monthly')
  const { data, isLoading, refetch, isFetching } = useQuery<Dashboard>({
    queryKey: ['dashboard'],
    queryFn: () => fetch('/api/dashboard').then((r) => r.json()),
    refetchInterval: 30000,
  })

  const stats = data?.stats
  const deltas = data?.deltas

  return (
    <div className="space-y-6">
      <SectionHeader
        title="Dashboard"
        subtitle="Real-time overview of your digital marketplace performance"
        icon={Activity}
        action={
          <>
            <Button variant="outline" size="sm" onClick={() => refetch()} disabled={isFetching}>
              <RefreshCw className={`mr-2 h-4 w-4 ${isFetching ? 'animate-spin' : ''}`} /> Refresh
            </Button>
            <Button size="sm" className="pb-gradient-brand" onClick={() => setView('reports')}>
              <Download className="mr-2 h-4 w-4" /> Export
            </Button>
          </>
        }
      />

      {/* Live visitors banner */}
      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="pb-glass relative overflow-hidden rounded-2xl p-5">
        <div className="absolute inset-0 bg-gradient-to-r from-red-500/10 via-orange-500/10 to-blue-500/10" />
        <div className="relative flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <span className="relative flex h-3 w-3">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-75" />
              <span className="relative inline-flex h-3 w-3 rounded-full bg-emerald-500" />
            </span>
            <div>
              <p className="text-sm font-semibold">Live Visitors</p>
              <p className="text-xs text-muted-foreground">Real-time active users on your store</p>
            </div>
          </div>
          <div className="flex items-center gap-6">
            <div className="text-right">
              <p className="text-3xl font-bold pb-count text-emerald-500">{stats?.liveVisitors ?? '—'}</p>
              <p className="text-xs text-muted-foreground">online now</p>
            </div>
            <div className="hidden h-12 w-px bg-border sm:block" />
            <div className="text-right">
              <p className="text-2xl font-bold pb-count">{stats?.conversionRate ?? '—'}%</p>
              <p className="text-xs text-muted-foreground">conversion rate</p>
            </div>
          </div>
        </div>
      </motion.div>

      {/* Stat cards */}
      {isLoading || !stats ? (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
          {Array.from({ length: 8 }).map((_, i) => <div key={i} className="h-32 rounded-2xl bg-muted pb-shimmer" />)}
        </div>
      ) : (
        <>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
            <StatCard title="Total Revenue" value={stats.totalRevenue} prefix="Rs " icon={DollarSign} delta={deltas.totalRevenue} deltaLabel="vs last month" gradient="bg-gradient-to-br from-red-500 to-orange-500" delay={0} />
            <StatCard title="Today's Revenue" value={stats.todaysRevenue} prefix="Rs " icon={TrendingUp} delta={deltas.todaysRevenue} deltaLabel="vs yesterday" gradient="bg-gradient-to-br from-orange-500 to-amber-500" delay={0.05} />
            <StatCard title="Monthly Revenue" value={stats.monthlyRevenue} prefix="Rs " icon={DollarSign} delta={deltas.monthlyRevenue} deltaLabel="vs last month" gradient="bg-gradient-to-br from-blue-500 to-cyan-500" delay={0.1} />
            <StatCard title="Total Orders" value={stats.totalOrders} icon={ShoppingBag} delta={deltas.totalOrders} deltaLabel="vs last month" gradient="bg-gradient-to-br from-violet-500 to-purple-500" delay={0.15} />
            <StatCard title="Pending Orders" value={stats.pendingOrders} icon={Package} gradient="bg-gradient-to-br from-amber-500 to-orange-500" delay={0.2} />
            <StatCard title="Completed Orders" value={stats.completedOrders} icon={ShoppingBag} gradient="bg-gradient-to-br from-emerald-500 to-teal-500" delay={0.25} />
            <StatCard title="Failed Orders" value={stats.failedOrders} icon={AlertTriangle} gradient="bg-gradient-to-br from-red-500 to-rose-500" delay={0.3} />
            <StatCard title="Active Users" value={stats.activeUsers} icon={Users} delta={deltas.activeUsers} deltaLabel="vs last month" gradient="bg-gradient-to-br from-blue-500 to-indigo-500" delay={0.35} />
          </div>

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
            <StatCard title="Registered Users" value={stats.registeredUsers} icon={Users} delta={deltas.registeredUsers} deltaLabel="vs last month" gradient="bg-gradient-to-br from-cyan-500 to-blue-500" delay={0} />
            <StatCard title="New Customers" value={stats.newCustomers} icon={Users} delta={deltas.newCustomers} deltaLabel="last 14 days" gradient="bg-gradient-to-br from-pink-500 to-rose-500" delay={0.05} />
            <StatCard title="Refund Requests" value={stats.refundRequests} icon={AlertTriangle} delta={deltas.refundRequests} deltaLabel="vs last month" gradient="bg-gradient-to-br from-orange-500 to-red-500" delay={0.1} />
            <StatCard title="Support Tickets" value={stats.supportTickets} icon={Ticket} delta={deltas.supportTickets} deltaLabel="open tickets" gradient="bg-gradient-to-br from-slate-500 to-slate-700" delay={0.15} />
          </div>
        </>
      )}

      {/* Charts row */}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        <ChartCard
          title="Revenue Analytics"
          subtitle="Track earnings over time"
          className="lg:col-span-2"
          action={
            <Tabs value={range} onValueChange={(v) => setRange(v as any)}>
              <TabsList className="h-8">
                <TabsTrigger value="daily" className="text-xs">Daily</TabsTrigger>
                <TabsTrigger value="weekly" className="text-xs">Weekly</TabsTrigger>
                <TabsTrigger value="monthly" className="text-xs">Monthly</TabsTrigger>
                <TabsTrigger value="yearly" className="text-xs">Yearly</TabsTrigger>
              </TabsList>
            </Tabs>
          }
        >
          {range === 'daily' && <GradientAreaChart data={data?.revenueSeries || []} dataKey="revenue" xKey="date" />}
          {range === 'monthly' && <DualLineChart data={data?.monthlySeries || []} />}
          {(range === 'weekly' || range === 'yearly') && (
            <GradientBarChart data={range === 'weekly' ? (data?.monthlySeries || []) : (data?.monthlySeries || [])} />
          )}
        </ChartCard>

        <ChartCard title="Order Status" subtitle="Distribution by status">
          {data?.orderStatusDistribution?.length ? (
            <DonutChart data={data.orderStatusDistribution} height={240} />
          ) : <TableSkeleton rows={4} cols={1} />}
        </ChartCard>
      </div>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        <ChartCard title="Payment Methods" subtitle="Revenue by gateway" className="lg:col-span-1">
          {data?.paymentDistribution?.length ? (
            <DonutChart data={data.paymentDistribution} height={240} />
          ) : <TableSkeleton rows={4} cols={1} />}
        </ChartCard>

        <ChartCard title="Best Categories" subtitle="Top performing product types" className="lg:col-span-2">
          {data?.bestCategories?.length ? (
            <GradientBarChart data={data.bestCategories.map((c) => ({ label: c.name, revenue: c.revenue }))} height={240} />
          ) : <TableSkeleton rows={4} cols={1} />}
        </ChartCard>
      </div>

      {/* Bottom row: top products, inventory, recent orders */}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        {/* Top products */}
        <GlassCard className="p-5">
          <div className="mb-4 flex items-center justify-between">
            <div>
              <p className="text-sm font-semibold">Top Selling Products</p>
              <p className="text-xs text-muted-foreground">Best performers this month</p>
            </div>
            <Button variant="ghost" size="sm" onClick={() => setView('products')}>View all <ArrowRight className="ml-1 h-3.5 w-3.5" /></Button>
          </div>
          <ScrollArea className="h-[300px] pr-2">
            <div className="space-y-3">
              {(data?.topProducts || []).map((p, i) => {
                const images = JSON.parse(p.images || '[]') as string[]
                return (
                  <div key={p.id} className="flex items-center gap-3">
                    <span className={`flex h-6 w-6 shrink-0 items-center justify-center rounded-md text-xs font-bold text-white ${i < 3 ? 'pb-gradient-brand' : 'bg-muted text-muted-foreground'}`}>{i + 1}</span>
                    <img src={images[0]} alt={p.name} className="h-10 w-10 rounded-lg object-cover ring-1 ring-border" />
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-medium">{p.name}</p>
                      <p className="text-xs text-muted-foreground">{p.type} · {p.salesCount} sales</p>
                    </div>
                    <p className="text-sm font-semibold text-emerald-600">{formatPKR(p.price)}</p>
                  </div>
                )
              })}
            </div>
          </ScrollArea>
        </GlassCard>

        {/* Inventory alerts */}
        <GlassCard className="p-5">
          <div className="mb-4 flex items-center justify-between">
            <div>
              <p className="text-sm font-semibold">Inventory Alerts</p>
              <p className="text-xs text-muted-foreground">Low & out-of-stock items</p>
            </div>
            <Button variant="ghost" size="sm" onClick={() => setView('inventory')}>Manage <ArrowRight className="ml-1 h-3.5 w-3.5" /></Button>
          </div>
          <ScrollArea className="h-[300px] pr-2">
            <div className="space-y-2">
              {(data?.inventoryAlerts || []).map((p) => (
                <div key={p.id} className="flex items-center gap-3 rounded-xl border border-border/60 p-2.5">
                  <div className={`flex h-9 w-9 items-center justify-center rounded-lg ${p.stock === 0 ? 'bg-red-500/10 text-red-500' : 'bg-amber-500/10 text-amber-500'}`}>
                    <AlertTriangle className="h-4 w-4" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-medium">{p.name}</p>
                    <p className="text-xs text-muted-foreground">{p.sku}</p>
                  </div>
                  <div className="text-right">
                    <p className={`text-sm font-bold ${p.stock === 0 ? 'text-red-500' : 'text-amber-500'}`}>{p.stock}</p>
                    <p className="text-[10px] text-muted-foreground">in stock</p>
                  </div>
                </div>
              ))}
              {(data?.inventoryAlerts || []).length === 0 && (
                <EmptyState icon={Package} title="All stocked up!" description="No inventory alerts." />
              )}
            </div>
          </ScrollArea>
        </GlassCard>

        {/* Recent orders */}
        <GlassCard className="p-5">
          <div className="mb-4 flex items-center justify-between">
            <div>
              <p className="text-sm font-semibold">Recent Orders</p>
              <p className="text-xs text-muted-foreground">Latest customer purchases</p>
            </div>
            <Button variant="ghost" size="sm" onClick={() => setView('orders')}>All orders <ArrowRight className="ml-1 h-3.5 w-3.5" /></Button>
          </div>
          <ScrollArea className="h-[300px] pr-2">
            <div className="space-y-2">
              {(data?.recentOrders || []).map((o) => (
                <div key={o.id} className="flex items-center gap-3 rounded-xl border border-border/60 p-2.5">
                  <div className="flex h-9 w-9 items-center justify-center rounded-lg pb-gradient-blue text-white">
                    <ShoppingBag className="h-4 w-4" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-semibold">{o.orderNumber}</p>
                    <p className="truncate text-xs text-muted-foreground">{o.customerName}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-bold">{formatPKR(o.total)}</p>
                    <StatusPill status={o.status} />
                  </div>
                </div>
              ))}
            </div>
          </ScrollArea>
        </GlassCard>
      </div>

      {/* Quick stats footer cards */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        {[
          { label: 'Total Products', value: stats?.totalProducts, icon: Package, color: 'from-violet-500 to-purple-500', view: 'products' as const },
          { label: 'Active Coupons', value: stats?.totalCoupons, icon: Ticket, color: 'from-orange-500 to-red-500', view: 'marketing' as const },
          { label: 'Pending Reviews', value: stats?.pendingReviews, icon: Star, color: 'from-amber-500 to-yellow-500', view: 'products' as const },
          { label: 'Available Licenses', value: stats?.licenseKeys, icon: Ticket, color: 'from-emerald-500 to-teal-500', view: 'inventory' as const },
        ].map((q) => (
          <button key={q.label} onClick={() => setView(q.view)} className="pb-glass flex items-center gap-3 rounded-2xl p-4 pb-lift text-left">
            <div className={`flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br ${q.color} text-white`}>
              <q.icon className="h-5 w-5" />
            </div>
            <div>
              <p className="text-xl font-bold pb-count">{q.value ?? '—'}</p>
              <p className="text-xs text-muted-foreground">{q.label}</p>
            </div>
          </button>
        ))}
      </div>
    </div>
  )
}
