'use client'

import { useQuery } from '@tanstack/react-query'
import { GlassCard, SectionHeader, StatCard, StatusPill, TableSkeleton, EmptyState } from '@/components/shared'
import { ChartCard, GradientBarChart, DonutChart } from '@/components/charts'
import { Area, AreaChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis, Legend } from 'recharts'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { ScrollArea } from '@/components/ui/scroll-area'
import {
  BarChart3, DollarSign, Receipt, Percent, TrendingUp, RefreshCcw, Download, FileText, FileSpreadsheet,
  Crown, ShoppingBag, CreditCard, Wallet, Boxes, ShieldCheck, Users, FileBarChart,
} from 'lucide-react'
import { formatPKR } from '@/lib/currency'
import { useState } from 'react'
import { toast } from 'sonner'

type Range = 'daily' | 'weekly' | 'monthly' | 'yearly'

type ReportData = {
  summary: {
    totalRevenue: number
    taxCollected: number
    totalDiscount: number
    refunds: number
    netRevenue: number
    totalOrders: number
    avgOrderValue: number
    activeCoupons: number
    couponUsage: number
  }
  series: { label: string; revenue: number; orders: number; tax: number }[]
  topSelling: { name: string; qty: number; revenue: number }[]
  customerStats: { name: string; email: string; orders: number; spent: number; status: string }[]
  byGateway: { gateway: string; revenue: number; count: number }[]
  refundsCount: number
  inventoryValue: number
}

const REPORT_TYPES = [
  { key: 'revenue', title: 'Revenue Report', desc: 'Sales, taxes, refunds and net revenue breakdown', icon: DollarSign, color: 'from-red-500 to-orange-500' },
  { key: 'sales', title: 'Sales Report', desc: 'Order volumes, conversion and channel performance', icon: ShoppingBag, color: 'from-orange-500 to-amber-500' },
  { key: 'tax', title: 'Tax Report', desc: 'Collected tax by region, period and gateway', icon: Receipt, color: 'from-blue-500 to-cyan-500' },
  { key: 'customer', title: 'Customer Report', desc: 'Acquisition, lifetime value and segmentation', icon: Users, color: 'from-cyan-500 to-teal-500' },
  { key: 'inventory', title: 'Inventory Report', desc: 'Stock value, turnover and low-stock alerts', icon: Boxes, color: 'from-emerald-500 to-green-500' },
  { key: 'refund', title: 'Refund Report', desc: 'Refunded transactions, reasons and ratios', icon: RefreshCcw, color: 'from-amber-500 to-yellow-500' },
  { key: 'payment', title: 'Payment Report', desc: 'Gateway distribution, fees and success rates', icon: CreditCard, color: 'from-pink-500 to-rose-500' },
  { key: 'finance', title: 'Finance Summary', desc: 'Wallet balances, payouts and gateways', icon: Wallet, color: 'from-slate-500 to-slate-700' },
]

export function ReportsView() {
  const [range, setRange] = useState<Range>('monthly')
  const { data, isLoading, refetch, isFetching } = useQuery<ReportData>({
    queryKey: ['reports', range],
    queryFn: () => fetch(`/api/reports?range=${range}`).then((r) => r.json()),
  })

  const summary = data?.summary
  const series = data?.series || []
  const topSelling = data?.topSelling || []
  const customerStats = data?.customerStats || []
  const byGateway = data?.byGateway || []

  // Custom dual line chart data with revenue + tax
  const revenueTaxSeries = series.map((s) => ({ label: s.label, revenue: s.revenue, tax: s.tax }))
  const barData = topSelling.map((t) => ({ label: t.name.length > 16 ? t.name.slice(0, 14) + '…' : t.name, revenue: Math.round(t.revenue) }))
  const gatewayDonut = byGateway.map((g) => ({ name: g.gateway, value: Math.round(g.revenue) }))

  const exportPdf = () => toast.info('Generating PDF report — you will be emailed when ready')
  const exportExcel = () => toast.info('Building Excel workbook with all report sheets...')
  const exportCsv = () => {
    if (!topSelling.length) { toast.error('No data to export yet'); return }
    const rows: (string | number)[][] = [['Product Name', 'Quantity Sold', 'Revenue (USD)']]
    for (const p of topSelling) rows.push([p.name, p.qty, p.revenue])
    const csv = rows.map((r) => r.map((c) => `"${c}"`).join(',')).join('\n')
    const url = URL.createObjectURL(new Blob([csv], { type: 'text/csv' }))
    const a = document.createElement('a'); a.href = url; a.download = `playbeat-top-selling-${range}.csv`; a.click()
    URL.revokeObjectURL(url)
    toast.success('CSV downloaded')
  }

  return (
    <div className="space-y-6">
      <SectionHeader
        title="Reports & Analytics"
        subtitle="Financial performance, sales breakdowns and exportable insights"
        icon={BarChart3}
        action={
          <>
            <Button variant="outline" size="sm" onClick={() => refetch()} disabled={isFetching}>
              <RefreshCcw className={`mr-2 h-4 w-4 ${isFetching ? 'animate-spin' : ''}`} /> Refresh
            </Button>
            <Button variant="outline" size="sm" onClick={exportPdf}><FileText className="mr-2 h-4 w-4" /> PDF</Button>
            <Button variant="outline" size="sm" onClick={exportExcel}><FileSpreadsheet className="mr-2 h-4 w-4" /> Excel</Button>
            <Button size="sm" className="pb-gradient-brand" onClick={exportCsv}><Download className="mr-2 h-4 w-4" /> Export CSV</Button>
          </>
        }
      />

      {/* Range tabs */}
      <Tabs value={range} onValueChange={(v) => setRange(v as Range)}>
        <TabsList className="h-auto">
          <TabsTrigger value="daily" className="text-xs">Daily</TabsTrigger>
          <TabsTrigger value="weekly" className="text-xs">Weekly</TabsTrigger>
          <TabsTrigger value="monthly" className="text-xs">Monthly</TabsTrigger>
          <TabsTrigger value="yearly" className="text-xs">Yearly</TabsTrigger>
        </TabsList>
      </Tabs>

      {/* Summary stats */}
      {isLoading || !summary ? (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6">
          {Array.from({ length: 6 }).map((_, i) => <div key={i} className="h-32 rounded-2xl bg-muted pb-shimmer" />)}
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6">
          <StatCard title="Total Revenue" value={summary.totalRevenue} prefix="Rs " icon={DollarSign} gradient="bg-gradient-to-br from-red-500 to-orange-500" delay={0} />
          <StatCard title="Net Revenue" value={summary.netRevenue} prefix="Rs " icon={TrendingUp} gradient="bg-gradient-to-br from-emerald-500 to-teal-500" delay={0.05} />
          <StatCard title="Tax Collected" value={summary.taxCollected} prefix="Rs " icon={Receipt} gradient="bg-gradient-to-br from-blue-500 to-cyan-500" delay={0.1} />
          <StatCard title="Total Discount" value={summary.totalDiscount} prefix="Rs " icon={Percent} gradient="bg-gradient-to-br from-orange-500 to-amber-500" delay={0.15} />
          <StatCard title="Avg Order Value" value={summary.avgOrderValue} prefix="Rs " icon={ShoppingBag} gradient="bg-gradient-to-br from-cyan-500 to-blue-500" delay={0.2} />
          <StatCard title="Refunds" value={summary.refunds} prefix="Rs " icon={RefreshCcw} gradient="bg-gradient-to-br from-pink-500 to-rose-500" delay={0.25} />
        </div>
      )}

      {/* Charts row */}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        <ChartCard
          title="Revenue & Tax"
          subtitle={`Trend over ${range} period`}
          className="lg:col-span-2"
          action={<Badge variant="outline" className="text-xs"><span className="mr-1 h-2 w-2 rounded-full bg-red-500" />Revenue · <span className="ml-1 mr-1 h-2 w-2 rounded-full bg-blue-500" />Tax</Badge>}
        >
          {isLoading ? <TableSkeleton rows={4} cols={1} /> : series.length ? (
            <RevenueTaxChart data={revenueTaxSeries} />
          ) : <EmptyState icon={BarChart3} title="No series data" />}
        </ChartCard>

        <ChartCard title="Payment Gateways" subtitle="Revenue by gateway">
          {isLoading ? <TableSkeleton rows={4} cols={1} /> : gatewayDonut.length ? (
            <DonutChart data={gatewayDonut} height={260} />
          ) : <EmptyState icon={CreditCard} title="No gateway data" />}
        </ChartCard>
      </div>

      {/* Top selling bar */}
      <ChartCard
        title="Top Selling Products"
        subtitle="Ranked by revenue contribution"
        action={<Button variant="outline" size="sm" onClick={exportCsv}><Download className="mr-2 h-3.5 w-3.5" /> Export</Button>}
      >
        {isLoading ? <TableSkeleton rows={4} cols={1} /> : barData.length ? (
          <GradientBarChart data={barData} dataKey="revenue" xKey="label" height={280} />
        ) : <EmptyState icon={Crown} title="No sales data" />}
      </ChartCard>

      {/* Tables: Top selling + Top customers */}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        <GlassCard className="overflow-hidden">
          <div className="flex items-center justify-between border-b border-border/60 px-5 py-4">
            <div>
              <p className="text-sm font-semibold">Top Selling Products</p>
              <p className="text-xs text-muted-foreground">By units sold & revenue</p>
            </div>
            <Button variant="ghost" size="sm" onClick={exportCsv}><Download className="mr-1.5 h-3.5 w-3.5" /> CSV</Button>
          </div>
          {isLoading ? <div className="p-5"><TableSkeleton rows={6} cols={3} /></div> : topSelling.length === 0 ? (
            <div className="p-5"><EmptyState icon={Crown} title="No top sellers yet" /></div>
          ) : (
            <div className="max-h-96 overflow-y-auto pb-scroll">
              <table className="w-full text-sm">
                <thead className="sticky top-0 bg-background/95 backdrop-blur">
                  <tr className="border-b border-border text-left text-xs uppercase tracking-wide text-muted-foreground">
                    <th className="px-5 py-2.5 font-semibold">#</th>
                    <th className="px-5 py-2.5 font-semibold">Product</th>
                    <th className="px-5 py-2.5 text-right font-semibold">Qty</th>
                    <th className="px-5 py-2.5 text-right font-semibold">Revenue</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {topSelling.map((p, i) => (
                    <tr key={p.name + i} className="hover:bg-accent/40">
                      <td className="px-5 py-3">
                        <span className={`flex h-7 w-7 items-center justify-center rounded-md text-xs font-bold text-white ${i < 3 ? 'pb-gradient-brand' : 'bg-muted text-muted-foreground'}`}>{i + 1}</span>
                      </td>
                      <td className="px-5 py-3 font-medium">{p.name}</td>
                      <td className="px-5 py-3 text-right tabular-nums">{p.qty}</td>
                      <td className="px-5 py-3 text-right font-semibold text-emerald-600">{formatPKR(p.revenue)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </GlassCard>

        <GlassCard className="overflow-hidden">
          <div className="flex items-center justify-between border-b border-border/60 px-5 py-4">
            <div>
              <p className="text-sm font-semibold">Top Customers</p>
              <p className="text-xs text-muted-foreground">Highest lifetime spend</p>
            </div>
            <Badge variant="secondary" className="text-xs">{customerStats.length} VIPs</Badge>
          </div>
          {isLoading ? <div className="p-5"><TableSkeleton rows={6} cols={3} /></div> : customerStats.length === 0 ? (
            <div className="p-5"><EmptyState icon={Users} title="No customer data" /></div>
          ) : (
            <div className="max-h-96 overflow-y-auto pb-scroll">
              <table className="w-full text-sm">
                <thead className="sticky top-0 bg-background/95 backdrop-blur">
                  <tr className="border-b border-border text-left text-xs uppercase tracking-wide text-muted-foreground">
                    <th className="px-5 py-2.5 font-semibold">Customer</th>
                    <th className="px-5 py-2.5 text-right font-semibold">Orders</th>
                    <th className="px-5 py-2.5 text-right font-semibold">Spent</th>
                    <th className="px-5 py-2.5 font-semibold">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {customerStats.map((c) => (
                    <tr key={c.email} className="hover:bg-accent/40">
                      <td className="px-5 py-3">
                        <div className="flex items-center gap-2.5">
                          <Avatar className="h-8 w-8 ring-1 ring-border">
                            <AvatarImage src={`https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(c.name)}`} />
                            <AvatarFallback className="bg-gradient-to-br from-red-500 to-orange-500 text-[10px] font-bold text-white">{c.name.slice(0, 2)}</AvatarFallback>
                          </Avatar>
                          <div className="min-w-0">
                            <p className="truncate font-medium">{c.name}</p>
                            <p className="truncate text-xs text-muted-foreground">{c.email}</p>
                          </div>
                        </div>
                      </td>
                      <td className="px-5 py-3 text-right tabular-nums">{c.orders}</td>
                      <td className="px-5 py-3 text-right font-semibold text-emerald-600">{formatPKR(c.spent)}</td>
                      <td className="px-5 py-3"><StatusPill status={c.status} /></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </GlassCard>
      </div>

      {/* Report types */}
      <div>
        <div className="mb-3 flex items-center gap-2">
          <FileBarChart className="h-4 w-4 text-muted-foreground" />
          <h2 className="text-sm font-semibold">Report Types</h2>
          <span className="text-xs text-muted-foreground">— pick a category to generate a detailed report</span>
        </div>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {REPORT_TYPES.map((r, i) => (
            <button
              key={r.key}
              onClick={() => toast.success(`Generating ${r.title}...`, { description: r.desc })}
              className="pb-glass group rounded-2xl p-5 pb-lift text-left transition hover:ring-2 hover:ring-primary/30"
              style={{ animationDelay: `${i * 40}ms` }}
            >
              <div className={`mb-3 inline-flex h-11 w-11 items-center justify-center rounded-xl bg-gradient-to-br ${r.color} text-white shadow-lg`}>
                <r.icon className="h-5 w-5" />
              </div>
              <p className="font-semibold text-foreground">{r.title}</p>
              <p className="mt-1 text-xs text-muted-foreground">{r.desc}</p>
              <div className="mt-3 flex items-center justify-between">
                <span className="text-xs font-medium text-primary">Generate</span>
                <Download className="h-3.5 w-3.5 text-primary transition group-hover:translate-y-0.5" />
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Inventory + refunds footer */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <GlassCard className="flex items-center gap-3 p-5">
          <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-gradient-to-br from-emerald-500 to-green-500 text-white"><Boxes className="h-5 w-5" /></div>
          <div><p className="text-2xl font-bold pb-count">{formatPKR(data?.inventoryValue ?? 0)}</p><p className="text-xs text-muted-foreground">Inventory Value</p></div>
        </GlassCard>
        <GlassCard className="flex items-center gap-3 p-5">
          <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-gradient-to-br from-orange-500 to-amber-500 text-white"><RefreshCcw className="h-5 w-5" /></div>
          <div><p className="text-2xl font-bold pb-count">{data?.refundsCount ?? 0}</p><p className="text-xs text-muted-foreground">Refund Transactions</p></div>
        </GlassCard>
        <GlassCard className="flex items-center gap-3 p-5">
          <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-gradient-to-br from-blue-500 to-cyan-500 text-white"><ShieldCheck className="h-5 w-5" /></div>
          <div><p className="text-2xl font-bold pb-count">{summary?.activeCoupons ?? 0}</p><p className="text-xs text-muted-foreground">Active Coupons · {summary?.couponUsage ?? 0} uses</p></div>
        </GlassCard>
      </div>
    </div>
  )
}

/* Local chart: revenue + tax dual area */
function RevenueTaxChart({ data }: { data: { label: string; revenue: number; tax: number }[] }) {
  return (
    <ResponsiveContainer width="100%" height={280}>
      <AreaChart data={data} margin={{ top: 8, right: 8, left: -16, bottom: 0 }}>
        <defs>
          <linearGradient id="grad-rev" x1="0" y1="0" x2="0" y2="1">
            <stop offset="5%" stopColor="#ef4444" stopOpacity={0.4} />
            <stop offset="95%" stopColor="#ef4444" stopOpacity={0} />
          </linearGradient>
          <linearGradient id="grad-tax" x1="0" y1="0" x2="0" y2="1">
            <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.35} />
            <stop offset="95%" stopColor="#3b82f6" stopOpacity={0} />
          </linearGradient>
        </defs>
        <CartesianGrid strokeDasharray="3 3" stroke="rgba(148,163,184,0.18)" vertical={false} />
        <XAxis dataKey="label" tick={{ fontSize: 11, fill: 'var(--muted-foreground)' }} tickLine={false} axisLine={false} />
        <YAxis tick={{ fontSize: 11, fill: 'var(--muted-foreground)' }} tickLine={false} axisLine={false} width={48} />
        <Tooltip contentStyle={{ background: 'var(--popover)', border: '1px solid var(--border)', borderRadius: 12, fontSize: 12 }} />
        <Legend wrapperStyle={{ fontSize: 12 }} />
        <Area type="monotone" dataKey="revenue" stroke="#ef4444" strokeWidth={2.5} fill="url(#grad-rev)" name="Revenue" dot={false} activeDot={{ r: 5 }} />
        <Area type="monotone" dataKey="tax" stroke="#3b82f6" strokeWidth={2.5} fill="url(#grad-tax)" name="Tax" dot={false} activeDot={{ r: 4 }} />
      </AreaChart>
    </ResponsiveContainer>
  )
}
