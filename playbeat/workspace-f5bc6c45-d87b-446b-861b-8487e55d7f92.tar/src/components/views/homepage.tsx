'use client'

import {
  DndContext, DragOverlay, PointerSensor, useSensor, useSensors, closestCenter,
  type DragStartEvent, type DragEndEvent,
} from '@dnd-kit/core'
import {
  SortableContext, useSortable, verticalListSortingStrategy, arrayMove,
} from '@dnd-kit/sortable'
import { CSS } from '@dnd-kit/utilities'
import { GlassCard, SectionHeader } from '@/components/shared'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Switch } from '@/components/ui/switch'
import { Badge } from '@/components/ui/badge'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog'
import { ScrollArea } from '@/components/ui/scroll-area'
import { cn } from '@/lib/utils'
import {
  LayoutTemplate, Monitor, Tablet, Smartphone, Eye, Save, Upload, GripVertical, Pencil,
  Image as ImageIcon, Layers, Flame, Trophy, Zap, Grid3x3, Quote, HelpCircle, Navigation,
  Sparkles, Bell, MousePointerClick, Trash2, Plus, X, Star,
} from 'lucide-react'
import { useMemo, useState } from 'react'
import { toast } from 'sonner'
import { motion } from 'framer-motion'

type SectionDef = {
  type: string
  label: string
  icon: any
  desc: string
  gradient: string
}

type EnabledSection = {
  id: string
  type: string
  label: string
  icon: any
  gradient: string
  visible: boolean
  // editable fields (generic)
  title?: string
  subtitle?: string
  buttonText?: string
  bgColor?: string
  imageUrl?: string
  productCount?: number
  items?: { q: string; a: string }[]
}

const PALETTE: SectionDef[] = [
  { type: 'hero', label: 'Hero Banner', icon: ImageIcon, desc: 'Large featured banner with CTA', gradient: 'from-red-500 to-orange-500' },
  { type: 'sliders', label: 'Sliders', icon: Layers, desc: 'Auto-rotating image carousel', gradient: 'from-blue-500 to-cyan-500' },
  { type: 'featured', label: 'Featured Products', icon: Star, desc: 'Highlighted product grid', gradient: 'from-orange-500 to-amber-500' },
  { type: 'trending', label: 'Trending', icon: Flame, desc: 'Hot products this week', gradient: 'from-red-500 to-rose-500' },
  { type: 'bestvalue', label: 'Best Value', icon: Trophy, desc: 'Top deals & bundles', gradient: 'from-emerald-500 to-teal-500' },
  { type: 'flash', label: 'Flash Deals', icon: Zap, desc: 'Time-limited offers', gradient: 'from-amber-500 to-yellow-500' },
  { type: 'categories', label: 'Categories', icon: Grid3x3, desc: 'Browse by category', gradient: 'from-blue-500 to-indigo-500' },
  { type: 'testimonials', label: 'Testimonials', icon: Quote, desc: 'Customer reviews', gradient: 'from-violet-500 to-purple-500' },
  { type: 'faq', label: 'FAQ', icon: HelpCircle, desc: 'Frequently asked questions', gradient: 'from-slate-500 to-slate-700' },
  { type: 'footer', label: 'Footer', icon: LayoutTemplate, desc: 'Site footer with links', gradient: 'from-slate-600 to-slate-800' },
  { type: 'navigation', label: 'Navigation', icon: Navigation, desc: 'Top menu bar', gradient: 'from-cyan-500 to-blue-500' },
  { type: 'promo', label: 'Promotional', icon: Sparkles, desc: 'Promo banner / strip', gradient: 'from-pink-500 to-rose-500' },
  { type: 'popups', label: 'Popups', icon: MousePointerClick, desc: 'Exit-intent & modal popups', gradient: 'from-orange-500 to-red-500' },
  { type: 'announcement', label: 'Announcement Bar', icon: Bell, desc: 'Top scrolling announcement', gradient: 'from-emerald-500 to-cyan-500' },
]

const DEFAULT_ENABLED: EnabledSection[] = [
  { id: 'sec-1', type: 'announcement', label: 'Announcement Bar', icon: Bell, gradient: 'from-emerald-500 to-cyan-500', visible: true, title: '🎉 Free shipping on orders over $50 — Limited time only!' },
  { id: 'sec-2', type: 'navigation', label: 'Navigation', icon: Navigation, gradient: 'from-cyan-500 to-blue-500', visible: true, title: 'Main Menu' },
  { id: 'sec-3', type: 'hero', label: 'Hero Banner', icon: ImageIcon, gradient: 'from-red-500 to-orange-500', visible: true, title: 'Mega Gaming Sale', subtitle: 'Up to 60% off top game keys & software', buttonText: 'Shop Now', bgColor: '#ef4444', imageUrl: '' },
  { id: 'sec-4', type: 'featured', label: 'Featured Products', icon: Star, gradient: 'from-orange-500 to-amber-500', visible: true, title: 'Featured', productCount: 8 },
  { id: 'sec-5', type: 'trending', label: 'Trending', icon: Flame, gradient: 'from-red-500 to-rose-500', visible: true, title: 'Trending Now', productCount: 6 },
  { id: 'sec-6', type: 'categories', label: 'Categories', icon: Grid3x3, gradient: 'from-blue-500 to-indigo-500', visible: true, title: 'Shop by Category' },
  { id: 'sec-7', type: 'faq', label: 'FAQ', icon: HelpCircle, gradient: 'from-slate-500 to-slate-700', visible: true, title: 'Frequently Asked Questions', items: [{ q: 'How do I receive my key?', a: 'Keys are emailed instantly after payment.' }, { q: 'Are keys legitimate?', a: 'Yes — all keys are sourced from authorized distributors.' }] },
  { id: 'sec-8', type: 'footer', label: 'Footer', icon: LayoutTemplate, gradient: 'from-slate-600 to-slate-800', visible: true, title: 'Playbeat.Digital' },
]

let counter = 100
const newId = () => `sec-${++counter}`

export function HomepageView() {
  const [device, setDevice] = useState<'desktop' | 'tablet' | 'mobile'>('desktop')
  const [sections, setSections] = useState<EnabledSection[]>(DEFAULT_ENABLED)
  const [editing, setEditing] = useState<EnabledSection | null>(null)
  const [activeId, setActiveId] = useState<string | null>(null)

  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 6 } }),
  )

  const paletteMap = useMemo(() => {
    const m: Record<string, SectionDef> = {}
    for (const p of PALETTE) m[p.type] = p
    return m
  }, [])

  const findDragSource = (id: string): 'palette' | 'canvas' | null => {
    if (id.startsWith('palette-')) return 'palette'
    if (sections.some((s) => s.id === id)) return 'canvas'
    return null
  }

  const onDragStart = (e: DragStartEvent) => setActiveId(String(e.active.id))

  const onDragEnd = (e: DragEndEvent) => {
    setActiveId(null)
    const { active, over } = e
    if (!over) return

    const activeIdStr = String(active.id)
    const overIdStr = String(over.id)
    const activeSrc = findDragSource(activeIdStr)
    const overSrc = findDragSource(overIdStr)

    // Palette → Canvas (drop onto an existing item or empty canvas)
    if (activeSrc === 'palette') {
      const type = activeIdStr.replace('palette-', '')
      const def = paletteMap[type]
      if (!def) return
      const newSection: EnabledSection = {
        id: newId(),
        type: def.type,
        label: def.label,
        icon: def.icon,
        gradient: def.gradient,
        visible: true,
        title: def.label,
      }
      if (overSrc === 'canvas') {
        const overIdx = sections.findIndex((s) => s.id === overIdStr)
        const next = [...sections]
        next.splice(overIdx + 1, 0, newSection)
        setSections(next)
        toast.success(`${def.label} added to homepage`)
      } else {
        // dropped outside canvas — append to end
        setSections([...sections, newSection])
        toast.success(`${def.label} added to bottom`)
      }
      return
    }

    // Canvas → Canvas (reorder)
    if (activeSrc === 'canvas' && overSrc === 'canvas' && activeIdStr !== overIdStr) {
      const oldIdx = sections.findIndex((s) => s.id === activeIdStr)
      const newIdx = sections.findIndex((s) => s.id === overIdStr)
      setSections(arrayMove(sections, oldIdx, newIdx))
      toast.success('Section reordered')
    }
  }

  const addFromPalette = (def: SectionDef) => {
    const newSection: EnabledSection = {
      id: newId(),
      type: def.type,
      label: def.label,
      icon: def.icon,
      gradient: def.gradient,
      visible: true,
      title: def.label,
    }
    setSections([...sections, newSection])
    toast.success(`${def.label} added to homepage`)
  }

  const toggleVisible = (id: string) => {
    setSections((s) => s.map((sec) => (sec.id === id ? { ...sec, visible: !sec.visible } : sec)))
  }

  const removeSection = (id: string) => {
    setSections((s) => s.filter((sec) => sec.id !== id))
    toast.success('Section removed')
  }

  const saveSection = (updated: EnabledSection) => {
    setSections((s) => s.map((sec) => (sec.id === updated.id ? updated : sec)))
    setEditing(null)
    toast.success('Section updated')
  }

  const deviceWidth = device === 'desktop' ? '100%' : device === 'tablet' ? '768px' : '375px'

  return (
    <div className="space-y-6">
      <SectionHeader
        title="Homepage Builder"
        subtitle="Drag, drop & edit every storefront section visually"
        icon={LayoutTemplate}
        action={
          <>
            <div className="flex items-center gap-1 rounded-lg border border-border bg-muted/40 p-1">
              {([
                { key: 'desktop', icon: Monitor },
                { key: 'tablet', icon: Tablet },
                { key: 'mobile', icon: Smartphone },
              ] as const).map((d) => (
                <button
                  key={d.key}
                  onClick={() => setDevice(d.key)}
                  className={cn(
                    'flex h-8 w-9 items-center justify-center rounded-md transition',
                    device === d.key ? 'pb-gradient-brand text-white shadow' : 'text-muted-foreground hover:text-foreground',
                  )}
                  title={`${d.key} preview`}
                >
                  <d.icon className="h-4 w-4" />
                </button>
              ))}
            </div>
            <Button size="sm" variant="outline" onClick={() => toast.info('Opening storefront preview...', { description: 'A live preview will open in a new tab.' })}>
              <Eye className="mr-2 h-4 w-4" /> Preview
            </Button>
            <Button size="sm" variant="outline" onClick={() => toast.success('Draft saved', { description: 'Your changes are saved as a draft.' })}>
              <Save className="mr-2 h-4 w-4" /> Save Draft
            </Button>
            <Button size="sm" className="pb-gradient-brand" onClick={() => toast.success('Homepage published!', { description: 'Changes are now live on the storefront.' })}>
              <Upload className="mr-2 h-4 w-4" /> Publish
            </Button>
          </>
        }
      />

      <DndContext sensors={sensors} collisionDetection={closestCenter} onDragStart={onDragStart} onDragEnd={onDragEnd}>
        <div className="grid grid-cols-1 gap-4 lg:grid-cols-[16rem_minmax(0,1fr)]">
          {/* LEFT: palette */}
          <div className="lg:sticky lg:top-4 lg:self-start">
            <GlassCard className="p-4">
              <div className="mb-3 flex items-center justify-between">
                <div>
                  <p className="text-sm font-semibold">Sections</p>
                  <p className="text-xs text-muted-foreground">Drag to canvas</p>
                </div>
                <Badge variant="secondary" className="text-xs">{PALETTE.length}</Badge>
              </div>
              <ScrollArea className="h-[calc(100vh-18rem)] pr-2">
                <div className="space-y-2">
                  {PALETTE.map((p) => (
                    <PaletteItem key={p.type} def={p} onAdd={() => addFromPalette(p)} />
                  ))}
                </div>
              </ScrollArea>
            </GlassCard>
          </div>

          {/* CENTER: canvas */}
          <div>
            <div className="mb-3 flex items-center justify-between">
              <p className="text-sm font-semibold">Canvas <span className="text-muted-foreground">· {sections.length} sections</span></p>
              <span className="text-xs text-muted-foreground capitalize">{device} view</span>
            </div>

            <div className="mx-auto transition-all duration-300" style={{ maxWidth: deviceWidth }}>
              <SortableContext items={sections.map((s) => s.id)} strategy={verticalListSortingStrategy}>
                <div className="space-y-3">
                  {sections.length === 0 && (
                    <GlassCard className="border-2 border-dashed p-12 text-center">
                      <LayoutTemplate className="mx-auto mb-3 h-10 w-10 text-muted-foreground" />
                      <p className="font-semibold">Your canvas is empty</p>
                      <p className="text-sm text-muted-foreground">Drag a section from the left to start building.</p>
                    </GlassCard>
                  )}
                  {sections.map((sec) => (
                    <SortableSection
                      key={sec.id}
                      section={sec}
                      onToggle={() => toggleVisible(sec.id)}
                      onEdit={() => setEditing(sec)}
                      onRemove={() => removeSection(sec.id)}
                    />
                  ))}
                </div>
              </SortableContext>
            </div>
          </div>
        </div>

        <DragOverlay dropAnimation={{ duration: 200, easing: 'cubic-bezier(0.18, 0.67, 0.6, 1.22)' }}>
          {activeId ? <DragPreview id={activeId} sections={sections} paletteMap={paletteMap} /> : null}
        </DragOverlay>
      </DndContext>

      <Dialog open={!!editing} onOpenChange={(o) => !o && setEditing(null)}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto pb-scroll">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              {editing && <editing.icon className="h-4 w-4" />} Edit {editing?.label}
            </DialogTitle>
          </DialogHeader>
          {editing && <SectionEditor section={editing} onSave={saveSection} />}
        </DialogContent>
      </Dialog>
    </div>
  )
}

function PaletteItem({ def, onAdd }: { def: SectionDef; onAdd: () => void }) {
  const { attributes, listeners, setNodeRef, isDragging } = useSortable({
    id: `palette-${def.type}`,
    data: { type: 'palette', sectionType: def.type },
  })

  return (
    <div
      ref={setNodeRef}
      {...attributes}
      {...listeners}
      onClick={onAdd}
      className={cn(
        'group flex cursor-grab items-center gap-3 rounded-xl border border-border bg-background/60 p-2.5 transition hover:border-primary/40 hover:bg-accent/40 active:cursor-grabbing',
        isDragging && 'opacity-40',
      )}
      title={`Drag to canvas or click to add — ${def.label}`}
    >
      <div className={cn('flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-gradient-to-br text-white shadow', def.gradient)}>
        <def.icon className="h-4.5 w-4.5" />
      </div>
      <div className="min-w-0 flex-1">
        <p className="truncate text-sm font-medium">{def.label}</p>
        <p className="truncate text-[10px] text-muted-foreground">{def.desc}</p>
      </div>
      <Plus className="h-3.5 w-3.5 text-muted-foreground opacity-0 transition group-hover:opacity-100" />
    </div>
  )
}

function SortableSection({
  section, onToggle, onEdit, onRemove,
}: {
  section: EnabledSection
  onToggle: () => void
  onEdit: () => void
  onRemove: () => void
}) {
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({
    id: section.id,
    data: { type: 'canvas' },
  })
  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    zIndex: isDragging ? 50 : 'auto',
  }

  return (
    <motion.div
      ref={setNodeRef}
      style={style}
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: section.visible ? 1 : 0.55, y: 0 }}
      className={cn(
        'pb-glass rounded-2xl border-2 transition',
        isDragging ? 'border-primary shadow-xl ring-2 ring-primary/30' : 'border-border',
        !section.visible && 'opacity-60',
      )}
    >
      {/* Header row */}
      <div className="flex items-center gap-2 border-b border-border/60 px-3 py-2">
        <button
          {...attributes}
          {...listeners}
          className="cursor-grab rounded-md p-1 text-muted-foreground transition hover:bg-accent hover:text-foreground active:cursor-grabbing"
          title="Drag to reorder"
        >
          <GripVertical className="h-4 w-4" />
        </button>
        <div className={cn('flex h-7 w-7 items-center justify-center rounded-md bg-gradient-to-br text-white', section.gradient)}>
          <section.icon className="h-3.5 w-3.5" />
        </div>
        <p className="flex-1 truncate text-sm font-semibold">{section.label}</p>
        <button
          onClick={onToggle}
          className={cn('rounded-md p-1.5 transition hover:bg-accent', section.visible ? 'text-foreground' : 'text-muted-foreground')}
          title={section.visible ? 'Hide section' : 'Show section'}
        >
          <Eye className="h-4 w-4" />
        </button>
        <button onClick={onEdit} className="rounded-md p-1.5 text-muted-foreground transition hover:bg-accent hover:text-foreground" title="Edit">
          <Pencil className="h-4 w-4" />
        </button>
        <button onClick={onRemove} className="rounded-md p-1.5 text-muted-foreground transition hover:bg-red-500/10 hover:text-red-600" title="Remove">
          <Trash2 className="h-4 w-4" />
        </button>
      </div>

      {/* Live mini-preview */}
      <div className="p-3">
        <SectionPreview section={section} />
      </div>
    </motion.div>
  )
}

function SectionPreview({ section }: { section: EnabledSection }) {
  switch (section.type) {
    case 'hero':
      return (
        <div
          className="relative flex h-32 flex-col justify-center overflow-hidden rounded-xl p-5 text-white"
          style={{ background: `linear-gradient(135deg, ${section.bgColor || '#ef4444'}, #f97316)` }}
        >
          <div className="absolute -right-8 -top-8 h-28 w-28 rounded-full bg-white/10 blur-2xl" />
          <p className="text-lg font-bold">{section.title || 'Hero Banner'}</p>
          <p className="text-xs opacity-90">{section.subtitle || 'Subtitle goes here'}</p>
          {section.buttonText && <span className="mt-2 w-fit rounded-md bg-white/20 px-3 py-1 text-xs font-semibold">{section.buttonText}</span>}
        </div>
      )
    case 'announcement':
      return (
        <div className="flex h-9 items-center justify-center gap-2 rounded-md bg-gradient-to-r from-emerald-500 to-cyan-500 px-3 text-xs font-medium text-white">
          <Bell className="h-3 w-3" /> {section.title || 'Announcement text'}
        </div>
      )
    case 'navigation':
      return (
        <div className="flex items-center justify-between rounded-md border border-border bg-background/60 px-3 py-2">
          <div className="flex items-center gap-2">
            <div className="h-4 w-4 rounded pb-gradient-brand" />
            <span className="text-xs font-bold">Playbeat</span>
          </div>
          <div className="flex gap-2">
            {['Home', 'Games', 'Software', 'Deals'].map((l) => <span key={l} className="rounded px-2 py-0.5 text-[10px] text-muted-foreground">{l}</span>)}
          </div>
          <div className="h-4 w-4 rounded bg-muted" />
        </div>
      )
    case 'sliders':
    case 'promo':
      return (
        <div className="grid grid-cols-3 gap-2">
          {[0, 1, 2].map((i) => <div key={i} className={cn('h-20 rounded-lg bg-gradient-to-br', section.gradient, 'opacity-70')} />)}
        </div>
      )
    case 'featured':
    case 'trending':
    case 'bestvalue':
    case 'flash':
      return (
        <div>
          <p className="mb-2 text-xs font-semibold text-muted-foreground">{section.title || section.label} · {section.productCount || 6} products</p>
          <div className="grid grid-cols-4 gap-2 sm:grid-cols-6">
            {Array.from({ length: section.productCount || 6 }).slice(0, 6).map((_, i) => (
              <div key={i} className="aspect-square rounded-lg border border-border bg-muted/40">
                <div className={cn('h-2/3 rounded-t-lg bg-gradient-to-br opacity-60', section.gradient)} />
              </div>
            ))}
          </div>
        </div>
      )
    case 'categories':
      return (
        <div>
          <p className="mb-2 text-xs font-semibold text-muted-foreground">{section.title || 'Categories'}</p>
          <div className="flex flex-wrap gap-2">
            {['Games', 'Gift Cards', 'Software', 'AI Tools', 'Subscriptions', 'Accounts'].map((c) => (
              <span key={c} className="rounded-full border border-border bg-background/60 px-3 py-1 text-xs">{c}</span>
            ))}
          </div>
        </div>
      )
    case 'testimonials':
      return (
        <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
          {['"Fast delivery, great prices!"', '"Best place for game keys."'].map((t, i) => (
            <div key={i} className="rounded-lg border border-border p-2 text-xs">
              <p className="text-muted-foreground">{t}</p>
              <div className="mt-1 flex items-center gap-1">
                <div className="h-4 w-4 rounded-full bg-gradient-to-br from-violet-500 to-purple-500" />
                <span className="text-[10px]">Customer</span>
              </div>
            </div>
          ))}
        </div>
      )
    case 'faq':
      return (
        <div className="space-y-1.5">
          {(section.items && section.items.length > 0 ? section.items : [{ q: 'Question 1?', a: 'Answer' }, { q: 'Question 2?', a: 'Answer' }]).slice(0, 3).map((it, i) => (
            <div key={i} className="rounded-md border border-border bg-background/40 p-2 text-xs">
              <p className="font-medium">{it.q}</p>
              <p className="text-muted-foreground">{it.a}</p>
            </div>
          ))}
        </div>
      )
    case 'footer':
      return (
        <div className="rounded-lg bg-slate-900 p-3 text-white">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-bold">{section.title || 'Playbeat.Digital'}</p>
              <p className="text-[10px] opacity-70">© 2025 — All rights reserved</p>
            </div>
            <div className="flex gap-3 text-[10px] opacity-80">
              {['About', 'Terms', 'Privacy', 'Support'].map((l) => <span key={l}>{l}</span>)}
            </div>
          </div>
        </div>
      )
    case 'popups':
      return (
        <div className="flex items-center gap-3 rounded-lg border-2 border-dashed border-border p-3">
          <MousePointerClick className="h-5 w-5 text-orange-500" />
          <div className="flex-1">
            <p className="text-xs font-semibold">Exit-intent popup</p>
            <p className="text-[10px] text-muted-foreground">Triggers when user tries to leave — offers 10% discount</p>
          </div>
        </div>
      )
    default:
      return <div className="rounded-lg border border-dashed border-border p-4 text-center text-xs text-muted-foreground">{section.label} preview</div>
  }
}

function SectionEditor({ section, onSave }: { section: EnabledSection; onSave: (s: EnabledSection) => void }) {
  const [form, setForm] = useState<EnabledSection>({ ...section })
  const set = (k: keyof EnabledSection, v: any) => setForm((f) => ({ ...f, [k]: v }))

  const renderFields = () => {
    switch (section.type) {
      case 'hero':
      case 'promo':
        return (
          <>
            <Field label="Title"><Input value={form.title || ''} onChange={(e) => set('title', e.target.value)} placeholder="Mega Sale" /></Field>
            <Field label="Subtitle"><Input value={form.subtitle || ''} onChange={(e) => set('subtitle', e.target.value)} placeholder="Up to 60% off everything" /></Field>
            <Field label="Button Text"><Input value={form.buttonText || ''} onChange={(e) => set('buttonText', e.target.value)} placeholder="Shop Now" /></Field>
            <Field label="Background Color"><div className="flex items-center gap-2"><input type="color" value={form.bgColor || '#ef4444'} onChange={(e) => set('bgColor', e.target.value)} className="h-9 w-12 rounded-md border border-border bg-transparent" /><Input value={form.bgColor || ''} onChange={(e) => set('bgColor', e.target.value)} /></div></Field>
            <Field label="Image URL (optional)"><Input value={form.imageUrl || ''} onChange={(e) => set('imageUrl', e.target.value)} placeholder="https://..." /></Field>
          </>
        )
      case 'announcement':
      case 'navigation':
        return <Field label="Text"><Input value={form.title || ''} onChange={(e) => set('title', e.target.value)} /></Field>
      case 'featured':
      case 'trending':
      case 'bestvalue':
      case 'flash':
        return (
          <>
            <Field label="Section Title"><Input value={form.title || ''} onChange={(e) => set('title', e.target.value)} /></Field>
            <Field label="Product Count">
              <Select value={String(form.productCount || 6)} onValueChange={(v) => set('productCount', Number(v))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{[4, 6, 8, 10, 12].map((n) => <SelectItem key={n} value={String(n)}>{n} products</SelectItem>)}</SelectContent>
              </Select>
            </Field>
          </>
        )
      case 'categories':
        return <Field label="Section Title"><Input value={form.title || ''} onChange={(e) => set('title', e.target.value)} /></Field>
      case 'faq':
        return (
          <Field label="Q&A Items">
            <div className="space-y-2">
              {(form.items || []).map((it, i) => (
                <div key={i} className="flex gap-2">
                  <Input placeholder="Question" value={it.q} onChange={(e) => { const items = [...(form.items || [])]; items[i] = { ...items[i], q: e.target.value }; set('items', items) }} />
                  <Input placeholder="Answer" value={it.a} onChange={(e) => { const items = [...(form.items || [])]; items[i] = { ...items[i], a: e.target.value }; set('items', items) }} />
                  <Button variant="ghost" size="icon" onClick={() => set('items', (form.items || []).filter((_, idx) => idx !== i))}><X className="h-4 w-4" /></Button>
                </div>
              ))}
              <Button variant="outline" size="sm" onClick={() => set('items', [...(form.items || []), { q: '', a: '' }])}><Plus className="mr-1 h-3.5 w-3.5" /> Add Q&A</Button>
            </div>
          </Field>
        )
      case 'footer':
        return <Field label="Footer Title"><Input value={form.title || ''} onChange={(e) => set('title', e.target.value)} /></Field>
      case 'testimonials':
        return <Field label="Section Title"><Input value={form.title || ''} onChange={(e) => set('title', e.target.value)} /></Field>
      case 'popups':
        return (
          <>
            <Field label="Popup Title"><Input value={form.title || ''} onChange={(e) => set('title', e.target.value)} /></Field>
            <Field label="Subtitle"><Textarea rows={3} value={form.subtitle || ''} onChange={(e) => set('subtitle', e.target.value)} /></Field>
          </>
        )
      default:
        return <Field label="Title"><Input value={form.title || ''} onChange={(e) => set('title', e.target.value)} /></Field>
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-2 rounded-xl border border-border bg-muted/30 p-3">
        <div className="flex items-center gap-2">
          <div className={cn('flex h-8 w-8 items-center justify-center rounded-md bg-gradient-to-br text-white', form.gradient)}>
            <form.icon className="h-4 w-4" />
          </div>
          <span className="text-sm font-medium">{form.label}</span>
        </div>
        <div className="flex items-center gap-2">
          <Label className="text-xs text-muted-foreground">Visible</Label>
          <Switch checked={form.visible} onCheckedChange={(v) => set('visible', v)} />
        </div>
      </div>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        {renderFields()}
      </div>

      <DialogFooter>
        <Button variant="outline" onClick={() => {}}>Cancel</Button>
        <Button className="pb-gradient-brand" onClick={() => onSave(form)}>Save Section</Button>
      </DialogFooter>
    </div>
  )
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="space-y-1.5">
      <Label>{label}</Label>
      {children}
    </div>
  )
}

function DragPreview({ id, sections, paletteMap }: { id: string; sections: EnabledSection[]; paletteMap: Record<string, SectionDef> }) {
  if (id.startsWith('palette-')) {
    const type = id.replace('palette-', '')
    const def = paletteMap[type]
    if (!def) return null
    return (
      <div className="flex w-56 items-center gap-3 rounded-xl border-2 border-primary bg-background p-3 shadow-2xl">
        <div className={cn('flex h-9 w-9 items-center justify-center rounded-lg bg-gradient-to-br text-white', def.gradient)}>
          <def.icon className="h-4.5 w-4.5" />
        </div>
        <div>
          <p className="text-sm font-semibold">{def.label}</p>
          <p className="text-[10px] text-muted-foreground">Drop to add</p>
        </div>
      </div>
    )
  }
  const sec = sections.find((s) => s.id === id)
  if (!sec) return null
  return (
    <div className="flex w-72 items-center gap-3 rounded-2xl border-2 border-primary bg-background p-3 shadow-2xl">
      <GripVertical className="h-4 w-4 text-muted-foreground" />
      <div className={cn('flex h-8 w-8 items-center justify-center rounded-md bg-gradient-to-br text-white', sec.gradient)}>
        <sec.icon className="h-4 w-4" />
      </div>
      <div className="flex-1">
        <p className="text-sm font-semibold">{sec.label}</p>
        <p className="text-[10px] text-muted-foreground">Moving section</p>
      </div>
    </div>
  )
}
