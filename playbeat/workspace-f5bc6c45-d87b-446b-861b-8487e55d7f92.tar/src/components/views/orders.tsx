'use client'

import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { GlassCard, SectionHeader, StatusPill, TableSkeleton, EmptyState } from '@/components/shared'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Separator } from '@/components/ui/separator'
import {
  ShoppingCart, Search, Download, Eye, RefreshCw, Truck, CheckCircle2, XCircle, Clock, FileText, ShieldAlert, Printer, Mail,
} from 'lucide-react'
import { useState } from 'react'
import { toast } from 'sonner'
import { formatPKR } from '@/lib/currency'

type Order = any

const STATUSES = ['pending', 'processing', 'completed', 'failed', 'cancelled', 'refunded']

export function OrdersView() {
  const qc = useQueryClient()
  const [status, setStatus] = useState('')
  const [paymentStatus, setPaymentStatus] = useState('')
  const [search, setSearch] = useState('')
  const [selected, setSelected] = useState<Order | null>(null)

  const qs = new URLSearchParams()
  if (status) qs.set('status', status)
  if (paymentStatus) qs.set('paymentStatus', paymentStatus)
  if (search) qs.set('search', search)

  const { data, isLoading } = useQuery<{ orders: Order[] }>({
    queryKey: ['orders', status, paymentStatus, search],
    queryFn: () => fetch(`/api/orders?${qs}`).then((r) => r.json()),
  })
  const orders = data?.orders || []

  const updateMut = useMutation({
    mutationFn: ({ id, body }: { id: string; body: any }) => fetch(`/api/orders/${id}`, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }).then((r) => r.json()),
    onSuccess: (updated) => {
      qc.invalidateQueries({ queryKey: ['orders'] })
      toast.success(`Order ${updated.order.orderNumber} updated`)
      setSelected(updated.order)
    },
  })

  const stats = {
    total: orders.length,
    pending: orders.filter((o) => o.status === 'pending').length,
    completed: orders.filter((o) => o.status === 'completed').length,
    revenue: orders.filter((o) => o.paymentStatus === 'paid').reduce((s, o) => s + o.total, 0),
  }

  return (
    <div className="space-y-6">
      <SectionHeader
        title="Order Management"
        subtitle="Process, fulfill & track all customer orders"
        icon={ShoppingCart}
        action={<Button variant="outline" size="sm" onClick={() => toast.info('Exporting full order report...')}><Download className="mr-2 h-4 w-4" /> Export</Button>}
      />

      {/* Mini stat row */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        {[
          { label: 'Total Orders', value: stats.total, icon: ShoppingCart, color: 'from-blue-500 to-cyan-500' },
          { label: 'Pending', value: stats.pending, icon: Clock, color: 'from-amber-500 to-orange-500' },
          { label: 'Completed', value: stats.completed, icon: CheckCircle2, color: 'from-emerald-500 to-teal-500' },
          { label: 'Revenue (paid)', value: formatPKR(stats.revenue), icon: Truck, color: 'from-red-500 to-orange-500' },
        ].map((s) => (
          <div key={s.label} className="pb-glass flex items-center gap-3 rounded-2xl p-4 pb-lift">
            <div className={`flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br ${s.color} text-white`}><s.icon className="h-5 w-5" /></div>
            <div><p className="text-xl font-bold pb-count">{s.value}</p><p className="text-xs text-muted-foreground">{s.label}</p></div>
          </div>
        ))}
      </div>

      {/* Filters */}
      <GlassCard className="p-4">
        <div className="flex flex-wrap items-center gap-3">
          <div className="relative min-w-[220px] flex-1">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input placeholder="Search order #, customer name, email..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-9" />
          </div>
          <Select value={status} onValueChange={(v) => setStatus(v === 'all' ? '' : v)}>
            <SelectTrigger className="w-[160px]"><SelectValue placeholder="Order status" /></SelectTrigger>
            <SelectContent><SelectItem value="all">All statuses</SelectItem>{STATUSES.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
          </Select>
          <Select value={paymentStatus} onValueChange={(v) => setPaymentStatus(v === 'all' ? '' : v)}>
            <SelectTrigger className="w-[160px]"><SelectValue placeholder="Payment" /></SelectTrigger>
            <SelectContent><SelectItem value="all">All payments</SelectItem><SelectItem value="paid">Paid</SelectItem><SelectItem value="unpaid">Unpaid</SelectItem><SelectItem value="refunded">Refunded</SelectItem></SelectContent>
          </Select>
        </div>
      </GlassCard>

      {/* Table */}
      <GlassCard className="overflow-hidden">
        {isLoading ? <div className="p-5"><TableSkeleton /></div> : orders.length === 0 ? (
          <div className="p-5"><EmptyState icon={ShoppingCart} title="No orders found" description="Adjust your filters to see orders." /></div>
        ) : (
          <div className="overflow-x-auto pb-scroll">
            <table className="w-full min-w-[900px] text-sm">
              <thead>
                <tr className="border-b border-border bg-muted/40 text-left text-xs uppercase tracking-wide text-muted-foreground">
                  <th className="px-4 py-3 font-semibold">Order</th>
                  <th className="px-4 py-3 font-semibold">Customer</th>
                  <th className="px-4 py-3 font-semibold">Date</th>
                  <th className="px-4 py-3 font-semibold">Payment</th>
                  <th className="px-4 py-3 font-semibold">Total</th>
                  <th className="px-4 py-3 font-semibold">Status</th>
                  <th className="px-4 py-3 text-right font-semibold">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {orders.map((o) => (
                  <tr key={o.id} className="transition hover:bg-accent/40">
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2">
                        {o.fraudScore > 60 && <ShieldAlert className="h-4 w-4 text-red-500" />}
                        <span className="font-semibold">{o.orderNumber}</span>
                      </div>
                      <span className="text-xs text-muted-foreground">{o.paymentMethod || '—'}</span>
                    </td>
                    <td className="px-4 py-3">
                      <p className="font-medium">{o.customerName}</p>
                      <p className="text-xs text-muted-foreground">{o.customerEmail}</p>
                    </td>
                    <td className="px-4 py-3 text-muted-foreground">{new Date(o.createdAt).toLocaleDateString('en', { month: 'short', day: 'numeric', year: 'numeric' })}</td>
                    <td className="px-4 py-3"><StatusPill status={o.paymentStatus} /></td>
                    <td className="px-4 py-3 font-semibold">{formatPKR(o.total)}</td>
                    <td className="px-4 py-3"><StatusPill status={o.status} /></td>
                    <td className="px-4 py-3 text-right">
                      <Button variant="ghost" size="sm" onClick={() => setSelected(o)}><Eye className="mr-1.5 h-4 w-4" /> View</Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </GlassCard>

      {/* Order detail dialog */}
      <Dialog open={!!selected} onOpenChange={(o) => !o && setSelected(null)}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto pb-scroll">
          {selected && <OrderDetail order={selected} onUpdate={(body) => updateMut.mutate({ id: selected.id, body })} loading={updateMut.isPending} />}
        </DialogContent>
      </Dialog>
    </div>
  )
}

function OrderDetail({ order, onUpdate, loading }: { order: Order; onUpdate: (b: any) => void; loading: boolean }) {
  const items = JSON.parse(order.items || '[]') as any[]
  const timeline = [
    { label: 'Order Placed', desc: order.customerName + ' placed the order', icon: ShoppingCart, done: true, time: new Date(order.createdAt).toLocaleString() },
    { label: 'Payment ' + (order.paymentStatus === 'paid' ? 'Confirmed' : 'Pending'), desc: order.paymentMethod + ' · ' + order.paymentStatus, icon: order.paymentStatus === 'paid' ? CheckCircle2 : Clock, done: order.paymentStatus === 'paid', time: new Date(order.createdAt).toLocaleString() },
    { label: 'Processing', desc: 'License keys assigned & delivered', icon: Truck, done: ['completed', 'refunded'].includes(order.status), time: '—' },
    { label: 'Completed', desc: 'Order fulfilled', icon: CheckCircle2, done: order.status === 'completed', time: order.status === 'completed' ? new Date(order.updatedAt).toLocaleString() : '—' },
  ]

  return (
    <div>
      <DialogHeader>
        <div className="flex items-center justify-between gap-3">
          <div>
            <DialogTitle className="flex items-center gap-2">
              Order {order.orderNumber}
              {order.fraudScore > 60 && <Badge variant="destructive" className="text-xs"><ShieldAlert className="mr-1 h-3 w-3" /> Fraud risk {order.fraudScore}%</Badge>}
            </DialogTitle>
            <p className="text-sm text-muted-foreground">{new Date(order.createdAt).toLocaleString()}</p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={() => toast.success('Invoice downloaded')}><Printer className="mr-1.5 h-4 w-4" /> Invoice</Button>
            <Button variant="outline" size="sm" onClick={() => toast.success('License keys resent to ' + order.customerEmail)}><Mail className="mr-1.5 h-4 w-4" /> Resend Keys</Button>
          </div>
        </div>
      </DialogHeader>

      {/* Customer + status */}
      <div className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-3">
        <div className="rounded-xl border border-border p-3">
          <p className="text-xs font-semibold uppercase text-muted-foreground">Customer</p>
          <p className="mt-1 text-sm font-medium">{order.customerName}</p>
          <p className="text-xs text-muted-foreground">{order.customerEmail}</p>
        </div>
        <div className="rounded-xl border border-border p-3">
          <p className="text-xs font-semibold uppercase text-muted-foreground">Payment</p>
          <p className="mt-1 text-sm font-medium">{order.paymentMethod || '—'}</p>
          <StatusPill status={order.paymentStatus} />
        </div>
        <div className="rounded-xl border border-border p-3">
          <p className="text-xs font-semibold uppercase text-muted-foreground">Order Status</p>
          <Select value={order.status} onValueChange={(v) => onUpdate({ status: v })}>
            <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
            <SelectContent>{STATUSES.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
          </Select>
        </div>
      </div>

      {/* Items */}
      <div className="mt-5">
        <p className="mb-2 text-sm font-semibold">Items</p>
        <div className="space-y-2">
          {items.map((it, i) => (
            <div key={i} className="flex items-center gap-3 rounded-xl border border-border p-3">
              {it.image && <img src={it.image} alt={it.name} className="h-10 w-10 rounded-lg object-cover ring-1 ring-border" />}
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-medium">{it.name}</p>
                <p className="text-xs text-muted-foreground">{it.type} · Qty {it.qty}</p>
              </div>
              <p className="text-sm font-semibold">{formatPKR(it.total, { decimals: true })}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Totals */}
      <div className="mt-4 flex justify-end">
        <div className="w-full max-w-xs space-y-1.5 rounded-xl border border-border p-4 text-sm">
          <div className="flex justify-between"><span className="text-muted-foreground">Subtotal</span><span>{formatPKR(order.subtotal)}</span></div>
          <div className="flex justify-between"><span className="text-muted-foreground">Tax</span><span>{formatPKR(order.tax)}</span></div>
          {order.discount > 0 && <div className="flex justify-between text-emerald-600"><span>Discount</span><span>-{formatPKR(order.discount)}</span></div>}
          <Separator className="my-2" />
          <div className="flex justify-between text-base font-bold"><span>Total</span><span className="pb-gradient-text">{formatPKR(order.total)}</span></div>
        </div>
      </div>

      {/* Timeline */}
      <div className="mt-6">
        <p className="mb-3 text-sm font-semibold">Order Timeline</p>
        <div className="relative space-y-5 pl-6">
          <div className="absolute left-[11px] top-1 h-full w-px bg-border" />
          {timeline.map((t, i) => (
            <div key={i} className="relative">
              <div className={`absolute -left-6 flex h-6 w-6 items-center justify-center rounded-full ${t.done ? 'pb-gradient-brand text-white' : 'bg-muted text-muted-foreground'} ring-4 ring-background`}>
                <t.icon className="h-3 w-3" />
              </div>
              <div>
                <p className={`text-sm font-medium ${t.done ? '' : 'text-muted-foreground'}`}>{t.label}</p>
                <p className="text-xs text-muted-foreground">{t.desc} · {t.time}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Actions */}
      <div className="mt-6 flex flex-wrap gap-2">
        <Button size="sm" className="pb-gradient-brand" disabled={loading} onClick={() => onUpdate({ status: 'completed', paymentStatus: 'paid' })}>
          <CheckCircle2 className="mr-2 h-4 w-4" /> Manual Approve
        </Button>
        <Button size="sm" variant="outline" disabled={loading} onClick={() => onUpdate({ status: 'refunded', paymentStatus: 'refunded' })}>
          <RefreshCw className="mr-2 h-4 w-4" /> Refund
        </Button>
        <Button size="sm" variant="outline" disabled={loading} onClick={() => onUpdate({ status: 'cancelled' })}>
          <XCircle className="mr-2 h-4 w-4" /> Cancel Order
        </Button>
      </div>
    </div>
  )
}
