'use client'

import { useQuery } from '@tanstack/react-query'
import { GlassCard, SectionHeader, StatusPill, TableSkeleton, EmptyState } from '@/components/shared'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import { Badge } from '@/components/ui/badge'
import { Slider } from '@/components/ui/slider'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs'
import { ScrollArea } from '@/components/ui/scroll-area'
import {
  ShieldCheck, Shield, Lock, KeyRound, Ban, Activity, Globe, Smartphone, Monitor, Tablet, Laptop, AlertTriangle, CheckCircle2,
  XCircle, Plus, Trash2, Eye, FileText, Wifi,
} from 'lucide-react'
import { useState } from 'react'
import { toast } from 'sonner'
import { RadialBarChart, RadialBar, ResponsiveContainer, PolarAngleAxis } from 'recharts'

type AuditLog = {
  id: string
  action: string
  module: string
  user: string
  ip: string
  details: string
  createdAt: string
}

const MODULES = ['Orders', 'Products', 'Customers', 'Payments', 'Settings', 'Security', 'Users', 'Inventory', 'Marketing', 'Auth']

const SECURITY_CHECKS = [
  { label: 'Two-Factor Authentication', ok: true },
  { label: 'Rate Limiting', ok: true },
  { label: 'Password Policy (12+ chars)', ok: true },
  { label: 'SSL Certificate', ok: true },
  { label: 'IP Whitelist', ok: false },
  { label: 'Backup Codes Generated', ok: true },
  { label: 'Session Timeout (30 min)', ok: true },
  { label: 'Login Notifications', ok: false },
  { label: 'Brute Force Protection', ok: true },
  { label: 'Web Application Firewall', ok: false },
]

const MOCK_SESSIONS = [
  { id: 'current', device: 'Chrome on macOS', icon: Laptop, ip: '203.135.42.18', location: 'Karachi, PK', lastActive: 'Active now', current: true },
  { id: '2', device: 'Safari on iPhone', icon: Smartphone, ip: '182.191.83.4', location: 'Lahore, PK', lastActive: '2 hours ago', current: false },
  { id: '3', device: 'Firefox on Windows', icon: Monitor, ip: '119.155.33.90', location: 'Islamabad, PK', lastActive: '1 day ago', current: false },
  { id: '4', device: 'Edge on Tablet', icon: Tablet, ip: '110.36.150.221', location: 'Dubai, UAE', lastActive: '3 days ago', current: false },
]

const MOCK_THREATS = [
  { id: '1', type: 'Brute Force Attempt', ip: '45.146.165.37', location: 'Unknown', severity: 'high', action: 'IP auto-blocked', time: '12 min ago' },
  { id: '2', type: 'Multiple Failed Logins', ip: '193.27.228.140', location: 'Russia', severity: 'medium', action: 'Rate limited', time: '47 min ago' },
  { id: '3', type: 'Suspicious Login', ip: '103.230.84.122', location: 'Hong Kong', severity: 'high', action: 'Challenge sent', time: '2 hours ago' },
  { id: '4', type: 'SQL Injection Pattern', ip: '198.51.100.42', location: 'Unknown', severity: 'urgent', action: 'Request blocked', time: '5 hours ago' },
  { id: '5', type: 'Unusual Geo Login', ip: '203.0.113.50', location: 'Nigeria', severity: 'low', action: 'Email alert sent', time: '8 hours ago' },
]

export function SecurityView() {
  const [tab, setTab] = useState('audit')
  const score = 87

  return (
    <div className="space-y-6">
      <SectionHeader
        title="Security Center"
        subtitle="Audit logs, sessions & threat protection"
        icon={ShieldCheck}
        action={
          <>
            <Button variant="outline" size="sm" onClick={() => toast.success('2FA setup wizard started')}><Lock className="mr-2 h-4 w-4" /> Enable 2FA</Button>
            <Button variant="outline" size="sm" onClick={() => toast.success('Backup codes generated — download to store safely')}><KeyRound className="mr-2 h-4 w-4" /> Backup Codes</Button>
            <Button size="sm" className="pb-gradient-brand" onClick={() => toast.info('Reviewing 3 connected apps...')}><Eye className="mr-2 h-4 w-4" /> Connected Apps</Button>
          </>
        }
      />

      {/* Security score banner */}
      <GlassCard className="overflow-hidden p-0">
        <div className="grid grid-cols-1 gap-4 p-5 lg:grid-cols-3">
          <div className="flex items-center gap-5">
            <div className="relative h-32 w-32 shrink-0">
              <ResponsiveContainer width="100%" height="100%">
                <RadialBarChart innerRadius="70%" outerRadius="100%" data={[{ value: score, fill: score >= 80 ? '#10b981' : score >= 60 ? '#f59e0b' : '#ef4444' }]} startAngle={90} endAngle={-270}>
                  <PolarAngleAxis type="number" domain={[0, 100]} tick={false} />
                  <RadialBar background={{ fill: 'rgba(148,163,184,0.18)' }} dataKey="value" cornerRadius={20} />
                </RadialBarChart>
              </ResponsiveContainer>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className="text-3xl font-bold pb-count text-foreground">{score}</span>
                <span className="text-xs text-muted-foreground">/ 100</span>
              </div>
            </div>
            <div>
              <p className="text-sm font-semibold">Security Score</p>
              <p className="text-xs text-muted-foreground">Based on best practices scan</p>
              <Badge variant="outline" className="mt-2 bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 ring-emerald-500/20">Good</Badge>
            </div>
          </div>
          <div className="lg:col-span-2">
            <p className="mb-3 text-sm font-semibold">Recommendations</p>
            <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
              {SECURITY_CHECKS.map((c) => (
                <div key={c.label} className="flex items-center gap-2 rounded-lg border border-border/60 px-3 py-2">
                  {c.ok ? <CheckCircle2 className="h-4 w-4 text-emerald-500" /> : <XCircle className="h-4 w-4 text-red-500" />}
                  <span className="flex-1 text-xs">{c.label}</span>
                  {!c.ok && <Button variant="ghost" size="sm" className="h-6 px-2 text-xs text-primary" onClick={() => toast.info(`Resolving: ${c.label}`)}>Fix</Button>}
                </div>
              ))}
            </div>
          </div>
        </div>
      </GlassCard>

      {/* Stats row */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatBox label="Active Sessions" value={MOCK_SESSIONS.length} icon={Activity} color="from-blue-500 to-cyan-500" />
        <StatBox label="Failed Logins (24h)" value={142} icon={AlertTriangle} color="from-orange-500 to-amber-500" />
        <StatBox label="Blocked IPs" value={38} icon={Ban} color="from-red-500 to-rose-500" />
        <StatBox label="Audit Events" value="2.4K" icon={FileText} color="from-emerald-500 to-teal-500" />
      </div>

      <Tabs value={tab} onValueChange={setTab}>
        <ScrollArea className="w-full whitespace-nowrap">
          <TabsList className="h-auto">
            <TabsTrigger value="audit" className="text-xs">Audit Logs</TabsTrigger>
            <TabsTrigger value="sessions" className="text-xs">Sessions</TabsTrigger>
            <TabsTrigger value="access" className="text-xs">Access Control</TabsTrigger>
            <TabsTrigger value="threats" className="text-xs">Threat Detection</TabsTrigger>
          </TabsList>
        </ScrollArea>

        <TabsContent value="audit" className="mt-4">
          <AuditLogsPanel />
        </TabsContent>
        <TabsContent value="sessions" className="mt-4">
          <SessionsPanel />
        </TabsContent>
        <TabsContent value="access" className="mt-4">
          <AccessControlPanel />
        </TabsContent>
        <TabsContent value="threats" className="mt-4">
          <ThreatsPanel />
        </TabsContent>
      </Tabs>
    </div>
  )
}

function AuditLogsPanel() {
  const [mod, setMod] = useState('')
  const qs = new URLSearchParams()
  if (mod) qs.set('module', mod)
  const { data, isLoading } = useQuery<{ logs: AuditLog[] }>({
    queryKey: ['audit-logs', mod],
    queryFn: () => fetch(`/api/audit-logs?${qs}`).then((r) => r.json()),
  })
  const logs = data?.logs || []

  return (
    <GlassCard className="overflow-hidden">
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-border/60 px-5 py-4">
        <div>
          <p className="text-sm font-semibold">Audit Logs</p>
          <p className="text-xs text-muted-foreground">Track every admin & system action</p>
        </div>
        <Select value={mod || 'all'} onValueChange={(v) => setMod(v === 'all' ? '' : v)}>
          <SelectTrigger className="w-[180px]"><SelectValue placeholder="Filter by module" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All modules</SelectItem>
            {MODULES.map((m) => <SelectItem key={m} value={m}>{m}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>
      {isLoading ? <div className="p-5"><TableSkeleton rows={8} cols={4} /></div> : logs.length === 0 ? (
        <div className="p-5"><EmptyState icon={FileText} title="No audit logs" description="Try a different module filter." /></div>
      ) : (
        <div className="max-h-[600px] overflow-y-auto pb-scroll">
          <table className="w-full min-w-[760px] text-sm">
            <thead className="sticky top-0 bg-background/95 backdrop-blur">
              <tr className="border-b border-border text-left text-xs uppercase tracking-wide text-muted-foreground">
                <th className="px-5 py-2.5 font-semibold">Action</th>
                <th className="px-5 py-2.5 font-semibold">Module</th>
                <th className="px-5 py-2.5 font-semibold">User</th>
                <th className="px-5 py-2.5 font-semibold">IP</th>
                <th className="px-5 py-2.5 font-semibold">Details</th>
                <th className="px-5 py-2.5 font-semibold">When</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {logs.map((l) => (
                <tr key={l.id} className="hover:bg-accent/40">
                  <td className="px-5 py-3"><Badge variant="outline" className="font-mono text-xs">{l.action}</Badge></td>
                  <td className="px-5 py-3"><Badge variant="secondary" className="text-xs">{l.module}</Badge></td>
                  <td className="px-5 py-3">{l.user}</td>
                  <td className="px-5 py-3 font-mono text-xs text-muted-foreground">{l.ip}</td>
                  <td className="px-5 py-3 text-xs text-muted-foreground">{l.details}</td>
                  <td className="px-5 py-3 text-xs text-muted-foreground">{relTime(l.createdAt)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </GlassCard>
  )
}

function SessionsPanel() {
  return (
    <GlassCard className="overflow-hidden">
      <div className="border-b border-border/60 px-5 py-4">
        <p className="text-sm font-semibold">Active Sessions</p>
        <p className="text-xs text-muted-foreground">Devices currently signed in to your account</p>
      </div>
      <div className="space-y-2 p-3">
        {MOCK_SESSIONS.map((s) => (
          <div key={s.id} className={`flex flex-wrap items-center gap-3 rounded-xl border p-3 transition hover:bg-accent/40 ${s.current ? 'border-emerald-500/30 bg-emerald-500/5' : 'border-border/60'}`}>
            <div className={`flex h-10 w-10 items-center justify-center rounded-xl text-white ${s.current ? 'bg-gradient-to-br from-emerald-500 to-teal-500' : 'bg-gradient-to-br from-slate-500 to-slate-700'}`}>
              <s.icon className="h-5 w-5" />
            </div>
            <div className="min-w-[140px] flex-1">
              <p className="flex items-center gap-1.5 text-sm font-semibold">
                {s.device}
                {s.current && <Badge variant="outline" className="bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 ring-emerald-500/20 text-[10px]">Current</Badge>}
              </p>
              <p className="text-xs text-muted-foreground">{s.ip} · {s.location}</p>
            </div>
            <span className="text-xs text-muted-foreground">{s.lastActive}</span>
            {!s.current && (
              <Button variant="outline" size="sm" onClick={() => toast.success(`Session ${s.device} revoked`)}>
                <Ban className="mr-1.5 h-3.5 w-3.5" /> Revoke
              </Button>
            )}
          </div>
        ))}
      </div>
    </GlassCard>
  )
}

function AccessControlPanel() {
  const [whitelistOn, setWhitelistOn] = useState(false)
  const [whitelist, setWhitelist] = useState<string[]>(['203.135.42.18', '182.191.83.4'])
  const [newIp, setNewIp] = useState('')
  const [rateOn, setRateOn] = useState(true)
  const [rate, setRate] = useState(60)
  const [blockDur, setBlockDur] = useState('30')
  const [emailAlerts, setEmailAlerts] = useState(true)
  const [newDeviceAlerts, setNewDeviceAlerts] = useState(true)

  const addIp = () => {
    if (!newIp || !/^\d+\.\d+\.\d+\.\d+$/.test(newIp)) { toast.error('Enter a valid IPv4 address'); return }
    if (whitelist.includes(newIp)) { toast.error('IP already whitelisted'); return }
    setWhitelist((w) => [...w, newIp]); setNewIp(''); toast.success('IP added to whitelist')
  }
  const removeIp = (ip: string) => { setWhitelist((w) => w.filter((x) => x !== ip)); toast.success('IP removed') }

  return (
    <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
      {/* IP Whitelist */}
      <GlassCard className="p-5">
        <div className="mb-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Globe className="h-4 w-4 text-blue-500" />
            <div><p className="text-sm font-semibold">IP Whitelist</p><p className="text-xs text-muted-foreground">Restrict admin access to known IPs</p></div>
          </div>
          <Switch checked={whitelistOn} onCheckedChange={(v) => { setWhitelistOn(v); toast.success(`IP whitelist ${v ? 'enabled' : 'disabled'}`) }} />
        </div>
        {!whitelistOn && <p className="mb-3 text-xs text-muted-foreground">Whitelist is currently disabled. Anyone with credentials can attempt login.</p>}
        <div className="mb-3 flex gap-2">
          <Input value={newIp} onChange={(e) => setNewIp(e.target.value)} placeholder="e.g. 203.135.42.18" disabled={!whitelistOn} />
          <Button size="sm" onClick={addIp} disabled={!whitelistOn}><Plus className="h-4 w-4" /></Button>
        </div>
        <div className="space-y-2">
          {whitelist.map((ip) => (
            <div key={ip} className="flex items-center justify-between rounded-lg border border-border/60 px-3 py-2">
              <span className="font-mono text-xs">{ip}</span>
              <Button variant="ghost" size="icon" className="h-7 w-7 text-red-500" onClick={() => removeIp(ip)}><Trash2 className="h-3.5 w-3.5" /></Button>
            </div>
          ))}
          {whitelist.length === 0 && <p className="text-xs text-muted-foreground">No IPs whitelisted.</p>}
        </div>
      </GlassCard>

      {/* Rate Limiting */}
      <GlassCard className="p-5">
        <div className="mb-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Wifi className="h-4 w-4 text-orange-500" />
            <div><p className="text-sm font-semibold">Rate Limiting</p><p className="text-xs text-muted-foreground">Throttle repeated failed attempts</p></div>
          </div>
          <Switch checked={rateOn} onCheckedChange={(v) => { setRateOn(v); toast.success(`Rate limiting ${v ? 'enabled' : 'disabled'}`) }} />
        </div>
        <div className="space-y-4">
          <div>
            <div className="mb-2 flex items-center justify-between text-xs">
              <span>Requests per minute</span>
              <span className="font-semibold tabular-nums">{rate}</span>
            </div>
            <Slider value={[rate]} min={10} max={300} step={10} onValueChange={(v) => setRate(v[0])} disabled={!rateOn} />
          </div>
          <div>
            <Label className="mb-2 block text-xs">Block duration</Label>
            <Select value={blockDur} onValueChange={setBlockDur} disabled={!rateOn}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="5">5 minutes</SelectItem>
                <SelectItem value="15">15 minutes</SelectItem>
                <SelectItem value="30">30 minutes</SelectItem>
                <SelectItem value="60">1 hour</SelectItem>
                <SelectItem value="1440">24 hours</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <Button variant="outline" size="sm" className="w-full" onClick={() => toast.success('Rate limit settings saved')}>Save Rate Limit</Button>
        </div>
      </GlassCard>

      {/* Login notifications */}
      <GlassCard className="p-5 lg:col-span-2">
        <div className="mb-4 flex items-center gap-2">
          <Shield className="h-4 w-4 text-emerald-500" />
          <div><p className="text-sm font-semibold">Login Notifications</p><p className="text-xs text-muted-foreground">Get alerted about suspicious access</p></div>
        </div>
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          <div className="flex items-center justify-between rounded-xl border border-border/60 p-3">
            <div><p className="text-sm font-medium">Email alerts</p><p className="text-xs text-muted-foreground">On every new login</p></div>
            <Switch checked={emailAlerts} onCheckedChange={(v) => { setEmailAlerts(v); toast.success(`Email alerts ${v ? 'on' : 'off'}`) }} />
          </div>
          <div className="flex items-center justify-between rounded-xl border border-border/60 p-3">
            <div><p className="text-sm font-medium">New device alerts</p><p className="text-xs text-muted-foreground">Notify on unfamiliar device</p></div>
            <Switch checked={newDeviceAlerts} onCheckedChange={(v) => { setNewDeviceAlerts(v); toast.success(`New device alerts ${v ? 'on' : 'off'}`) }} />
          </div>
        </div>
      </GlassCard>
    </div>
  )
}

function ThreatsPanel() {
  return (
    <GlassCard className="overflow-hidden">
      <div className="flex items-center justify-between border-b border-border/60 px-5 py-4">
        <div>
          <p className="text-sm font-semibold">Threat Detection</p>
          <p className="text-xs text-muted-foreground">Recent security events & automated responses</p>
        </div>
        <Badge variant="outline" className="bg-red-500/10 text-red-600 dark:text-red-400 ring-red-500/20">{MOCK_THREATS.length} flagged</Badge>
      </div>
      <div className="space-y-2 p-3">
        {MOCK_THREATS.map((t) => (
          <div key={t.id} className="flex flex-wrap items-center gap-3 rounded-xl border border-border/60 p-3 transition hover:bg-accent/40">
            <div className={`flex h-10 w-10 items-center justify-center rounded-xl text-white ${t.severity === 'urgent' ? 'bg-gradient-to-br from-red-600 to-rose-600' : t.severity === 'high' ? 'bg-gradient-to-br from-red-500 to-orange-500' : t.severity === 'medium' ? 'bg-gradient-to-br from-orange-500 to-amber-500' : 'bg-gradient-to-br from-blue-500 to-cyan-500'}`}>
              <AlertTriangle className="h-5 w-5" />
            </div>
            <div className="min-w-[160px] flex-1">
              <p className="text-sm font-semibold">{t.type}</p>
              <p className="text-xs text-muted-foreground">{t.ip} · {t.location}</p>
            </div>
            <StatusPill status={t.severity} />
            <div className="text-xs text-muted-foreground">
              <p>{t.action}</p>
              <p>{t.time}</p>
            </div>
            <Button variant="outline" size="sm" onClick={() => toast.success(`IP ${t.ip} blocked`)}><Ban className="mr-1.5 h-3.5 w-3.5" /> Block</Button>
          </div>
        ))}
      </div>
    </GlassCard>
  )
}

function StatBox({ label, value, icon: Icon, color }: any) {
  return (
    <div className="pb-glass flex items-center gap-3 rounded-2xl p-4 pb-lift">
      <div className={`flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br ${color} text-white`}><Icon className="h-5 w-5" /></div>
      <div><p className="text-xl font-bold pb-count">{value}</p><p className="text-xs text-muted-foreground">{label}</p></div>
    </div>
  )
}

function relTime(date: string | Date): string {
  const d = typeof date === 'string' ? new Date(date) : date
  const diff = Date.now() - d.getTime()
  const sec = Math.floor(diff / 1000)
  if (sec < 60) return `${sec}s ago`
  const min = Math.floor(sec / 60)
  if (min < 60) return `${min}m ago`
  const hr = Math.floor(min / 60)
  if (hr < 24) return `${hr}h ago`
  const day = Math.floor(hr / 24)
  if (day < 30) return `${day}d ago`
  return d.toLocaleDateString()
}
