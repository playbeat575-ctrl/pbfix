'use client'

import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { GlassCard, SectionHeader, StatusPill, TableSkeleton, EmptyState } from '@/components/shared'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Switch } from '@/components/ui/switch'
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { ScrollArea } from '@/components/ui/scroll-area'
import {
  CreditCard, DollarSign, CheckCircle2, RotateCcw, XCircle, Search, Building2, Wallet,
  HandCoins, ArrowRight, Landmark, Plus, Percent, TrendingUp,
} from 'lucide-react'
import { useMemo, useState } from 'react'
import { toast } from 'sonner'
import { useNav } from '@/lib/nav-store'
import { motion } from 'framer-motion'
import { formatPKR } from '@/lib/currency'

type Payment = {
  id: string
  orderId: string
  orderNumber: string
  gateway: string
  method: string | null
  amount: number
  currency: string
  status: string
  transactionId: string | null
  createdAt: string
}

const GATEWAYS = [
  { id: 'Stripe', desc: 'Cards, Apple Pay, Google Pay', icon: CreditCard, gradient: 'from-slate-700 to-slate-900', enabled: true },
  { id: 'PayPal', desc: 'PayPal balance & cards', icon: Wallet, gradient: 'from-blue-500 to-cyan-500', enabled: true },
  { id: 'JazzCash', desc: 'Mobile wallet — Pakistan', icon: HandCoins, gradient: 'from-red-500 to-orange-500', enabled: true },
  { id: 'Easypaisa', desc: 'Mobile wallet — Pakistan', icon: HandCoins, gradient: 'from-emerald-500 to-teal-500', enabled: true },
  { id: 'Bank Transfer', desc: 'Manual bank deposit', icon: Landmark, gradient: 'from-amber-500 to-yellow-500', enabled: false },
  { id: 'Manual', desc: 'Admin-approved payments', icon: Building2, gradient: 'from-slate-500 to-slate-600', enabled: false },
]

const PAYMENT_STATUSES = ['success', 'failed', 'refunded', 'pending']

const REFUND_REASONS = [
  'Customer request — duplicate order',
  'Product unavailable',
  'Fraudulent transaction detected',
  'Payment gateway error',
  'Customer changed mind',
  'Wrong product purchased',
]

// Mock withdrawal requests
const WITHDRAWALS = [
  { id: 'WD-2041', merchant: 'Playbeat Digital', amount: 4850.0, gateway: 'Stripe', status: 'pending', date: '2025-01-14' },
  { id: 'WD-2042', merchant: 'CDKeys Hub', amount: 1290.5, gateway: 'Bank Transfer', status: 'pending', date: '2025-01-13' },
  { id: 'WD-2043', merchant: 'GameStore PK', amount: 740.25, gateway: 'JazzCash', status: 'pending', date: '2025-01-12' },
  { id: 'WD-2044', merchant: 'SoftVault', amount: 2210.0, gateway: 'PayPal', status: 'pending', date: '2025-01-11' },
]

export function PaymentsView() {
  const qc = useQueryClient()
  const { setView } = useNav()
  const [gateway, setGateway] = useState('')
  const [status, setStatus] = useState('')
  const [search, setSearch] = useState('')
  const [tab, setTab] = useState('history')
  const [enabled, setEnabled] = useState<Record<string, boolean>>(
    GATEWAYS.reduce((acc, g) => ({ ...acc, [g.id]: g.enabled }), {} as Record<string, boolean>),
  )

  const qs = useMemo(() => {
    const p = new URLSearchParams()
    if (gateway) p.set('gateway', gateway)
    if (status) p.set('status', status)
    if (search) p.set('search', search)
    return p.toString()
  }, [gateway, status, search])

  const { data, isLoading } = useQuery<{ payments: Payment[] }>({
    queryKey: ['payments', gateway, status, search],
    queryFn: () => fetch(`/api/payments?${qs}`).then((r) => r.json()),
  })
  const payments = data?.payments || []

  const totalProcessed = payments.filter((p) => p.status === 'success').reduce((s, p) => s + p.amount, 0)
  const successCount = payments.filter((p) => p.status === 'success').length
  const refundedTotal = payments.filter((p) => p.status === 'refunded').reduce((s, p) => s + p.amount, 0)
  const failedCount = payments.filter((p) => p.status === 'failed').length

  const refunds = payments.filter((p) => p.status === 'refunded')

  const toggleGateway = (id: string, value: boolean) => {
    setEnabled((e) => ({ ...e, [id]: value }))
    toast.success(`${id} ${value ? 'enabled' : 'disabled'}`, { description: value ? 'Customers can now pay with this gateway.' : 'This gateway is no longer available at checkout.' })
  }

  const handleWithdrawal = (id: string, action: 'approve' | 'reject') => {
    toast.success(`Withdrawal ${id} ${action === 'approve' ? 'approved' : 'rejected'}`, {
      description: action === 'approve' ? 'Funds will be disbursed within 24h.' : 'Request denied. Merchant notified.',
    })
  }

  return (
    <div className="space-y-6">
      <SectionHeader
        title="Payment Management"
        subtitle="Gateways, transactions, refunds, payouts & tax configuration"
        icon={CreditCard}
        action={
          <Button size="sm" variant="outline" onClick={() => toast.info('Exporting transactions report...')}>
            <DollarSign className="mr-2 h-4 w-4" /> Export
          </Button>
        }
      />

      {/* Stat row */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <MiniStat label="Total Processed" value={formatPKR(totalProcessed)} icon={DollarSign} gradient="from-emerald-500 to-teal-500" delay={0} />
        <MiniStat label="Successful" value={successCount} icon={CheckCircle2} gradient="from-blue-500 to-cyan-500" delay={0.05} />
        <MiniStat label="Refunded" value={formatPKR(refundedTotal)} icon={RotateCcw} gradient="from-orange-500 to-amber-500" delay={0.1} />
        <MiniStat label="Failed" value={failedCount} icon={XCircle} gradient="from-red-500 to-rose-500" delay={0.15} />
      </div>

      {/* Gateway cards */}
      <div>
        <div className="mb-3 flex items-center justify-between">
          <div>
            <h2 className="text-sm font-semibold">Payment Gateways</h2>
            <p className="text-xs text-muted-foreground">Enable or disable checkout methods</p>
          </div>
          <Badge variant="secondary" className="text-xs">{Object.values(enabled).filter(Boolean).length} active</Badge>
        </div>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {GATEWAYS.map((g, i) => (
            <motion.div
              key={g.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: i * 0.04 }}
            >
              <GlassCard hover className="flex items-center gap-4 p-4">
                <div className={`flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br ${g.gradient} text-white shadow-lg`}>
                  <g.icon className="h-6 w-6" />
                </div>
                <div className="min-w-0 flex-1">
                  <p className="font-semibold">{g.id}</p>
                  <p className="truncate text-xs text-muted-foreground">{g.desc}</p>
                </div>
                <Switch checked={enabled[g.id]} onCheckedChange={(v) => toggleGateway(g.id, v)} />
              </GlassCard>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Main tabs */}
      <Tabs value={tab} onValueChange={setTab}>
        <TabsList className="h-auto flex-wrap">
          <TabsTrigger value="history" className="text-xs">Transaction History</TabsTrigger>
          <TabsTrigger value="refunds" className="text-xs">Refunds</TabsTrigger>
          <TabsTrigger value="coupons" className="text-xs">Coupons</TabsTrigger>
          <TabsTrigger value="withdrawals" className="text-xs">Withdrawal Requests</TabsTrigger>
          <TabsTrigger value="tax" className="text-xs">Tax Settings</TabsTrigger>
        </TabsList>

        {/* Transaction history */}
        <TabsContent value="history" className="mt-4 space-y-4">
          <GlassCard className="p-4">
            <div className="flex flex-wrap items-center gap-3">
              <div className="relative min-w-[220px] flex-1">
                <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input placeholder="Search transaction ID or order number..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-9" />
              </div>
              <Select value={gateway} onValueChange={(v) => setGateway(v === 'all' ? '' : v)}>
                <SelectTrigger className="w-[170px]"><SelectValue placeholder="Gateway" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All gateways</SelectItem>
                  {GATEWAYS.map((g) => <SelectItem key={g.id} value={g.id}>{g.id}</SelectItem>)}
                </SelectContent>
              </Select>
              <Select value={status} onValueChange={(v) => setStatus(v === 'all' ? '' : v)}>
                <SelectTrigger className="w-[150px]"><SelectValue placeholder="Status" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All status</SelectItem>
                  {PAYMENT_STATUSES.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}
                </SelectContent>
              </Select>
              <Badge variant="secondary" className="ml-auto">{payments.length} transactions</Badge>
            </div>
          </GlassCard>

          <GlassCard className="overflow-hidden">
            {isLoading ? (
              <div className="p-5"><TableSkeleton /></div>
            ) : payments.length === 0 ? (
              <div className="p-5"><EmptyState icon={CreditCard} title="No transactions found" description="Adjust filters to see payment records." /></div>
            ) : (
              <div className="overflow-x-auto pb-scroll">
                <table className="w-full min-w-[820px] text-sm">
                  <thead>
                    <tr className="border-b border-border bg-muted/40 text-left text-xs uppercase tracking-wide text-muted-foreground">
                      <th className="px-4 py-3 font-semibold">Transaction ID</th>
                      <th className="px-4 py-3 font-semibold">Order #</th>
                      <th className="px-4 py-3 font-semibold">Gateway</th>
                      <th className="px-4 py-3 font-semibold">Amount</th>
                      <th className="px-4 py-3 font-semibold">Status</th>
                      <th className="px-4 py-3 font-semibold">Date</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-border">
                    {payments.slice(0, 60).map((p) => (
                      <tr key={p.id} className="transition hover:bg-accent/40">
                        <td className="px-4 py-3 font-mono text-xs">{p.transactionId || '—'}</td>
                        <td className="px-4 py-3 font-semibold">{p.orderNumber}</td>
                        <td className="px-4 py-3"><GatewayBadge gateway={p.gateway} /></td>
                        <td className="px-4 py-3 font-semibold">{formatPKR(p.amount, { decimals: true })} <span className="text-xs text-muted-foreground">{p.currency}</span></td>
                        <td className="px-4 py-3"><StatusPill status={p.status} /></td>
                        <td className="px-4 py-3 text-muted-foreground">{new Date(p.createdAt).toLocaleDateString('en', { month: 'short', day: 'numeric', year: 'numeric' })}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </GlassCard>
        </TabsContent>

        {/* Refunds */}
        <TabsContent value="refunds" className="mt-4">
          <GlassCard className="p-5">
            <div className="mb-4 flex items-center justify-between">
              <div>
                <p className="text-sm font-semibold">Refunded Payments</p>
                <p className="text-xs text-muted-foreground">{refunds.length} refunded transactions · ${refundedTotal.toFixed(2)} total</p>
              </div>
              <Badge variant="outline" className="text-xs"><RotateCcw className="mr-1 h-3 w-3" /> {refunds.length} refunds</Badge>
            </div>
            {refunds.length === 0 ? (
              <EmptyState icon={RotateCcw} title="No refunds yet" description="Refunded payments will appear here." />
            ) : (
              <div className="space-y-2">
                {refunds.slice(0, 20).map((p, i) => (
                  <div key={p.id} className="flex flex-wrap items-center gap-3 rounded-xl border border-border p-3">
                    <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-orange-500/10 text-orange-500"><RotateCcw className="h-4 w-4" /></div>
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-semibold">{p.orderNumber} · {p.transactionId || '—'}</p>
                      <p className="text-xs text-muted-foreground">{REFUND_REASONS[i % REFUND_REASONS.length]}</p>
                    </div>
                    <GatewayBadge gateway={p.gateway} />
                    <p className="text-sm font-semibold text-orange-600">-{formatPKR(p.amount, { decimals: true })}</p>
                    <StatusPill status={p.status} />
                    <span className="text-xs text-muted-foreground">{new Date(p.createdAt).toLocaleDateString()}</span>
                  </div>
                ))}
              </div>
            )}
          </GlassCard>
        </TabsContent>

        {/* Coupons — conceptually link to marketing */}
        <TabsContent value="coupons" className="mt-4">
          <GlassCard className="flex flex-col items-center gap-4 p-8 text-center">
            <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-orange-500 to-red-500 text-white shadow-lg">
              <Percent className="h-7 w-7" />
            </div>
            <div>
              <p className="text-lg font-semibold">Coupons & Discount Codes</p>
              <p className="mx-auto mt-1 max-w-md text-sm text-muted-foreground">
                Promotional coupons are managed in the Marketing panel. Create percentage or fixed-amount codes, track usage and performance, and schedule validity windows.
              </p>
            </div>
            <Button className="pb-gradient-brand" onClick={() => setView('marketing')}>
              Go to Marketing <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </GlassCard>
        </TabsContent>

        {/* Withdrawal requests */}
        <TabsContent value="withdrawals" className="mt-4 space-y-4">
          <GlassCard className="p-5">
            <div className="mb-4 flex items-center justify-between">
              <div>
                <p className="text-sm font-semibold">Payout / Withdrawal Requests</p>
                <p className="text-xs text-muted-foreground">Review merchant withdrawal requests</p>
              </div>
              <Badge variant="secondary" className="text-xs">{WITHDRAWALS.length} pending</Badge>
            </div>
            <div className="space-y-2">
              {WITHDRAWALS.map((w) => (
                <div key={w.id} className="flex flex-wrap items-center gap-3 rounded-xl border border-border p-3 transition hover:bg-accent/30">
                  <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-gradient-to-br from-blue-500 to-cyan-500 text-white">
                    <Wallet className="h-4 w-4" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-semibold">{w.merchant}</p>
                    <p className="text-xs text-muted-foreground">{w.id} · {w.date}</p>
                  </div>
                  <GatewayBadge gateway={w.gateway} />
                  <p className="text-sm font-bold">{formatPKR(w.amount, { decimals: true })}</p>
                  <StatusPill status={w.status} />
                  <div className="flex gap-2">
                    <Button size="sm" className="h-8 pb-gradient-brand" onClick={() => handleWithdrawal(w.id, 'approve')}>
                      <CheckCircle2 className="mr-1 h-3.5 w-3.5" /> Approve
                    </Button>
                    <Button size="sm" variant="outline" className="h-8 text-red-600 hover:text-red-700" onClick={() => handleWithdrawal(w.id, 'reject')}>
                      <XCircle className="mr-1 h-3.5 w-3.5" /> Reject
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </GlassCard>
        </TabsContent>

        {/* Tax settings */}
        <TabsContent value="tax" className="mt-4">
          <TaxSettingsCard />
        </TabsContent>
      </Tabs>
    </div>
  )
}

function MiniStat({ label, value, icon: Icon, gradient, delay }: { label: string; value: string | number; icon: any; gradient: string; delay: number }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35, delay }}
      className="pb-glass flex items-center gap-3 rounded-2xl p-4 pb-lift"
    >
      <div className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br ${gradient} text-white shadow-lg`}>
        <Icon className="h-5 w-5" />
      </div>
      <div className="min-w-0">
        <p className="text-xl font-bold pb-count">{value}</p>
        <p className="text-xs text-muted-foreground">{label}</p>
      </div>
    </motion.div>
  )
}

function GatewayBadge({ gateway }: { gateway: string }) {
  const map: Record<string, string> = {
    Stripe: 'bg-slate-500/10 text-slate-700 dark:text-slate-300 ring-slate-500/20',
    PayPal: 'bg-blue-500/10 text-blue-600 dark:text-blue-400 ring-blue-500/20',
    JazzCash: 'bg-red-500/10 text-red-600 dark:text-red-400 ring-red-500/20',
    Easypaisa: 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 ring-emerald-500/20',
    'Bank Transfer': 'bg-amber-500/10 text-amber-600 dark:text-amber-400 ring-amber-500/20',
    Manual: 'bg-slate-500/10 text-slate-600 dark:text-slate-300 ring-slate-500/20',
  }
  return (
    <span className={`inline-flex items-center gap-1 rounded-full px-2.5 py-0.5 text-xs font-semibold ring-1 ring-inset ${map[gateway] || 'bg-slate-500/10 text-slate-600 ring-slate-500/20'}`}>
      {gateway}
    </span>
  )
}

function TaxSettingsCard() {
  const [taxRate, setTaxRate] = useState('7.5')
  const [currency, setCurrency] = useState('PKR')
  const [inclusive, setInclusive] = useState(true)
  const [region, setRegion] = useState('pk')

  const save = () => {
    if (!taxRate || isNaN(Number(taxRate))) { toast.error('Enter a valid tax rate'); return }
    toast.success('Tax settings saved', {
      description: `${taxRate}% ${inclusive ? 'tax-inclusive' : 'tax-exclusive'} pricing · currency: ${currency}`,
    })
  }

  return (
    <GlassCard className="p-5">
      <div className="mb-4 flex items-center gap-3">
        <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-orange-500 to-red-500 text-white shadow-md">
          <Percent className="h-5 w-5" />
        </div>
        <div>
          <p className="text-sm font-semibold">Tax & Currency Settings</p>
          <p className="text-xs text-muted-foreground">Configure tax collection and pricing currency</p>
        </div>
      </div>
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <div className="space-y-1.5">
          <Label>Tax Rate (%)</Label>
          <Input type="number" step="0.01" value={taxRate} onChange={(e) => setTaxRate(e.target.value)} />
        </div>
        <div className="space-y-1.5">
          <Label>Currency</Label>
          <Select value={currency} onValueChange={setCurrency}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="PKR">PKR — Pakistani Rupee</SelectItem>
              <SelectItem value="USD">USD — US Dollar</SelectItem>
              <SelectItem value="EUR">EUR — Euro</SelectItem>
              <SelectItem value="GBP">GBP — British Pound</SelectItem>
              <SelectItem value="AED">AED — UAE Dirham</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-1.5">
          <Label>Tax Region</Label>
          <Select value={region} onValueChange={setRegion}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="pk">Pakistan</SelectItem>
              <SelectItem value="global">Global (default)</SelectItem>
              <SelectItem value="us">United States</SelectItem>
              <SelectItem value="eu">European Union</SelectItem>
              <SelectItem value="ae">UAE</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="flex items-end">
          <div className="flex w-full items-center justify-between gap-2 rounded-xl border border-border bg-muted/30 p-3">
            <div>
              <p className="text-sm font-medium">Tax-Inclusive Pricing</p>
              <p className="text-xs text-muted-foreground">Show prices with tax included</p>
            </div>
            <Switch checked={inclusive} onCheckedChange={(v) => { setInclusive(v); toast.info(`Pricing is now ${v ? 'tax-inclusive' : 'tax-exclusive'}`) }} />
          </div>
        </div>
      </div>
      <div className="mt-4 flex justify-end gap-2">
        <Button variant="outline" onClick={() => toast.info('Changes discarded')}>Reset</Button>
        <Button className="pb-gradient-brand" onClick={save}>
          <CheckCircle2 className="mr-2 h-4 w-4" /> Save Settings
        </Button>
      </div>

      <div className="mt-5 grid grid-cols-1 gap-3 sm:grid-cols-3">
        <div className="rounded-xl border border-border p-3">
          <div className="flex items-center gap-2 text-xs text-muted-foreground"><TrendingUp className="h-3.5 w-3.5" /> Tax collected (MTD)</div>
          <p className="mt-1 text-lg font-bold pb-count">Rs 3,420.50</p>
        </div>
        <div className="rounded-xl border border-border p-3">
          <div className="flex items-center gap-2 text-xs text-muted-foreground"><DollarSign className="h-3.5 w-3.5" /> Avg. effective rate</div>
          <p className="mt-1 text-lg font-bold pb-count">7.31%</p>
        </div>
        <div className="rounded-xl border border-border p-3">
          <div className="flex items-center gap-2 text-xs text-muted-foreground"><Building2 className="h-3.5 w-3.5" /> Tax jurisdictions</div>
          <p className="mt-1 text-lg font-bold pb-count">5</p>
        </div>
      </div>
    </GlassCard>
  )
}
