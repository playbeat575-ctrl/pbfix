'use client'

import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { GlassCard, SectionHeader } from '@/components/shared'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Switch } from '@/components/ui/switch'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { ScrollArea } from '@/components/ui/scroll-area'
import { useTheme } from 'next-themes'
import {
  Settings, Save, Store, Image as ImageIcon, Mail, MessageSquare, KeyRound, CreditCard, Palette, Wrench, Globe, Eye, EyeOff,
  Copy, RefreshCw, Plus, Check, Sun, Moon, Laptop, RotateCcw, Send, Smartphone, AlertTriangle,
} from 'lucide-react'
import { useMemo, useState } from 'react'
import { toast } from 'sonner'

type SettingsMap = Record<string, string>

const SECTIONS = [
  { key: 'general', label: 'General', icon: Store },
  { key: 'branding', label: 'Branding', icon: ImageIcon },
  { key: 'smtp', label: 'SMTP', icon: Mail },
  { key: 'sms', label: 'SMS Gateway', icon: MessageSquare },
  { key: 'apikeys', label: 'API Keys', icon: KeyRound },
  { key: 'payments', label: 'Payment Gateways', icon: CreditCard },
  { key: 'theme', label: 'Theme', icon: Palette },
  { key: 'maintenance', label: 'Maintenance', icon: Wrench },
  { key: 'region', label: 'Language & Region', icon: Globe },
] as const

type SectionKey = typeof SECTIONS[number]['key']

const DEFAULTS: SettingsMap = {
  'general.siteName': 'Playbeat.Digital',
  'general.tagline': 'Premium Digital Marketplace',
  'general.supportEmail': 'support@playbeat.digital',
  'general.timezone': 'Asia/Karachi',
  'general.currency': 'PKR',
  'general.region': 'Pakistan',
  'general.language': 'en',
  'branding.logoUrl': '',
  'branding.faviconUrl': '',
  'branding.primaryColor': '#ef4444',
  'branding.accentColor': '#f97316',
  'smtp.host': 'smtp.playbeat.digital',
  'smtp.port': '587',
  'smtp.username': 'no-reply@playbeat.digital',
  'smtp.password': '',
  'smtp.encryption': 'TLS',
  'smtp.fromEmail': 'no-reply@playbeat.digital',
  'sms.provider': 'twilio',
  'sms.apiSid': '',
  'sms.authToken': '',
  'sms.senderId': 'PLAYBEAT',
  'payment.stripe': 'true',
  'payment.paypal': 'true',
  'payment.jazzcash': 'false',
  'payment.easypaisa': 'false',
  'payment.bank': 'true',
  'payment.manual': 'false',
  'theme.mode': 'auto',
  'theme.radius': '0.75',
  'maintenance.enabled': 'false',
  'maintenance.message': 'We are performing scheduled maintenance. Please check back soon.',
  'maintenance.scheduledAt': '',
  'maintenance.allowedIps': '',
  'region.language': 'en',
  'region.timezone': 'Asia/Karachi',
  'region.dateFormat': 'DD/MM/YYYY',
  'region.currencyFormat': 'en-PK',
  'region.rtl': 'false',
}

export function SettingsView() {
  const qc = useQueryClient()
  const { data, isLoading } = useQuery<{ settings: SettingsMap }>({
    queryKey: ['settings'],
    queryFn: () => fetch('/api/settings').then((r) => r.json()),
  })
  const [section, setSection] = useState<SectionKey>('general')
  // Overrides track only the fields the user has explicitly changed in this session.
  const [overrides, setOverrides] = useState<SettingsMap>({})

  // Effective form = defaults + server values + local overrides (no setState-in-effect).
  const form = useMemo<SettingsMap>(() => ({ ...DEFAULTS, ...(data?.settings || {}), ...overrides }), [data, overrides])

  const dirty = useMemo(() => {
    const base = { ...DEFAULTS, ...(data?.settings || {}) }
    return Object.keys(form).some((k) => form[k] !== (base as any)[k])
  }, [form, data])

  const saveMut = useMutation({
    mutationFn: (body: SettingsMap) =>
      fetch('/api/settings', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }).then((r) => r.json()),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['settings'] }); toast.success('Settings saved'); setOverrides({}) },
    onError: () => toast.error('Failed to save settings'),
  })

  const set = (k: string, v: string) => setOverrides((o) => ({ ...o, [k]: v }))
  const get = (k: string) => form[k] ?? ''
  const save = () => saveMut.mutate(form)

  return (
    <div className="space-y-6">
      <SectionHeader
        title="Settings"
        subtitle="Configure your marketplace"
        icon={Settings}
        action={
          <>
            <Button variant="outline" size="sm" onClick={() => { setOverrides({}); toast.info('Changes discarded') }} disabled={!dirty}>
              <RotateCcw className="mr-2 h-4 w-4" /> Reset
            </Button>
            <Button size="sm" className="pb-gradient-brand" onClick={save} disabled={!dirty || saveMut.isPending}>
              <Save className="mr-2 h-4 w-4" /> {saveMut.isPending ? 'Saving...' : 'Save Changes'}
              {dirty && <Badge variant="secondary" className="ml-2 h-5 px-1.5 text-[10px]">unsaved</Badge>}
            </Button>
          </>
        }
      />

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-4">
        {/* Side nav */}
        <GlassCard className="h-fit p-2 lg:col-span-1">
          <ScrollArea className="w-full">
            <div className="flex gap-1 overflow-x-auto pb-2 lg:flex-col lg:overflow-visible lg:pb-0">
              {SECTIONS.map((s) => (
                <button
                  key={s.key}
                  onClick={() => setSection(s.key)}
                  className={`flex shrink-0 items-center gap-2 rounded-xl px-3 py-2 text-left text-sm font-medium transition lg:w-full ${section === s.key ? 'bg-primary text-primary-foreground shadow' : 'text-muted-foreground hover:bg-accent hover:text-foreground'}`}
                >
                  <s.icon className="h-4 w-4" />
                  <span className="whitespace-nowrap">{s.label}</span>
                </button>
              ))}
            </div>
          </ScrollArea>
        </GlassCard>

        {/* Content */}
        <div className="lg:col-span-3">
          {isLoading ? (
            <GlassCard className="p-5">
              <div className="space-y-3">
                {Array.from({ length: 6 }).map((_, i) => <div key={i} className="h-10 rounded-lg bg-muted pb-shimmer" />)}
              </div>
            </GlassCard>
          ) : (
            <GlassCard className="p-5">
              {section === 'general' && <GeneralSection get={get} set={set} />}
              {section === 'branding' && <BrandingSection get={get} set={set} />}
              {section === 'smtp' && <SmtpSection get={get} set={set} />}
              {section === 'sms' && <SmsSection get={get} set={set} />}
              {section === 'apikeys' && <ApiKeysSection />}
              {section === 'payments' && <PaymentsSection get={get} set={set} save={save} />}
              {section === 'theme' && <ThemeSection get={get} set={set} />}
              {section === 'maintenance' && <MaintenanceSection get={get} set={set} />}
              {section === 'region' && <RegionSection get={get} set={set} />}

              <Separator className="my-5" />
              <div className="flex items-center justify-between">
                <p className="text-xs text-muted-foreground">{dirty ? 'You have unsaved changes' : 'All changes saved'}</p>
                <Button size="sm" className="pb-gradient-brand" onClick={save} disabled={!dirty || saveMut.isPending}>
                  <Save className="mr-2 h-4 w-4" /> {saveMut.isPending ? 'Saving...' : 'Save Changes'}
                </Button>
              </div>
            </GlassCard>
          )}
        </div>
      </div>
    </div>
  )
}

/* ---------- Sections ---------- */
function Field({ label, hint, children }: { label: string; hint?: string; children: React.ReactNode }) {
  return (
    <div className="space-y-1.5">
      <Label className="text-xs font-medium">{label}</Label>
      {children}
      {hint && <p className="text-[11px] text-muted-foreground">{hint}</p>}
    </div>
  )
}

function GeneralSection({ get, set }: { get: (k: string) => string; set: (k: string, v: string) => void }) {
  return (
    <div className="space-y-4">
      <SectionTitle icon={Store} title="General Settings" desc="Basic marketplace configuration" />
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <Field label="Site Name"><Input value={get('general.siteName')} onChange={(e) => set('general.siteName', e.target.value)} /></Field>
        <Field label="Tagline"><Input value={get('general.tagline')} onChange={(e) => set('general.tagline', e.target.value)} /></Field>
        <Field label="Support Email"><Input type="email" value={get('general.supportEmail')} onChange={(e) => set('general.supportEmail', e.target.value)} /></Field>
        <Field label="Timezone">
          <Select value={get('general.timezone')} onValueChange={(v) => set('general.timezone', v)}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              {['Asia/Karachi', 'Asia/Dubai', 'America/New_York', 'Europe/London', 'Asia/Tokyo', 'UTC'].map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}
            </SelectContent>
          </Select>
        </Field>
        <Field label="Region">
          <Select value={get('general.region')} onValueChange={(v) => set('general.region', v)}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              {[['Pakistan', 'Pakistan'], ['United Arab Emirates', 'United Arab Emirates'], ['United States', 'United States'], ['United Kingdom', 'United Kingdom'], ['Saudi Arabia', 'Saudi Arabia'], ['India', 'India'], ['Global', 'Global']].map(([v, l]) => <SelectItem key={v} value={v}>{l}</SelectItem>)}
            </SelectContent>
          </Select>
        </Field>
        <Field label="Currency">
          <Select value={get('general.currency')} onValueChange={(v) => set('general.currency', v)}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              {[['PKR', 'Pakistani Rupee (Rs)', 'PKR'], ['USD', 'US Dollar ($)', 'USD'], ['EUR', 'Euro (€)', 'EUR'], ['GBP', 'British Pound (£)', 'GBP']].map(([v, l]) => <SelectItem key={v} value={v}>{l}</SelectItem>)}
            </SelectContent>
          </Select>
        </Field>
        <Field label="Default Language">
          <Select value={get('general.language')} onValueChange={(v) => set('general.language', v)}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              {[['en', 'English'], ['ur', 'Urdu'], ['ar', 'Arabic'], ['fr', 'French'], ['es', 'Spanish']].map(([v, l]) => <SelectItem key={v} value={v}>{l}</SelectItem>)}
            </SelectContent>
          </Select>
        </Field>
      </div>
    </div>
  )
}

function BrandingSection({ get, set }: { get: (k: string) => string; set: (k: string, v: string) => void }) {
  return (
    <div className="space-y-4">
      <SectionTitle icon={ImageIcon} title="Branding" desc="Logos, colors and visual identity" />
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <Field label="Logo URL" hint="PNG/SVG recommended, 240x60">
          <Input value={get('branding.logoUrl')} onChange={(e) => set('branding.logoUrl', e.target.value)} placeholder="https://..." />
        </Field>
        <Field label="Favicon URL">
          <Input value={get('branding.faviconUrl')} onChange={(e) => set('branding.faviconUrl', e.target.value)} placeholder="https://..." />
        </Field>
        <Field label="Primary Color">
          <div className="flex items-center gap-2">
            <input type="color" value={get('branding.primaryColor')} onChange={(e) => set('branding.primaryColor', e.target.value)} className="h-9 w-12 cursor-pointer rounded-md border border-border bg-transparent" />
            <Input value={get('branding.primaryColor')} onChange={(e) => set('branding.primaryColor', e.target.value)} className="font-mono" />
          </div>
        </Field>
        <Field label="Accent Color">
          <div className="flex items-center gap-2">
            <input type="color" value={get('branding.accentColor')} onChange={(e) => set('branding.accentColor', e.target.value)} className="h-9 w-12 cursor-pointer rounded-md border border-border bg-transparent" />
            <Input value={get('branding.accentColor')} onChange={(e) => set('branding.accentColor', e.target.value)} className="font-mono" />
          </div>
        </Field>
      </div>
      {/* Live preview */}
      <div className="rounded-2xl border border-border p-5">
        <p className="mb-3 text-xs font-medium text-muted-foreground">Live Preview</p>
        <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl p-4" style={{ background: `linear-gradient(135deg, ${get('branding.primaryColor')}15, ${get('branding.accentColor')}15)` }}>
          <div className="flex items-center gap-3">
            {get('branding.logoUrl') ? (
              <img src={get('branding.logoUrl')} alt="logo" className="h-9 w-auto" />
            ) : (
              <div className="flex h-9 items-center rounded-lg px-3 font-bold text-white" style={{ background: `linear-gradient(135deg, ${get('branding.primaryColor')}, ${get('branding.accentColor')})` }}>
                {get('general.siteName')}
              </div>
            )}
          </div>
          <div className="flex gap-2">
            <button className="rounded-lg px-3 py-1.5 text-xs font-semibold text-white shadow" style={{ background: get('branding.primaryColor') }}>Primary</button>
            <button className="rounded-lg px-3 py-1.5 text-xs font-semibold text-white shadow" style={{ background: get('branding.accentColor') }}>Accent</button>
          </div>
        </div>
      </div>
    </div>
  )
}

function SmtpSection({ get, set }: { get: (k: string) => string; set: (k: string, v: string) => void }) {
  return (
    <div className="space-y-4">
      <SectionTitle icon={Mail} title="SMTP Configuration" desc="Outgoing email server settings" />
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <Field label="SMTP Host"><Input value={get('smtp.host')} onChange={(e) => set('smtp.host', e.target.value)} /></Field>
        <Field label="Port"><Input value={get('smtp.port')} onChange={(e) => set('smtp.port', e.target.value)} /></Field>
        <Field label="Username"><Input value={get('smtp.username')} onChange={(e) => set('smtp.username', e.target.value)} /></Field>
        <Field label="Password"><Input type="password" value={get('smtp.password')} onChange={(e) => set('smtp.password', e.target.value)} placeholder="••••••••" /></Field>
        <Field label="Encryption">
          <Select value={get('smtp.encryption')} onValueChange={(v) => set('smtp.encryption', v)}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent><SelectItem value="none">None</SelectItem><SelectItem value="SSL">SSL</SelectItem><SelectItem value="TLS">TLS</SelectItem></SelectContent>
          </Select>
        </Field>
        <Field label="From Email"><Input type="email" value={get('smtp.fromEmail')} onChange={(e) => set('smtp.fromEmail', e.target.value)} /></Field>
      </div>
      <Button variant="outline" size="sm" onClick={() => toast.success('Test email sent — check inbox', { description: get('smtp.fromEmail') })}>
        <Send className="mr-2 h-4 w-4" /> Send Test Email
      </Button>
    </div>
  )
}

function SmsSection({ get, set }: { get: (k: string) => string; set: (k: string, v: string) => void }) {
  return (
    <div className="space-y-4">
      <SectionTitle icon={MessageSquare} title="SMS Gateway" desc="Transactional SMS provider for OTPs & alerts" />
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <Field label="Provider">
          <Select value={get('sms.provider')} onValueChange={(v) => set('sms.provider', v)}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent><SelectItem value="twilio">Twilio</SelectItem><SelectItem value="vonage">Vonage</SelectItem><SelectItem value="custom">Custom</SelectItem></SelectContent>
          </Select>
        </Field>
        <Field label="Sender ID"><Input value={get('sms.senderId')} onChange={(e) => set('sms.senderId', e.target.value)} /></Field>
        <Field label="API SID / Account ID"><Input value={get('sms.apiSid')} onChange={(e) => set('sms.apiSid', e.target.value)} /></Field>
        <Field label="Auth Token"><Input type="password" value={get('sms.authToken')} onChange={(e) => set('sms.authToken', e.target.value)} placeholder="••••••••" /></Field>
      </div>
      <Button variant="outline" size="sm" onClick={() => toast.success('Test SMS sent to your registered number')}>
        <Smartphone className="mr-2 h-4 w-4" /> Send Test SMS
      </Button>
    </div>
  )
}

type ApiKey = { id: string; name: string; value: string; masked: string }

function ApiKeysSection() {
  const [keys, setKeys] = useState<ApiKey[]>([
    { id: '1', name: 'Stripe Secret', value: 'sk_live_51MqABcD1234567xyz', masked: 'sk_live_••••••••••••••••••••••6789' },
    { id: '2', name: 'PayPal Client Secret', value: 'EH3xpaypal_live_secret_98765', masked: 'EH3x•••••••••••••••••••••8765' },
    { id: '3', name: 'Cloudinary API Secret', value: 'cloudinary_secret_abc12345', masked: 'clou••••••••••••••••••••••2345' },
    { id: '4', name: 'Google Maps API', value: 'AIzaSyB-google_maps_key_xyz', masked: 'AIza•••••••••••••••••••••••_xyz' },
  ])
  const [revealed, setRevealed] = useState<Record<string, boolean>>({})
  const [newName, setNewName] = useState('')

  const reveal = (id: string) => setRevealed((r) => ({ ...r, [id]: !r[id] }))
  const copy = (k: ApiKey) => { navigator.clipboard?.writeText(k.value); toast.success(`${k.name} copied to clipboard`) }
  const regen = (k: ApiKey) => { toast.success(`${k.name} regenerated — old key revoked`); setRevealed((r) => ({ ...r, [k.id]: true })) }
  const addKey = () => {
    if (!newName) { toast.error('Enter a key name'); return }
    const id = String(Date.now())
    setKeys((k) => [...k, { id, name: newName, value: 'sk_' + Math.random().toString(36).slice(2, 18), masked: 'sk_•••••••••••••••' }])
    setNewName(''); toast.success(`Key "${newName}" created`)
  }

  return (
    <div className="space-y-4">
      <SectionTitle icon={KeyRound} title="API Keys" desc="Credentials for integrated services" />
      <div className="space-y-2">
        {keys.map((k) => (
          <div key={k.id} className="flex flex-wrap items-center gap-2 rounded-xl border border-border/60 p-3">
            <KeyRound className="h-4 w-4 text-amber-500" />
            <div className="min-w-[140px] flex-1">
              <p className="text-sm font-medium">{k.name}</p>
              <p className="font-mono text-xs text-muted-foreground">{revealed[k.id] ? k.value : k.masked}</p>
            </div>
            <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => reveal(k.id)} title={revealed[k.id] ? 'Hide' : 'Reveal'}>
              {revealed[k.id] ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
            </Button>
            <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => copy(k)} title="Copy"><Copy className="h-4 w-4" /></Button>
            <Button variant="ghost" size="icon" className="h-8 w-8 text-amber-500" onClick={() => regen(k)} title="Regenerate"><RefreshCw className="h-4 w-4" /></Button>
          </div>
        ))}
      </div>
      <div className="flex gap-2">
        <Input value={newName} onChange={(e) => setNewName(e.target.value)} placeholder="New key name e.g. Twilio API Key" />
        <Button size="sm" onClick={addKey} className="pb-gradient-brand"><Plus className="mr-1.5 h-4 w-4" /> Create</Button>
      </div>
    </div>
  )
}

const PAYMENTS = [
  { key: 'payment.stripe', label: 'Stripe', desc: 'Cards, Apple Pay, Google Pay', color: 'from-indigo-500 to-purple-500' },
  { key: 'payment.paypal', label: 'PayPal', desc: 'PayPal balance & cards', color: 'from-blue-500 to-cyan-500' },
  { key: 'payment.jazzcash', label: 'JazzCash', desc: 'Mobile wallet (PK)', color: 'from-red-500 to-orange-500' },
  { key: 'payment.easypaisa', label: 'Easypaisa', desc: 'Mobile wallet (PK)', color: 'from-emerald-500 to-green-500' },
  { key: 'payment.bank', label: 'Bank Transfer', desc: 'Manual confirmation', color: 'from-slate-500 to-slate-700' },
  { key: 'payment.manual', label: 'Manual', desc: 'Cash / in-store', color: 'from-amber-500 to-yellow-500' },
]

function PaymentsSection({ get, set, save }: { get: (k: string) => string; set: (k: string, v: string) => void; save: () => void }) {
  const [expanded, setExpanded] = useState<string | null>(null)
  return (
    <div className="space-y-4">
      <SectionTitle icon={CreditCard} title="Payment Gateways" desc="Toggle and configure your active payment processors" />
      <div className="space-y-2">
        {PAYMENTS.map((p) => {
          const on = get(p.key) === 'true'
          return (
            <div key={p.key} className="rounded-xl border border-border/60">
              <div className="flex flex-wrap items-center gap-3 p-3">
                <div className={`flex h-9 w-9 items-center justify-center rounded-lg bg-gradient-to-br ${p.color} text-white`}><CreditCard className="h-4 w-4" /></div>
                <div className="min-w-[140px] flex-1">
                  <p className="text-sm font-medium">{p.label}</p>
                  <p className="text-xs text-muted-foreground">{p.desc}</p>
                </div>
                <Switch
                  checked={on}
                  onCheckedChange={(v) => { set(p.key, String(v)); toast.success(`${p.label} ${v ? 'enabled' : 'disabled'}`) }}
                />
                <Button variant="ghost" size="sm" onClick={() => setExpanded(expanded === p.key ? null : p.key)}>
                  {expanded === p.key ? 'Hide' : 'Configure'}
                </Button>
              </div>
              {expanded === p.key && (
                <div className="grid grid-cols-1 gap-3 border-t border-border/60 p-3 sm:grid-cols-2">
                  <Field label="API Key / Publishable"><Input placeholder={`${p.label} publishable key`} /></Field>
                  <Field label="Secret Key"><Input type="password" placeholder="••••••••" /></Field>
                  <Field label="Webhook URL" hint="Set this URL in your gateway dashboard">
                    <Input readOnly value={`/api/webhooks/${p.label.toLowerCase()}`} className="font-mono text-xs" />
                  </Field>
                  <div className="flex items-end">
                    <Button size="sm" onClick={() => { save(); toast.success(`${p.label} credentials saved`) }}>Save Config</Button>
                  </div>
                </div>
              )}
            </div>
          )
        })}
      </div>
    </div>
  )
}

function ThemeSection({ get, set }: { get: (k: string) => string; set: (k: string, v: string) => void }) {
  const { theme, setTheme } = useTheme()
  const swatches = ['#ef4444', '#f97316', '#f59e0b', '#10b981', '#06b6d4', '#3b82f6', '#ec4899', '#8b5cf6']
  return (
    <div className="space-y-4">
      <SectionTitle icon={Palette} title="Theme" desc="Appearance, color scheme and rounding" />
      <Field label="Theme Mode">
        <div className="grid grid-cols-3 gap-2">
          {([['light', Sun, 'Light'], ['dark', Moon, 'Dark'], ['auto', Laptop, 'Auto']] as const).map(([v, Icon, label]) => (
            <button
              key={v}
              onClick={() => { setTheme(v); set('theme.mode', v); toast.success(`Theme: ${label}`) }}
              className={`flex flex-col items-center gap-1 rounded-xl border p-3 transition ${theme === v ? 'border-primary bg-primary/5' : 'border-border hover:bg-accent'}`}
            >
              <Icon className="h-5 w-5" />
              <span className="text-xs font-medium">{label}</span>
            </button>
          ))}
        </div>
      </Field>
      <Field label="Primary Color Swatches">
        <div className="flex flex-wrap gap-2">
          {swatches.map((c) => (
            <button
              key={c}
              onClick={() => { set('branding.primaryColor', c); toast.success('Primary color updated — save to apply') }}
              className={`flex h-9 w-9 items-center justify-center rounded-full ring-2 ring-offset-2 ring-offset-background transition ${get('branding.primaryColor') === c ? 'ring-foreground' : 'ring-transparent'}`}
              style={{ background: c }}
            >
              {get('branding.primaryColor') === c && <Check className="h-4 w-4 text-white" />}
            </button>
          ))}
        </div>
      </Field>
      <Field label={`Border Radius · ${get('theme.radius')}rem`}>
        <input type="range" min={0} max={2} step={0.05} value={get('theme.radius')} onChange={(e) => set('theme.radius', e.target.value)} className="w-full accent-red-500" />
      </Field>
      <Button variant="outline" size="sm" onClick={() => { set('theme.radius', '0.75'); set('branding.primaryColor', '#ef4444'); toast.info('Reset to defaults') }}>
        <RotateCcw className="mr-2 h-4 w-4" /> Reset to defaults
      </Button>
    </div>
  )
}

function MaintenanceSection({ get, set }: { get: (k: string) => string; set: (k: string, v: string) => void }) {
  const on = get('maintenance.enabled') === 'true'
  return (
    <div className="space-y-4">
      <SectionTitle icon={Wrench} title="Maintenance Mode" desc="Temporarily take the marketplace offline" />
      <div className="flex items-center justify-between rounded-xl border border-border/60 p-3">
        <div className="flex items-center gap-2">
          <AlertTriangle className="h-4 w-4 text-amber-500" />
          <div><p className="text-sm font-medium">Enable maintenance mode</p><p className="text-xs text-muted-foreground">Visitors see a maintenance page</p></div>
        </div>
        <Switch checked={on} onCheckedChange={(v) => { set('maintenance.enabled', String(v)); toast.success(`Maintenance mode ${v ? 'enabled' : 'disabled'}`) }} />
      </div>
      <Field label="Maintenance Message">
        <Textarea rows={3} value={get('maintenance.message')} onChange={(e) => set('maintenance.message', e.target.value)} />
      </Field>
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <Field label="Scheduled Maintenance At">
          <Input type="datetime-local" value={get('maintenance.scheduledAt')} onChange={(e) => set('maintenance.scheduledAt', e.target.value)} />
        </Field>
        <Field label="Allowed IPs (comma separated)" hint="These IPs bypass maintenance">
          <Input value={get('maintenance.allowedIps')} onChange={(e) => set('maintenance.allowedIps', e.target.value)} placeholder="203.135.42.18, 182.191.83.4" />
        </Field>
      </div>
    </div>
  )
}

function RegionSection({ get, set }: { get: (k: string) => string; set: (k: string, v: string) => void }) {
  return (
    <div className="space-y-4">
      <SectionTitle icon={Globe} title="Language & Region" desc="Localization defaults for your storefront" />
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <Field label="Default Language">
          <Select value={get('region.language')} onValueChange={(v) => set('region.language', v)}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              {[['en', 'English'], ['ur', 'Urdu'], ['ar', 'Arabic'], ['fr', 'French'], ['es', 'Spanish'], ['de', 'German']].map(([v, l]) => <SelectItem key={v} value={v}>{l}</SelectItem>)}
            </SelectContent>
          </Select>
        </Field>
        <Field label="Timezone">
          <Select value={get('region.timezone')} onValueChange={(v) => set('region.timezone', v)}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              {['Asia/Karachi', 'Asia/Dubai', 'America/New_York', 'Europe/London', 'Asia/Tokyo', 'UTC'].map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}
            </SelectContent>
          </Select>
        </Field>
        <Field label="Date Format">
          <Select value={get('region.dateFormat')} onValueChange={(v) => set('region.dateFormat', v)}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              {['MM/DD/YYYY', 'DD/MM/YYYY', 'YYYY-MM-DD', 'DD MMM YYYY'].map((d) => <SelectItem key={d} value={d}>{d}</SelectItem>)}
            </SelectContent>
          </Select>
        </Field>
        <Field label="Currency Format">
          <Select value={get('region.currencyFormat')} onValueChange={(v) => set('region.currencyFormat', v)}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              {['en-PK', 'en-US', 'ur-PK', 'en-GB', 'de-DE', 'fr-FR'].map((d) => <SelectItem key={d} value={d}>{d}</SelectItem>)}
            </SelectContent>
          </Select>
        </Field>
      </div>
      <div className="flex items-center justify-between rounded-xl border border-border/60 p-3">
        <div><p className="text-sm font-medium">Right-to-Left (RTL)</p><p className="text-xs text-muted-foreground">For Arabic, Hebrew, etc.</p></div>
        <Switch checked={get('region.rtl') === 'true'} onCheckedChange={(v) => set('region.rtl', String(v))} />
      </div>
    </div>
  )
}

function SectionTitle({ icon: Icon, title, desc }: { icon: any; title: string; desc: string }) {
  return (
    <div className="flex items-center gap-3">
      <div className="flex h-9 w-9 items-center justify-center rounded-xl pb-gradient-brand text-white"><Icon className="h-4 w-4" /></div>
      <div><p className="text-sm font-semibold">{title}</p><p className="text-xs text-muted-foreground">{desc}</p></div>
    </div>
  )
}
