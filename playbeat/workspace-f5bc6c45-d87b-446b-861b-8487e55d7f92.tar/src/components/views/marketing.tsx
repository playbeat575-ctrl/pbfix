'use client'

import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { GlassCard, SectionHeader, StatCard, StatusPill, TableSkeleton, EmptyState } from '@/components/shared'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { Switch } from '@/components/ui/switch'
import { Progress } from '@/components/ui/progress'
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog'
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog'
import { ScrollArea } from '@/components/ui/scroll-area'
import { cn } from '@/lib/utils'
import {
  Megaphone, Ticket, Mail, MessageSquare, Bell, Users, Gift, Star, Plus, Search, Pencil, Trash2,
  Send, CalendarClock, Sparkles, Percent, DollarSign, TrendingUp, Crown, Award, Heart, ChevronRight,
  CheckCircle2,
} from 'lucide-react'
import { useMemo, useState } from 'react'
import { toast } from 'sonner'
import { motion } from 'framer-motion'
import { formatPKR } from '@/lib/currency'

type Coupon = {
  id: string
  code: string
  type: string
  value: number
  minOrder: number
  maxDiscount: number | null
  usageLimit: number
  usedCount: number
  status: string
  validFrom: string
  validTo: string | null
  createdAt: string
}
type Campaign = {
  id: string
  name: string
  type: string
  channel: string
  status: string
  audience: string
  sent: number
  opened: number
  clicked: number
  createdAt: string
}

const COUPON_STATUSES = ['active', 'draft', 'expired']
const CAMPAIGN_TYPES = ['email', 'sms', 'push']
const TIERS = [
  { name: 'Bronze', min: 0, color: 'from-amber-600 to-orange-700', icon: Award },
  { name: 'Silver', min: 500, color: 'from-slate-400 to-slate-600', icon: Award },
  { name: 'Gold', min: 2000, color: 'from-amber-400 to-yellow-500', icon: Crown },
  { name: 'Platinum', min: 5000, color: 'from-cyan-400 to-blue-500', icon: Crown },
]

const RECENT_SUBSCRIBERS = [
  { email: 'olivia.martin@example.com', date: '2 hours ago', source: 'Footer form' },
  { email: 'liam.chen@example.com', date: '5 hours ago', source: 'Checkout opt-in' },
  { email: 'sofia.khan@example.com', date: '1 day ago', source: 'Pop-up' },
  { email: 'noah.park@example.com', date: '1 day ago', source: 'Footer form' },
  { email: 'emma.schmidt@example.com', date: '2 days ago', source: 'Account signup' },
]

export function MarketingView() {
  const [tab, setTab] = useState('coupons')

  return (
    <div className="space-y-6">
      <SectionHeader
        title="Marketing & Promotions"
        subtitle="Coupons, campaigns, loyalty & affiliates"
        icon={Megaphone}
        action={
          <Button size="sm" variant="outline" onClick={() => toast.info('Generating campaign performance report...')}>
            <TrendingUp className="mr-2 h-4 w-4" /> Performance
          </Button>
        }
      />

      <Tabs value={tab} onValueChange={setTab}>
        <ScrollArea className="w-full whitespace-nowrap">
          <TabsList className="h-auto">
            <TabsTrigger value="coupons" className="text-xs">Coupons</TabsTrigger>
            <TabsTrigger value="campaigns" className="text-xs">Campaigns</TabsTrigger>
            <TabsTrigger value="compose" className="text-xs">Email / Push / SMS</TabsTrigger>
            <TabsTrigger value="loyalty" className="text-xs">Referral & Loyalty</TabsTrigger>
            <TabsTrigger value="newsletter" className="text-xs">Newsletter</TabsTrigger>
          </TabsList>
        </ScrollArea>

        <TabsContent value="coupons" className="mt-4"><CouponsPanel /></TabsContent>
        <TabsContent value="campaigns" className="mt-4"><CampaignsPanel /></TabsContent>
        <TabsContent value="compose" className="mt-4"><ComposePanel /></TabsContent>
        <TabsContent value="loyalty" className="mt-4"><LoyaltyPanel /></TabsContent>
        <TabsContent value="newsletter" className="mt-4"><NewsletterPanel /></TabsContent>
      </Tabs>
    </div>
  )
}

/* ====================== COUPONS ====================== */
function CouponsPanel() {
  const qc = useQueryClient()
  const [status, setStatus] = useState('')
  const [search, setSearch] = useState('')
  const [editorOpen, setEditorOpen] = useState(false)
  const [editing, setEditing] = useState<Coupon | null>(null)
  const [deleteId, setDeleteId] = useState<string | null>(null)

  const qs = useMemo(() => {
    const p = new URLSearchParams()
    if (status) p.set('status', status)
    if (search) p.set('search', search)
    return p.toString()
  }, [status, search])

  const { data, isLoading } = useQuery<{ coupons: Coupon[] }>({
    queryKey: ['coupons', status, search],
    queryFn: () => fetch(`/api/coupons?${qs}`).then((r) => r.json()),
  })
  const coupons = data?.coupons || []

  const totalUsage = coupons.reduce((s, c) => s + c.usedCount, 0)
  const activeCount = coupons.filter((c) => c.status === 'active').length
  const top = coupons.slice().sort((a, b) => b.usedCount - a.usedCount)[0]

  const createMut = useMutation({
    mutationFn: (body: any) => fetch('/api/coupons', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }).then((r) => r.json()),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['coupons'] }); toast.success('Coupon created'); setEditorOpen(false) },
    onError: () => toast.error('Failed to create coupon'),
  })
  const updateMut = useMutation({
    mutationFn: ({ id, body }: { id: string; body: any }) => fetch(`/api/coupons/${id}`, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }).then((r) => r.json()),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['coupons'] }); toast.success('Coupon updated'); setEditorOpen(false); setEditing(null) },
  })
  const deleteMut = useMutation({
    mutationFn: (id: string) => fetch(`/api/coupons/${id}`, { method: 'DELETE' }).then((r) => r.json()),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['coupons'] }); toast.success('Coupon deleted'); setDeleteId(null) },
  })

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatCard title="Total Coupons" value={coupons.length} icon={Ticket} gradient="bg-gradient-to-br from-blue-500 to-cyan-500" delay={0} />
        <StatCard title="Active" value={activeCount} icon={Sparkles} gradient="bg-gradient-to-br from-emerald-500 to-teal-500" delay={0.05} />
        <StatCard title="Total Usage" value={totalUsage} icon={TrendingUp} gradient="bg-gradient-to-br from-orange-500 to-amber-500" delay={0.1} />
        <StatCard title="Top Performer" value={top?.code || '—'} icon={Star} gradient="bg-gradient-to-br from-red-500 to-orange-500" delay={0.15} />
      </div>

      <GlassCard className="p-4">
        <div className="flex flex-wrap items-center gap-3">
          <div className="relative min-w-[220px] flex-1">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input placeholder="Search coupon code..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-9" />
          </div>
          <Select value={status} onValueChange={(v) => setStatus(v === 'all' ? '' : v)}>
            <SelectTrigger className="w-[160px]"><SelectValue placeholder="Status" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All status</SelectItem>
              {COUPON_STATUSES.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}
            </SelectContent>
          </Select>
          <Button size="sm" className="ml-auto pb-gradient-brand" onClick={() => { setEditing(null); setEditorOpen(true) }}>
            <Plus className="mr-2 h-4 w-4" /> Create Coupon
          </Button>
        </div>
      </GlassCard>

      <GlassCard className="overflow-hidden">
        {isLoading ? (
          <div className="p-5"><TableSkeleton /></div>
        ) : coupons.length === 0 ? (
          <div className="p-5"><EmptyState icon={Ticket} title="No coupons found" description="Create your first discount code." action={<Button className="pb-gradient-brand" onClick={() => { setEditing(null); setEditorOpen(true) }}><Plus className="mr-2 h-4 w-4" /> Create Coupon</Button>} /></div>
        ) : (
          <div className="overflow-x-auto pb-scroll">
            <table className="w-full min-w-[900px] text-sm">
              <thead>
                <tr className="border-b border-border bg-muted/40 text-left text-xs uppercase tracking-wide text-muted-foreground">
                  <th className="px-4 py-3 font-semibold">Code</th>
                  <th className="px-4 py-3 font-semibold">Type</th>
                  <th className="px-4 py-3 font-semibold">Value</th>
                  <th className="px-4 py-3 font-semibold">Min Order</th>
                  <th className="px-4 py-3 font-semibold">Usage</th>
                  <th className="px-4 py-3 font-semibold">Status</th>
                  <th className="px-4 py-3 font-semibold">Validity</th>
                  <th className="px-4 py-3 text-right font-semibold">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {coupons.map((c) => {
                  const pct = c.usageLimit > 0 ? Math.min(100, (c.usedCount / c.usageLimit) * 100) : 0
                  return (
                    <tr key={c.id} className="transition hover:bg-accent/40">
                      <td className="px-4 py-3">
                        <code className="rounded-md bg-gradient-to-br from-red-500/10 to-orange-500/10 px-2 py-1 font-mono text-xs font-semibold text-red-600 dark:text-red-400 ring-1 ring-inset ring-red-500/20">{c.code}</code>
                      </td>
                      <td className="px-4 py-3">
                        <Badge variant="outline" className="text-xs">
                          {c.type === 'percentage' ? <><Percent className="mr-1 h-3 w-3" /> Percentage</> : <><DollarSign className="mr-1 h-3 w-3" /> Fixed</>}
                        </Badge>
                      </td>
                      <td className="px-4 py-3 font-semibold">{c.type === 'percentage' ? `${c.value}%` : formatPKR(c.value)}</td>
                      <td className="px-4 py-3 text-muted-foreground">{formatPKR(c.minOrder)}</td>
                      <td className="px-4 py-3">
                        <div className="w-32">
                          <div className="mb-1 flex justify-between text-xs">
                            <span className="font-medium">{c.usedCount}</span>
                            <span className="text-muted-foreground">/ {c.usageLimit || '∞'}</span>
                          </div>
                          <Progress value={pct} className="h-1.5" />
                        </div>
                      </td>
                      <td className="px-4 py-3"><StatusPill status={c.status} /></td>
                      <td className="px-4 py-3 text-xs text-muted-foreground">
                        {new Date(c.validFrom).toLocaleDateString()}
                        {c.validTo && ` → ${new Date(c.validTo).toLocaleDateString()}`}
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex items-center justify-end gap-1">
                          <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => { setEditing(c); setEditorOpen(true) }} title="Edit"><Pencil className="h-4 w-4" /></Button>
                          <Button variant="ghost" size="icon" className="h-8 w-8 text-red-600 hover:text-red-700" onClick={() => setDeleteId(c.id)} title="Delete"><Trash2 className="h-4 w-4" /></Button>
                        </div>
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        )}
      </GlassCard>

      <Dialog open={editorOpen} onOpenChange={(o) => { setEditorOpen(o); if (!o) setEditing(null) }}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto pb-scroll">
          <DialogHeader>
            <DialogTitle>{editing ? 'Edit Coupon' : 'Create Coupon'}</DialogTitle>
          </DialogHeader>
          <CouponForm
            initial={editing}
            onSubmit={(body) => {
              if (editing) updateMut.mutate({ id: editing.id, body })
              else createMut.mutate(body)
            }}
            loading={createMut.isPending || updateMut.isPending}
          />
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!deleteId} onOpenChange={(o) => !o && setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete coupon?</AlertDialogTitle>
            <AlertDialogDescription>This action cannot be undone. The coupon will no longer be redeemable.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction className="bg-red-600 hover:bg-red-700" onClick={() => deleteId && deleteMut.mutate(deleteId)}>Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}

function CouponForm({ initial, onSubmit, loading }: { initial: Coupon | null; onSubmit: (b: any) => void; loading: boolean }) {
  const [form, setForm] = useState({
    code: initial?.code || '',
    type: initial?.type || 'percentage',
    value: initial?.value ?? '',
    minOrder: initial?.minOrder ?? '',
    maxDiscount: initial?.maxDiscount ?? '',
    usageLimit: initial?.usageLimit ?? '',
    validFrom: initial ? new Date(initial.validFrom).toISOString().slice(0, 10) : new Date().toISOString().slice(0, 10),
    validTo: initial?.validTo ? new Date(initial.validTo).toISOString().slice(0, 10) : '',
    status: initial?.status || 'active',
  })
  const set = (k: string, v: any) => setForm((f) => ({ ...f, [k]: v }))

  const submit = () => {
    if (!form.code || !form.value) { toast.error('Code and value are required'); return }
    onSubmit({
      code: form.code.toUpperCase(),
      type: form.type,
      value: Number(form.value),
      minOrder: Number(form.minOrder) || 0,
      maxDiscount: form.maxDiscount ? Number(form.maxDiscount) : null,
      usageLimit: Number(form.usageLimit) || 0,
      validFrom: form.validFrom,
      validTo: form.validTo || null,
      status: form.status,
    })
  }

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <div className="space-y-1.5 sm:col-span-2">
          <Label>Coupon Code *</Label>
          <Input value={form.code} onChange={(e) => set('code', e.target.value.toUpperCase())} placeholder="SUMMER25" className="font-mono" />
        </div>
        <div className="space-y-1.5">
          <Label>Discount Type</Label>
          <Select value={form.type} onValueChange={(v) => set('type', v)}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="percentage">Percentage (%)</SelectItem>
              <SelectItem value="fixed">Fixed Amount ($)</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-1.5">
          <Label>Value *</Label>
          <Input type="number" step="0.01" value={form.value} onChange={(e) => set('value', e.target.value)} placeholder={form.type === 'percentage' ? '25' : '10'} />
        </div>
        <div className="space-y-1.5">
          <Label>Minimum Order ($)</Label>
          <Input type="number" step="0.01" value={form.minOrder} onChange={(e) => set('minOrder', e.target.value)} placeholder="0" />
        </div>
        <div className="space-y-1.5">
          <Label>Max Discount ($)</Label>
          <Input type="number" step="0.01" value={form.maxDiscount} onChange={(e) => set('maxDiscount', e.target.value)} placeholder="Optional" />
        </div>
        <div className="space-y-1.5">
          <Label>Usage Limit</Label>
          <Input type="number" value={form.usageLimit} onChange={(e) => set('usageLimit', e.target.value)} placeholder="0 = unlimited" />
        </div>
        <div className="space-y-1.5">
          <Label>Status</Label>
          <Select value={form.status} onValueChange={(v) => set('status', v)}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>{COUPON_STATUSES.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
          </Select>
        </div>
        <div className="space-y-1.5">
          <Label>Valid From</Label>
          <Input type="date" value={form.validFrom} onChange={(e) => set('validFrom', e.target.value)} />
        </div>
        <div className="space-y-1.5">
          <Label>Valid To</Label>
          <Input type="date" value={form.validTo} onChange={(e) => set('validTo', e.target.value)} />
        </div>
      </div>
      <DialogFooter>
        <Button variant="outline" onClick={() => {}}>Cancel</Button>
        <Button className="pb-gradient-brand" onClick={submit} disabled={loading}>{loading ? 'Saving...' : initial ? 'Save Changes' : 'Create Coupon'}</Button>
      </DialogFooter>
    </div>
  )
}

/* ====================== CAMPAIGNS ====================== */
function CampaignsPanel() {
  const qc = useQueryClient()
  const [editorOpen, setEditorOpen] = useState(false)

  const { data, isLoading } = useQuery<{ campaigns: Campaign[] }>({
    queryKey: ['campaigns'],
    queryFn: () => fetch('/api/campaigns').then((r) => r.json()),
  })
  const campaigns = data?.campaigns || []

  const createMut = useMutation({
    mutationFn: (body: any) => fetch('/api/campaigns', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }).then((r) => r.json()),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['campaigns'] }); toast.success('Campaign created'); setEditorOpen(false) },
  })
  const updateMut = useMutation({
    mutationFn: ({ id, body }: { id: string; body: any }) => fetch(`/api/campaigns/${id}`, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }).then((r) => r.json()),
    onSuccess: (c) => { qc.invalidateQueries({ queryKey: ['campaigns'] }); toast.success(`Campaign ${c.campaign.status}`) },
  })

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <p className="text-sm text-muted-foreground">{campaigns.length} campaigns · {campaigns.filter((c) => c.status === 'active').length} active</p>
        <Button size="sm" className="pb-gradient-brand" onClick={() => setEditorOpen(true)}><Plus className="mr-2 h-4 w-4" /> New Campaign</Button>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {Array.from({ length: 6 }).map((_, i) => <div key={i} className="h-48 rounded-2xl bg-muted pb-shimmer" />)}
        </div>
      ) : campaigns.length === 0 ? (
        <EmptyState icon={Megaphone} title="No campaigns yet" description="Launch your first marketing campaign." action={<Button className="pb-gradient-brand" onClick={() => setEditorOpen(true)}><Plus className="mr-2 h-4 w-4" /> New Campaign</Button>} />
      ) : (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {campaigns.map((c, i) => {
            const openRate = c.sent > 0 ? Math.round((c.opened / c.sent) * 100) : 0
            const clickRate = c.sent > 0 ? Math.round((c.clicked / c.sent) * 100) : 0
            const meta = channelMeta(c.type)
            return (
              <motion.div key={c.id} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3, delay: i * 0.04 }}>
                <GlassCard hover className="flex h-full flex-col p-4">
                  <div className="mb-3 flex items-start justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <div className={cn('flex h-9 w-9 items-center justify-center rounded-lg bg-gradient-to-br text-white', meta.gradient)}>
                        <meta.icon className="h-4.5 w-4.5" />
                      </div>
                      <div className="min-w-0">
                        <p className="truncate text-sm font-semibold">{c.name}</p>
                        <p className="text-xs text-muted-foreground capitalize">{c.type} · {c.channel}</p>
                      </div>
                    </div>
                    <StatusPill status={c.status} />
                  </div>
                  <div className="mb-3 flex items-center gap-1.5 text-xs text-muted-foreground">
                    <Users className="h-3 w-3" /> {c.audience}
                  </div>
                  <div className="grid grid-cols-3 gap-2 rounded-xl border border-border bg-muted/20 p-3 text-center">
                    <div>
                      <p className="text-base font-bold pb-count">{c.sent.toLocaleString()}</p>
                      <p className="text-[10px] text-muted-foreground">Sent</p>
                    </div>
                    <div>
                      <p className="text-base font-bold pb-count text-emerald-600 dark:text-emerald-400">{openRate}%</p>
                      <p className="text-[10px] text-muted-foreground">Opened</p>
                    </div>
                    <div>
                      <p className="text-base font-bold pb-count text-blue-600 dark:text-blue-400">{clickRate}%</p>
                      <p className="text-[10px] text-muted-foreground">Clicked</p>
                    </div>
                  </div>
                  <div className="mt-3">
                    <Progress value={openRate} className="h-1.5" />
                  </div>
                  <div className="mt-3 flex gap-2 pt-1">
                    {c.status === 'active' ? (
                      <Button size="sm" variant="outline" className="flex-1" onClick={() => updateMut.mutate({ id: c.id, body: { status: 'draft' } })}>Pause</Button>
                    ) : (
                      <Button size="sm" className="flex-1 pb-gradient-brand" onClick={() => updateMut.mutate({ id: c.id, body: { status: 'active' } })}>Activate</Button>
                    )}
                    <Button size="sm" variant="outline" onClick={() => toast.info(`Viewing analytics for "${c.name}"`)}><ChevronRight className="h-4 w-4" /></Button>
                  </div>
                </GlassCard>
              </motion.div>
            )
          })}
        </div>
      )}

      <Dialog open={editorOpen} onOpenChange={setEditorOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>New Campaign</DialogTitle></DialogHeader>
          <CampaignForm onSubmit={(b) => createMut.mutate(b)} loading={createMut.isPending} />
        </DialogContent>
      </Dialog>
    </div>
  )
}

function CampaignForm({ onSubmit, loading }: { onSubmit: (b: any) => void; loading: boolean }) {
  const [form, setForm] = useState({ name: '', type: 'email', channel: 'Email', audience: 'All Customers' })
  const set = (k: string, v: any) => setForm((f) => ({ ...f, [k]: v }))
  return (
    <div className="space-y-4">
      <div className="space-y-1.5">
        <Label>Campaign Name *</Label>
        <Input value={form.name} onChange={(e) => set('name', e.target.value)} placeholder="Summer Sale 2025" />
      </div>
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-1.5">
          <Label>Type</Label>
          <Select value={form.type} onValueChange={(v) => set('type', v)}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>{CAMPAIGN_TYPES.map((t) => <SelectItem key={t} value={t} className="capitalize">{t}</SelectItem>)}</SelectContent>
          </Select>
        </div>
        <div className="space-y-1.5">
          <Label>Channel</Label>
          <Input value={form.channel} onChange={(e) => set('channel', e.target.value)} />
        </div>
      </div>
      <div className="space-y-1.5">
        <Label>Audience</Label>
        <Select value={form.audience} onValueChange={(v) => set('audience', v)}>
          <SelectTrigger><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="All Customers">All Customers</SelectItem>
            <SelectItem value="VIP Customers">VIP Customers</SelectItem>
            <SelectItem value="Newsletter Subscribers">Newsletter Subscribers</SelectItem>
            <SelectItem value="Inactive Customers">Inactive Customers</SelectItem>
            <SelectItem value="New Customers">New Customers</SelectItem>
          </SelectContent>
        </Select>
      </div>
      <DialogFooter>
        <Button variant="outline" onClick={() => {}}>Cancel</Button>
        <Button className="pb-gradient-brand" onClick={() => { if (!form.name) { toast.error('Name required'); return } onSubmit(form) }} disabled={loading}>{loading ? 'Creating...' : 'Create Campaign'}</Button>
      </DialogFooter>
    </div>
  )
}

function channelMeta(type: string) {
  switch (type) {
    case 'email': return { icon: Mail, gradient: 'from-blue-500 to-cyan-500' }
    case 'sms': return { icon: MessageSquare, gradient: 'from-emerald-500 to-teal-500' }
    case 'push': return { icon: Bell, gradient: 'from-orange-500 to-red-500' }
    default: return { icon: Megaphone, gradient: 'from-slate-500 to-slate-700' }
  }
}

/* ====================== COMPOSE ====================== */
function ComposePanel() {
  const [channel, setChannel] = useState<'email' | 'sms' | 'push'>('email')
  const [subject, setSubject] = useState('')
  const [audience, setAudience] = useState('All Customers')
  const [template, setTemplate] = useState('')

  const sendTest = () => {
    if (!subject && channel !== 'sms') { toast.error('Add a subject first'); return }
    toast.success('Test message sent', { description: `Preview delivered to your ${channel} inbox.` })
  }
  const schedule = () => {
    toast.success('Message scheduled', { description: `Will be sent to "${audience}" tomorrow at 9:00 AM.` })
  }

  const meta = channelMeta(channel)

  return (
    <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
      <GlassCard className="p-5">
        <div className="mb-4 flex items-center gap-3">
          <div className={cn('flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br text-white shadow-md', meta.gradient)}>
            <meta.icon className="h-5 w-5" />
          </div>
          <div>
            <p className="text-sm font-semibold">Compose Message</p>
            <p className="text-xs text-muted-foreground">Email · SMS · Push notifications</p>
          </div>
        </div>

        <Tabs value={channel} onValueChange={(v) => setChannel(v as any)}>
          <TabsList className="mb-4 w-full">
            <TabsTrigger value="email" className="flex-1 text-xs"><Mail className="mr-1.5 h-3.5 w-3.5" /> Email</TabsTrigger>
            <TabsTrigger value="sms" className="flex-1 text-xs"><MessageSquare className="mr-1.5 h-3.5 w-3.5" /> SMS</TabsTrigger>
            <TabsTrigger value="push" className="flex-1 text-xs"><Bell className="mr-1.5 h-3.5 w-3.5" /> Push</TabsTrigger>
          </TabsList>
        </Tabs>

        <div className="space-y-3">
          <div className="space-y-1.5">
            <Label>{channel === 'sms' ? 'Sender Name' : 'Subject'}</Label>
            <Input value={subject} onChange={(e) => setSubject(e.target.value)} placeholder={channel === 'sms' ? 'PLAYBEAT' : '🎮 Summer Mega Sale — 30% off!'} />
          </div>
          <div className="space-y-1.5">
            <Label>Audience</Label>
            <Select value={audience} onValueChange={setAudience}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="All Customers">All Customers</SelectItem>
                <SelectItem value="Newsletter Subscribers">Newsletter Subscribers</SelectItem>
                <SelectItem value="VIP Customers">VIP Customers</SelectItem>
                <SelectItem value="Inactive Customers">Inactive Customers</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5">
            <Label>Template</Label>
            <Textarea rows={6} value={template} onChange={(e) => setTemplate(e.target.value)} placeholder={channel === 'sms' ? 'Hi {{name}}, flash sale ends tonight! Get 30% off with code FLASH30.' : 'Dear {{name}},\n\nOur biggest sale of the season is here...'} />
            <p className="text-xs text-muted-foreground">Use {`{{name}}`}, {`{{code}}`} for personalization.</p>
          </div>
          <div className="flex gap-2 pt-1">
            <Button variant="outline" className="flex-1" onClick={sendTest}><Send className="mr-2 h-4 w-4" /> Send Test</Button>
            <Button className="flex-1 pb-gradient-brand" onClick={schedule}><CalendarClock className="mr-2 h-4 w-4" /> Schedule</Button>
          </div>
        </div>
      </GlassCard>

      <GlassCard className="p-5">
        <div className="mb-4 flex items-center justify-between">
          <div>
            <p className="text-sm font-semibold">Recent Sends</p>
            <p className="text-xs text-muted-foreground">Latest delivered campaigns</p>
          </div>
          <Badge variant="secondary" className="text-xs">live</Badge>
        </div>
        <RecentSendsList filter={channel} />
      </GlassCard>
    </div>
  )
}

function RecentSendsList({ filter }: { filter: string }) {
  const { data, isLoading } = useQuery<{ campaigns: Campaign[] }>({
    queryKey: ['campaigns'],
    queryFn: () => fetch('/api/campaigns').then((r) => r.json()),
  })
  const list = (data?.campaigns || []).filter((c) => !filter || c.type === filter).slice(0, 6)
  if (isLoading) return <div className="py-4"><TableSkeleton rows={4} cols={2} /></div>
  if (list.length === 0) return <EmptyState icon={Send} title="No sends yet" description="Schedule a message to see it here." />
  return (
    <ScrollArea className="h-[360px] pr-2">
      <div className="space-y-2">
        {list.map((c) => {
          const meta = channelMeta(c.type)
          const openRate = c.sent > 0 ? Math.round((c.opened / c.sent) * 100) : 0
          return (
            <div key={c.id} className="rounded-xl border border-border p-3">
              <div className="flex items-start gap-2">
                <div className={cn('flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br text-white', meta.gradient)}>
                  <meta.icon className="h-4 w-4" />
                </div>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-medium">{c.name}</p>
                  <p className="text-xs text-muted-foreground">{c.sent.toLocaleString()} sent · {openRate}% open</p>
                </div>
                <StatusPill status={c.status} />
              </div>
            </div>
          )
        })}
      </div>
    </ScrollArea>
  )
}

/* ====================== LOYALTY ====================== */
function LoyaltyPanel() {
  const [referralEnabled, setReferralEnabled] = useState(true)
  const [referralReward, setReferralReward] = useState('5')
  const [pointsPerReferral, setPointsPerReferral] = useState('100')
  const [loyaltyEnabled, setLoyaltyEnabled] = useState(true)
  const [pointsPerDollar, setPointsPerDollar] = useState('1')
  const [redemptionRate, setRedemptionRate] = useState('100')

  return (
    <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
      {/* Referral Program */}
      <GlassCard className="p-5">
        <div className="mb-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-red-500 to-orange-500 text-white shadow-md">
              <Gift className="h-5 w-5" />
            </div>
            <div>
              <p className="text-sm font-semibold">Referral Program</p>
              <p className="text-xs text-muted-foreground">Reward customers for inviting friends</p>
            </div>
          </div>
          <Switch checked={referralEnabled} onCheckedChange={(v) => { setReferralEnabled(v); toast.info(`Referral program ${v ? 'enabled' : 'disabled'}`) }} />
        </div>

        <div className="mb-4 grid grid-cols-2 gap-3">
          <div className="rounded-xl border border-border p-3">
            <p className="text-xs text-muted-foreground">Total Referrals</p>
            <p className="text-xl font-bold pb-count">1,284</p>
          </div>
          <div className="rounded-xl border border-border p-3">
            <p className="text-xs text-muted-foreground">Rewards Given</p>
            <p className="text-xl font-bold pb-count">Rs 3,210</p>
          </div>
        </div>

        <div className="space-y-3">
          <div className="space-y-1.5">
            <Label>Referral Reward ($)</Label>
            <Input type="number" value={referralReward} onChange={(e) => setReferralReward(e.target.value)} />
          </div>
          <div className="space-y-1.5">
            <Label>Points per Referral</Label>
            <Input type="number" value={pointsPerReferral} onChange={(e) => setPointsPerReferral(e.target.value)} />
          </div>
          <Button className="w-full pb-gradient-brand" onClick={() => toast.success('Referral settings saved')}>
            <CheckCircle2 className="mr-2 h-4 w-4" /> Save Settings
          </Button>
        </div>
      </GlassCard>

      {/* Loyalty Rewards */}
      <GlassCard className="p-5">
        <div className="mb-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-violet-500 to-purple-500 text-white shadow-md">
              <Award className="h-5 w-5" />
            </div>
            <div>
              <p className="text-sm font-semibold">Loyalty Rewards</p>
              <p className="text-xs text-muted-foreground">Points, tiers & redemption</p>
            </div>
          </div>
          <Switch checked={loyaltyEnabled} onCheckedChange={(v) => { setLoyaltyEnabled(v); toast.info(`Loyalty program ${v ? 'enabled' : 'disabled'}`) }} />
        </div>

        <div className="mb-4 grid grid-cols-2 gap-3">
          <div className="space-y-1.5">
            <Label>Points per $1 spent</Label>
            <Input type="number" value={pointsPerDollar} onChange={(e) => setPointsPerDollar(e.target.value)} />
          </div>
          <div className="space-y-1.5">
            <Label>Redemption Rate (pts = $1)</Label>
            <Input type="number" value={redemptionRate} onChange={(e) => setRedemptionRate(e.target.value)} />
          </div>
        </div>

        <div className="space-y-2">
          <Label className="text-xs uppercase tracking-wide text-muted-foreground">Customer Tiers</Label>
          {TIERS.map((t) => (
            <div key={t.name} className="flex items-center gap-3 rounded-xl border border-border p-3">
              <div className={cn('flex h-9 w-9 items-center justify-center rounded-lg bg-gradient-to-br text-white shadow', t.color)}>
                <t.icon className="h-4.5 w-4.5" />
              </div>
              <div className="flex-1">
                <p className="text-sm font-semibold">{t.name}</p>
                <p className="text-xs text-muted-foreground">{t.min.toLocaleString()}+ points</p>
              </div>
              <Badge variant="secondary" className="text-xs">Tier {TIERS.indexOf(t) + 1}</Badge>
            </div>
          ))}
        </div>

        <Button className="mt-4 w-full pb-gradient-brand" onClick={() => toast.success('Loyalty settings saved')}>
          <CheckCircle2 className="mr-2 h-4 w-4" /> Save Settings
        </Button>
      </GlassCard>
    </div>
  )
}

/* ====================== NEWSLETTER ====================== */
function NewsletterPanel() {
  const [subject, setSubject] = useState('🎮 New Arrivals & Flash Deals')
  const [preview, setPreview] = useState('Discover this week\'s hottest game keys, AI tools, and software bundles — at unbeatable prices.')

  return (
    <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
      <div className="space-y-4 lg:col-span-2">
        <div className="grid grid-cols-2 gap-4">
          <StatCard title="Subscribers" value={4827} icon={Users} delta={4.2} deltaLabel="this week" gradient="bg-gradient-to-br from-blue-500 to-cyan-500" delay={0} />
          <StatCard title="Avg. Open Rate" value="42.6%" icon={Mail} delta={1.8} deltaLabel="vs last month" gradient="bg-gradient-to-br from-orange-500 to-amber-500" delay={0.05} />
        </div>

        <GlassCard className="p-5">
          <div className="mb-4 flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-blue-500 to-cyan-500 text-white shadow-md">
              <Mail className="h-5 w-5" />
            </div>
            <div>
              <p className="text-sm font-semibold">Compose Newsletter</p>
              <p className="text-xs text-muted-foreground">Send a broadcast to all subscribers</p>
            </div>
          </div>
          <div className="space-y-3">
            <div className="space-y-1.5">
              <Label>Subject</Label>
              <Input value={subject} onChange={(e) => setSubject(e.target.value)} />
            </div>
            <div className="space-y-1.5">
              <Label>Preview Text</Label>
              <Input value={preview} onChange={(e) => setPreview(e.target.value)} />
            </div>
            <div className="space-y-1.5">
              <Label>Body</Label>
              <Textarea rows={8} placeholder="Write your newsletter content. Use Markdown for formatting..." defaultValue={'# 🎮 This Week at Playbeat\n\n**Flash Sale Alert!** Get up to 40% off on top game keys...\n\n## Featured Deals\n- Cyberpunk 2077 — 30% off\n- ChatGPT Plus — $19.99\n- Spotify Premium 1Y — $59\n\nShop now → https://playbeat.digital'} />
            </div>
            <div className="flex gap-2">
              <Button variant="outline" className="flex-1" onClick={() => toast.success('Test email sent', { description: 'Check your inbox.' })}><Send className="mr-2 h-4 w-4" /> Send Test</Button>
              <Button className="flex-1 pb-gradient-brand" onClick={() => toast.success('Newsletter sent', { description: 'Broadcasting to 4,827 subscribers.' })}><Megaphone className="mr-2 h-4 w-4" /> Send Newsletter</Button>
            </div>
          </div>
        </GlassCard>
      </div>

      <GlassCard className="p-5">
        <div className="mb-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-emerald-500 to-teal-500 text-white shadow-md">
              <Heart className="h-5 w-5" />
            </div>
            <div>
              <p className="text-sm font-semibold">Recent Subscribers</p>
              <p className="text-xs text-muted-foreground">Latest 5 signups</p>
            </div>
          </div>
          <Badge variant="secondary" className="text-xs">+24 today</Badge>
        </div>
        <ScrollArea className="h-[420px] pr-2">
          <div className="space-y-2">
            {RECENT_SUBSCRIBERS.map((s, i) => (
              <div key={i} className="flex items-center gap-3 rounded-xl border border-border p-3">
                <div className="flex h-9 w-9 items-center justify-center rounded-full bg-gradient-to-br from-blue-500 to-cyan-500 text-xs font-bold text-white">
                  {s.email.slice(0, 2).toUpperCase()}
                </div>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-medium">{s.email}</p>
                  <p className="text-xs text-muted-foreground">{s.source}</p>
                </div>
                <span className="text-xs text-muted-foreground">{s.date}</span>
              </div>
            ))}
          </div>
        </ScrollArea>
      </GlassCard>
    </div>
  )
}
