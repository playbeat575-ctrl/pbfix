'use client'

import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { GlassCard, SectionHeader, StatusPill, TableSkeleton, EmptyState } from '@/components/shared'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Switch } from '@/components/ui/switch'
import { Slider } from '@/components/ui/slider'
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { ScrollArea } from '@/components/ui/scroll-area'
import { cn } from '@/lib/utils'
import {
  Boxes, Package, DollarSign, AlertTriangle, XCircle, KeyRound, Search, Eye, EyeOff,
  RefreshCw, Plug, CheckCircle2, Server, Database, Zap, Plus, Settings2, Mail,
} from 'lucide-react'
import { useMemo, useState } from 'react'
import { toast } from 'sonner'
import { motion } from 'framer-motion'
import { formatPKR } from '@/lib/currency'

type InventorySummary = {
  totalProducts: number
  totalStock: number
  totalValue: number
  lowStockCount: number
  outOfStockCount: number
  availableKeys: number
  usedKeys: number
}
type InventoryItem = {
  id: string
  name: string
  type: string
  sku: string
  stock: number
  price: number
  value: number
  status: string
  hasLicenseKeys: boolean
}
type LicenseKey = {
  id: string
  productId: string
  productName: string
  key: string
  status: string
  orderId: string | null
  createdAt: string
}

const LICENSE_STATUSES = ['available', 'assigned', 'used', 'revoked']

const SUPPLIERS = [
  { id: 'SUP-01', name: 'CDKeys Wholesale', endpoint: 'https://api.cdkeys.com/v2/inventory', lastSync: '2 min ago', status: 'active' },
  { id: 'SUP-02', name: 'GameStop Connect', endpoint: 'https://api.gamestop.com/sync', lastSync: '14 min ago', status: 'active' },
  { id: 'SUP-03', name: 'Steam Distributor', endpoint: 'https://partner.steampowered.com/api/stock', lastSync: '1 hour ago', status: 'active' },
  { id: 'SUP-04', name: 'Eneba Reseller', endpoint: 'https://api.eneba.com/v1/stock', lastSync: '5 hours ago', status: 'paused' },
]

const SYNC_LOG = [
  { id: 1, supplier: 'CDKeys Wholesale', items: 142, status: 'success', time: '2 min ago' },
  { id: 2, supplier: 'GameStop Connect', items: 38, status: 'success', time: '14 min ago' },
  { id: 3, supplier: 'Steam Distributor', items: 0, status: 'warning', time: '1 hour ago', note: 'No new items' },
  { id: 4, supplier: 'CDKeys Wholesale', items: 27, status: 'success', time: '3 hours ago' },
  { id: 5, supplier: 'Eneba Reseller', items: 0, status: 'error', time: '5 hours ago', note: 'Auth failed' },
]

export function InventoryView() {
  const [tab, setTab] = useState('stock')

  const { data, isLoading } = useQuery<{ summary: InventorySummary; lowStock: any[]; outOfStock: any[]; items: InventoryItem[] }>({
    queryKey: ['inventory'],
    queryFn: () => fetch('/api/inventory').then((r) => r.json()),
  })
  const summary = data?.summary
  const items = data?.items || []
  const lowStock = data?.lowStock || []
  const outOfStock = data?.outOfStock || []

  const hasAlerts = (summary?.lowStockCount ?? 0) + (summary?.outOfStockCount ?? 0) > 0

  return (
    <div className="space-y-6">
      <SectionHeader
        title="Inventory Management"
        subtitle="Stock monitoring, digital licenses & auto-sync"
        icon={Boxes}
        action={
          <Button size="sm" className="pb-gradient-brand" onClick={() => toast.success('Sync started', { description: 'Pulling latest stock from all suppliers...' })}>
            <RefreshCw className="mr-2 h-4 w-4" /> Sync Now
          </Button>
        }
      />

      {/* Low stock alert banner */}
      {hasAlerts && !isLoading && (
        <motion.div initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }}>
          <GlassCard className="flex flex-wrap items-center gap-4 border-l-4 border-l-amber-500 p-4">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-amber-500/15 text-amber-600 dark:text-amber-400">
              <AlertTriangle className="h-5 w-5" />
            </div>
            <div className="min-w-0 flex-1">
              <p className="text-sm font-semibold">Inventory attention needed</p>
              <p className="text-xs text-muted-foreground">
                <span className="font-semibold text-amber-600">{summary?.lowStockCount ?? 0} low stock</span>
                {' · '}
                <span className="font-semibold text-red-600">{summary?.outOfStockCount ?? 0} out of stock</span>
                {' — restock or enable auto-sync to avoid lost sales.'}
              </p>
            </div>
            <Button size="sm" variant="outline" onClick={() => setTab('sync')}>Configure auto-sync</Button>
          </GlassCard>
        </motion.div>
      )}

      {/* Summary stat cards */}
      {isLoading || !summary ? (
        <div className="grid grid-cols-2 gap-4 lg:grid-cols-3 xl:grid-cols-6">
          {Array.from({ length: 6 }).map((_, i) => <div key={i} className="h-28 rounded-2xl bg-muted pb-shimmer" />)}
        </div>
      ) : (
        <div className="grid grid-cols-2 gap-4 lg:grid-cols-3 xl:grid-cols-6">
          <SummaryStat label="Total Products" value={summary.totalProducts} icon={Package} gradient="from-blue-500 to-cyan-500" delay={0} />
          <SummaryStat label="Stock Units" value={summary.totalStock} icon={Boxes} gradient="from-orange-500 to-red-500" delay={0.04} />
          <SummaryStat label="Inventory Value" value={formatPKR(summary.totalValue)} icon={DollarSign} gradient="from-emerald-500 to-teal-500" delay={0.08} />
          <SummaryStat label="Low Stock" value={summary.lowStockCount} icon={AlertTriangle} gradient="from-amber-500 to-yellow-500" delay={0.12} />
          <SummaryStat label="Out of Stock" value={summary.outOfStockCount} icon={XCircle} gradient="from-red-500 to-rose-500" delay={0.16} />
          <SummaryStat label="License Keys" value={summary.availableKeys} icon={KeyRound} gradient="from-violet-500 to-purple-500" delay={0.2} />
        </div>
      )}

      <Tabs value={tab} onValueChange={setTab}>
        <TabsList className="h-auto flex-wrap">
          <TabsTrigger value="stock" className="text-xs">Stock Monitoring</TabsTrigger>
          <TabsTrigger value="licenses" className="text-xs">License Keys</TabsTrigger>
          <TabsTrigger value="api" className="text-xs">API Inventory</TabsTrigger>
          <TabsTrigger value="sync" className="text-xs">Auto Sync</TabsTrigger>
        </TabsList>

        {/* Stock monitoring */}
        <TabsContent value="stock" className="mt-4">
          <GlassCard className="overflow-hidden">
            {isLoading ? (
              <div className="p-5"><TableSkeleton /></div>
            ) : items.length === 0 ? (
              <div className="p-5"><EmptyState icon={Boxes} title="No inventory items" /></div>
            ) : (
              <div className="overflow-x-auto pb-scroll">
                <table className="w-full min-w-[860px] text-sm">
                  <thead>
                    <tr className="border-b border-border bg-muted/40 text-left text-xs uppercase tracking-wide text-muted-foreground">
                      <th className="px-4 py-3 font-semibold">Product</th>
                      <th className="px-4 py-3 font-semibold">SKU</th>
                      <th className="px-4 py-3 font-semibold">Type</th>
                      <th className="px-4 py-3 font-semibold">Stock</th>
                      <th className="px-4 py-3 font-semibold">Value</th>
                      <th className="px-4 py-3 font-semibold">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-border">
                    {items.map((it) => {
                      const isOut = it.stock === 0
                      const isLow = it.stock > 0 && it.stock < 15
                      return (
                        <tr key={it.id} className={cn('transition hover:bg-accent/40', isLow && 'bg-amber-500/5', isOut && 'bg-red-500/5')}>
                          <td className="px-4 py-3">
                            <div className="flex items-center gap-2">
                              <p className="font-medium">{it.name}</p>
                              {it.hasLicenseKeys && <KeyRound className="h-3 w-3 text-muted-foreground" />}
                            </div>
                          </td>
                          <td className="px-4 py-3 font-mono text-xs text-muted-foreground">{it.sku}</td>
                          <td className="px-4 py-3"><Badge variant="outline" className="text-xs">{it.type}</Badge></td>
                          <td className="px-4 py-3">
                            <span className={cn('font-semibold', isOut ? 'text-red-600 dark:text-red-400' : isLow ? 'text-amber-600 dark:text-amber-400' : 'text-emerald-600 dark:text-emerald-400')}>
                              {it.stock}
                            </span>
                            {isLow && !isOut && <span className="ml-2 text-xs text-amber-600">low</span>}
                          </td>
                          <td className="px-4 py-3 font-semibold">{formatPKR(it.value)}</td>
                          <td className="px-4 py-3">
                            <StatusPill status={it.status === 'healthy' ? 'active' : it.status === 'low' ? 'pending' : 'out_of_stock'} />
                          </td>
                        </tr>
                      )
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </GlassCard>
        </TabsContent>

        {/* License keys */}
        <TabsContent value="licenses" className="mt-4">
          <LicenseKeysPanel />
        </TabsContent>

        {/* API inventory */}
        <TabsContent value="api" className="mt-4">
          <ApiInventoryPanel />
        </TabsContent>

        {/* Auto sync */}
        <TabsContent value="sync" className="mt-4">
          <AutoSyncPanel />
        </TabsContent>
      </Tabs>
    </div>
  )
}

function SummaryStat({ label, value, icon: Icon, gradient, delay }: { label: string; value: string | number; icon: any; gradient: string; delay: number }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35, delay }}
      className="pb-glass flex flex-col gap-2 rounded-2xl p-4 pb-lift"
    >
      <div className={`flex h-9 w-9 items-center justify-center rounded-lg bg-gradient-to-br ${gradient} text-white shadow-md`}>
        <Icon className="h-4.5 w-4.5" />
      </div>
      <div>
        <p className="text-xl font-bold pb-count">{value}</p>
        <p className="text-xs text-muted-foreground">{label}</p>
      </div>
    </motion.div>
  )
}

function LicenseKeysPanel() {
  const qc = useQueryClient()
  const [status, setStatus] = useState('')
  const [search, setSearch] = useState('')
  const [revealed, setRevealed] = useState<Record<string, boolean>>({})

  const qs = useMemo(() => {
    const p = new URLSearchParams()
    if (status) p.set('status', status)
    if (search) p.set('search', search)
    return p.toString()
  }, [status, search])

  const { data, isLoading } = useQuery<{ keys: LicenseKey[] }>({
    queryKey: ['license-keys', status, search],
    queryFn: () => fetch(`/api/license-keys?${qs}`).then((r) => r.json()),
  })
  const keys = data?.keys || []
  const availableCount = keys.filter((k) => k.status === 'available').length

  const toggleReveal = (id: string) => setRevealed((r) => ({ ...r, [id]: !r[id] }))

  const maskKey = (key: string) => {
    const parts = key.split('-')
    if (parts.length < 2) return '••••-••••-••••'
    return parts.map((p, i) => (i === parts.length - 1 ? p : '•'.repeat(Math.max(4, p.length)))).join('-')
  }

  const generateMut = useMutation({
    mutationFn: (body: any) => fetch('/api/license-keys', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }).then((r) => r.json()),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['license-keys'] }); toast.success('Keys generated', { description: 'New license keys added to the pool.' }) },
    onError: () => toast.error('Failed to generate keys'),
  })

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <GlassCard className="flex items-center gap-3 p-4">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-emerald-500 to-teal-500 text-white"><KeyRound className="h-5 w-5" /></div>
          <div><p className="text-xl font-bold pb-count">{availableCount}</p><p className="text-xs text-muted-foreground">Available keys</p></div>
        </GlassCard>
        <GlassCard className="flex items-center gap-3 p-4">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-orange-500 to-amber-500 text-white"><KeyRound className="h-5 w-5" /></div>
          <div><p className="text-xl font-bold pb-count">{keys.filter((k) => k.status === 'assigned').length}</p><p className="text-xs text-muted-foreground">Assigned</p></div>
        </GlassCard>
        <GlassCard className="flex items-center gap-3 p-4">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-slate-500 to-slate-700 text-white"><KeyRound className="h-5 w-5" /></div>
          <div><p className="text-xl font-bold pb-count">{keys.filter((k) => k.status === 'used').length}</p><p className="text-xs text-muted-foreground">Used</p></div>
        </GlassCard>
      </div>

      <GlassCard className="p-4">
        <div className="flex flex-wrap items-center gap-3">
          <div className="relative min-w-[220px] flex-1">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input placeholder="Search by product or key..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-9" />
          </div>
          <Select value={status} onValueChange={(v) => setStatus(v === 'all' ? '' : v)}>
            <SelectTrigger className="w-[170px]"><SelectValue placeholder="Status" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All status</SelectItem>
              {LICENSE_STATUSES.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}
            </SelectContent>
          </Select>
          <Button size="sm" className="ml-auto pb-gradient-brand" onClick={() => generateMut.mutate({ productId: 'bulk', count: 10 })} disabled={generateMut.isPending}>
            <Plus className="mr-2 h-4 w-4" /> Generate Keys
          </Button>
        </div>
      </GlassCard>

      <GlassCard className="overflow-hidden">
        {isLoading ? (
          <div className="p-5"><TableSkeleton /></div>
        ) : keys.length === 0 ? (
          <div className="p-5"><EmptyState icon={KeyRound} title="No license keys found" description="Generate keys for digital products." /></div>
        ) : (
          <div className="overflow-x-auto pb-scroll">
            <table className="w-full min-w-[760px] text-sm">
              <thead>
                <tr className="border-b border-border bg-muted/40 text-left text-xs uppercase tracking-wide text-muted-foreground">
                  <th className="px-4 py-3 font-semibold">License Key</th>
                  <th className="px-4 py-3 font-semibold">Product</th>
                  <th className="px-4 py-3 font-semibold">Status</th>
                  <th className="px-4 py-3 font-semibold">Created</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {keys.slice(0, 80).map((k) => (
                  <tr key={k.id} className="transition hover:bg-accent/40">
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2">
                        <code className="rounded bg-muted px-2 py-1 font-mono text-xs">{revealed[k.id] ? k.key : maskKey(k.key)}</code>
                        <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => toggleReveal(k.id)}>
                          {revealed[k.id] ? <EyeOff className="h-3.5 w-3.5" /> : <Eye className="h-3.5 w-3.5" />}
                        </Button>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-xs">{k.productName}</td>
                    <td className="px-4 py-3"><StatusPill status={k.status} /></td>
                    <td className="px-4 py-3 text-xs text-muted-foreground">{new Date(k.createdAt).toLocaleDateString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </GlassCard>
    </div>
  )
}

function ApiInventoryPanel() {
  const [endpoint, setEndpoint] = useState('')
  const [apiKey, setApiKey] = useState('')
  const [interval, setInterval] = useState('15')
  const [autoSync, setAutoSync] = useState(true)
  const [testing, setTesting] = useState(false)

  const testConnection = () => {
    if (!endpoint) { toast.error('Enter an API endpoint first'); return }
    setTesting(true)
    setTimeout(() => {
      setTesting(false)
      toast.success('Connection successful', { description: 'Supplier API reachable. Ready to sync inventory.' })
    }, 1100)
  }

  return (
    <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
      <GlassCard className="p-5">
        <div className="mb-4 flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-blue-500 to-cyan-500 text-white shadow-md">
            <Plug className="h-5 w-5" />
          </div>
          <div>
            <p className="text-sm font-semibold">Connect Supplier API</p>
            <p className="text-xs text-muted-foreground">Sync stock from external supplier endpoints</p>
          </div>
        </div>
        <div className="space-y-3">
          <div className="space-y-1.5">
            <Label>API Endpoint URL</Label>
            <Input placeholder="https://api.supplier.com/v2/inventory" value={endpoint} onChange={(e) => setEndpoint(e.target.value)} />
          </div>
          <div className="space-y-1.5">
            <Label>API Key</Label>
            <Input type="password" placeholder="••••••••••••" value={apiKey} onChange={(e) => setApiKey(e.target.value)} />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label>Sync Interval</Label>
              <Select value={interval} onValueChange={setInterval}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="5">Every 5 min</SelectItem>
                  <SelectItem value="15">Every 15 min</SelectItem>
                  <SelectItem value="30">Every 30 min</SelectItem>
                  <SelectItem value="60">Every hour</SelectItem>
                  <SelectItem value="360">Every 6 hours</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-end">
              <div className="flex w-full items-center justify-between gap-2 rounded-xl border border-border bg-muted/30 p-3">
                <div>
                  <p className="text-sm font-medium">Auto-Sync</p>
                  <p className="text-xs text-muted-foreground">Pull on schedule</p>
                </div>
                <Switch checked={autoSync} onCheckedChange={setAutoSync} />
              </div>
            </div>
          </div>
          <div className="flex gap-2 pt-1">
            <Button variant="outline" className="flex-1" onClick={testConnection} disabled={testing}>
              {testing ? <><RefreshCw className="mr-2 h-4 w-4 animate-spin" /> Testing...</> : <><Zap className="mr-2 h-4 w-4" /> Test Connection</>}
            </Button>
            <Button className="flex-1 pb-gradient-brand" onClick={() => toast.success('Supplier connected', { description: 'Inventory will sync automatically.' })}>
              <CheckCircle2 className="mr-2 h-4 w-4" /> Connect
            </Button>
          </div>
        </div>
      </GlassCard>

      <GlassCard className="p-5">
        <div className="mb-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-violet-500 to-purple-500 text-white shadow-md">
              <Server className="h-5 w-5" />
            </div>
            <div>
              <p className="text-sm font-semibold">Connected Suppliers</p>
              <p className="text-xs text-muted-foreground">{SUPPLIERS.length} suppliers · {SUPPLIERS.filter((s) => s.status === 'active').length} active</p>
            </div>
          </div>
          <Badge variant="secondary" className="text-xs">{SUPPLIERS.length}</Badge>
        </div>
        <ScrollArea className="h-[320px] pr-2">
          <div className="space-y-2">
            {SUPPLIERS.map((s) => (
              <div key={s.id} className="rounded-xl border border-border p-3">
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <p className="truncate text-sm font-semibold">{s.name}</p>
                    <p className="truncate font-mono text-[10px] text-muted-foreground">{s.endpoint}</p>
                  </div>
                  <StatusPill status={s.status} />
                </div>
                <div className="mt-2 flex items-center justify-between">
                  <span className="flex items-center gap-1 text-xs text-muted-foreground"><Database className="h-3 w-3" /> Last sync: {s.lastSync}</span>
                  <Button variant="ghost" size="sm" className="h-7 text-xs" onClick={() => toast.success(`Syncing ${s.name}...`)}>
                    <RefreshCw className="mr-1 h-3 w-3" /> Sync
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </ScrollArea>
      </GlassCard>
    </div>
  )
}

function AutoSyncPanel() {
  const [autoSync, setAutoSync] = useState(true)
  const [threshold, setThreshold] = useState(15)
  const [frequency, setFrequency] = useState('30')
  const [emailAlerts, setEmailAlerts] = useState(true)

  return (
    <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
      <GlassCard className="p-5">
        <div className="mb-4 flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-orange-500 to-red-500 text-white shadow-md">
            <Settings2 className="h-5 w-5" />
          </div>
          <div>
            <p className="text-sm font-semibold">Auto-Sync Settings</p>
            <p className="text-xs text-muted-foreground">Automate inventory restocking</p>
          </div>
        </div>
        <div className="space-y-5">
          <div className="flex items-center justify-between gap-2 rounded-xl border border-border bg-muted/30 p-3">
            <div>
              <p className="text-sm font-medium">Enable Auto-Sync</p>
              <p className="text-xs text-muted-foreground">Pull stock automatically on schedule</p>
            </div>
            <Switch
              checked={autoSync}
              onCheckedChange={(v) => { setAutoSync(v); toast.info(`Auto-sync ${v ? 'enabled' : 'disabled'}`) }}
            />
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label>Low Stock Threshold</Label>
              <Badge variant="secondary" className="text-xs">{threshold} units</Badge>
            </div>
            <Slider value={[threshold]} min={5} max={50} step={1} onValueChange={(v) => setThreshold(v[0])} />
            <p className="text-xs text-muted-foreground">Items below this count trigger an alert and auto-restock request.</p>
          </div>

          <div className="space-y-1.5">
            <Label>Sync Frequency</Label>
            <Select value={frequency} onValueChange={(v) => { setFrequency(v); toast.info(`Frequency set: every ${v} min`) }}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="5">Every 5 min</SelectItem>
                <SelectItem value="15">Every 15 min</SelectItem>
                <SelectItem value="30">Every 30 min</SelectItem>
                <SelectItem value="60">Every hour</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex items-center justify-between gap-2 rounded-xl border border-border bg-muted/30 p-3">
            <div className="flex items-center gap-2">
              <Mail className="h-4 w-4 text-muted-foreground" />
              <div>
                <p className="text-sm font-medium">Email Alerts</p>
                <p className="text-xs text-muted-foreground">Notify on low/out-of-stock</p>
              </div>
            </div>
            <Switch
              checked={emailAlerts}
              onCheckedChange={(v) => { setEmailAlerts(v); toast.info(`Email alerts ${v ? 'on' : 'off'}`) }}
            />
          </div>

          <Button className="w-full pb-gradient-brand" onClick={() => toast.success('Sync settings saved')}>
            <CheckCircle2 className="mr-2 h-4 w-4" /> Save Settings
          </Button>
        </div>
      </GlassCard>

      <GlassCard className="p-5">
        <div className="mb-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-blue-500 to-cyan-500 text-white shadow-md">
              <RefreshCw className="h-5 w-5" />
            </div>
            <div>
              <p className="text-sm font-semibold">Recent Sync Log</p>
              <p className="text-xs text-muted-foreground">Last sync operations</p>
            </div>
          </div>
          <Button variant="ghost" size="sm" onClick={() => toast.info('Loading full sync history...')}>View all</Button>
        </div>
        <ScrollArea className="h-[380px] pr-2">
          <div className="space-y-2">
            {SYNC_LOG.map((log) => (
              <div key={log.id} className="flex items-center gap-3 rounded-xl border border-border p-3">
                <div className={cn(
                  'flex h-8 w-8 items-center justify-center rounded-lg',
                  log.status === 'success' && 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400',
                  log.status === 'warning' && 'bg-amber-500/10 text-amber-600 dark:text-amber-400',
                  log.status === 'error' && 'bg-red-500/10 text-red-600 dark:text-red-400',
                )}>
                  {log.status === 'success' ? <CheckCircle2 className="h-4 w-4" /> : log.status === 'warning' ? <AlertTriangle className="h-4 w-4" /> : <XCircle className="h-4 w-4" />}
                </div>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-medium">{log.supplier}</p>
                  <p className="text-xs text-muted-foreground">{log.note || `${log.items} item(s) synced`}</p>
                </div>
                <span className="text-xs text-muted-foreground">{log.time}</span>
              </div>
            ))}
          </div>
        </ScrollArea>
      </GlassCard>
    </div>
  )
}
