'use client'

import { useEffect } from 'react'
import { useNav } from '@/lib/nav-store'
import { Sidebar } from '@/components/layout/sidebar'
import { Header } from '@/components/layout/header'
import { Footer } from '@/components/layout/footer'
import { CommandPalette } from '@/components/layout/command-palette'
import { DashboardView } from '@/components/views/dashboard'
import { ProductsView } from '@/components/views/products'
import { HomepageView } from '@/components/views/homepage'
import { OrdersView } from '@/components/views/orders'
import { CustomersView } from '@/components/views/customers'
import { PaymentsView } from '@/components/views/payments'
import { InventoryView } from '@/components/views/inventory'
import { MarketingView } from '@/components/views/marketing'
import { ReportsView } from '@/components/views/reports'
import { UsersView } from '@/components/views/users'
import { SecurityView } from '@/components/views/security'
import { SettingsView } from '@/components/views/settings'
import { AnimatePresence, motion } from 'framer-motion'

export default function Home() {
  const { view, setCommandOpen } = useNav()

  // Global ⌘K shortcut
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault()
        setCommandOpen(true)
      }
    }
    window.addEventListener('keydown', handler)
    return () => window.removeEventListener('keydown', handler)
  }, [setCommandOpen])

  const View = (() => {
    switch (view) {
      case 'dashboard': return <DashboardView />
      case 'products': return <ProductsView />
      case 'homepage': return <HomepageView />
      case 'orders': return <OrdersView />
      case 'customers': return <CustomersView />
      case 'payments': return <PaymentsView />
      case 'inventory': return <InventoryView />
      case 'marketing': return <MarketingView />
      case 'reports': return <ReportsView />
      case 'users': return <UsersView />
      case 'security': return <SecurityView />
      case 'settings': return <SettingsView />
      default: return <DashboardView />
    }
  })()

  return (
    <div className="pb-app-bg flex min-h-screen flex-col bg-background">
      <div className="flex flex-1 overflow-hidden">
        <Sidebar />
        <div className="flex min-w-0 flex-1 flex-col">
          <Header />
          <main className="flex-1 overflow-y-auto pb-scroll px-4 py-6 sm:px-6 lg:px-8">
            <AnimatePresence mode="wait">
              <motion.div
                key={view}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -4 }}
                transition={{ duration: 0.25 }}
                className="mx-auto w-full max-w-[1600px]"
              >
                {View}
              </motion.div>
            </AnimatePresence>
          </main>
          <Footer />
        </div>
      </div>
      <CommandPalette />
    </div>
  )
}
