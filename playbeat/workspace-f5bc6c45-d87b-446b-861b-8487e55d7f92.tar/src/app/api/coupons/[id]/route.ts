import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function PUT(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  const body = await req.json()
  const data: any = { ...body }
  if (data.value !== undefined) data.value = Number(data.value)
  if (data.minOrder !== undefined) data.minOrder = Number(data.minOrder)
  if (data.usageLimit !== undefined) data.usageLimit = Number(data.usageLimit)
  if (data.validFrom) data.validFrom = new Date(data.validFrom)
  if (data.validTo) data.validTo = new Date(data.validTo)
  const coupon = await db.coupon.update({ where: { id }, data })
  return NextResponse.json({ coupon })
}

export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  await db.coupon.delete({ where: { id } })
  return NextResponse.json({ ok: true })
}
