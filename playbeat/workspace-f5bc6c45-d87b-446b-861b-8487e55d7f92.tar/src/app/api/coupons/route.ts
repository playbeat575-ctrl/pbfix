import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url)
  const status = searchParams.get('status') || ''
  const search = searchParams.get('search') || ''
  const where: any = {}
  if (status) where.status = status
  if (search) where.code = { contains: search }
  const coupons = await db.coupon.findMany({ where, orderBy: { createdAt: 'desc' } })
  return NextResponse.json({ coupons })
}

export async function POST(req: NextRequest) {
  const body = await req.json()
  const coupon = await db.coupon.create({
    data: {
      code: body.code.toUpperCase(),
      type: body.type,
      value: Number(body.value),
      minOrder: Number(body.minOrder) || 0,
      maxDiscount: body.maxDiscount ? Number(body.maxDiscount) : null,
      usageLimit: Number(body.usageLimit) || 0,
      status: body.status || 'active',
      validFrom: body.validFrom ? new Date(body.validFrom) : new Date(),
      validTo: body.validTo ? new Date(body.validTo) : null,
    },
  })
  await db.auditLog.create({ data: { action: 'coupon.create', module: 'Marketing', user: 'Admin', details: `Created coupon ${coupon.code}` } })
  return NextResponse.json({ coupon })
}
