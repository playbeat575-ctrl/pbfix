import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET() {
  const rows = await db.setting.findMany()
  const settings: Record<string, string> = {}
  for (const r of rows) settings[r.id] = r.value
  return NextResponse.json({ settings })
}

export async function PUT(req: NextRequest) {
  const body = (await req.json()) as Record<string, string>
  for (const [k, v] of Object.entries(body)) {
    await db.setting.upsert({ where: { id: k }, create: { id: k, value: String(v) }, update: { value: String(v) } })
  }
  await db.auditLog.create({ data: { action: 'settings.update', module: 'Settings', user: 'Admin', details: `Updated ${Object.keys(body).length} setting(s)` } })
  return NextResponse.json({ ok: true })
}
