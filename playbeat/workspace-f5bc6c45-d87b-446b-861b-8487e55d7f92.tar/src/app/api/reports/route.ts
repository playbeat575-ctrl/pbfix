import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url)
  const range = searchParams.get('range') || 'monthly' // daily, weekly, monthly, yearly
  const [orders, products, customers, payments, coupons, reviews] = await Promise.all([
    db.order.findMany(),
    db.product.findMany(),
    db.customer.findMany(),
    db.payment.findMany(),
    db.coupon.findMany(),
    db.review.findMany(),
  ])

  const paidOrders = orders.filter((o) => o.paymentStatus === 'paid')
  const totalRevenue = paidOrders.reduce((s, o) => s + o.total, 0)
  const taxCollected = paidOrders.reduce((s, o) => s + o.tax, 0)
  const totalDiscount = paidOrders.reduce((s, o) => s + o.discount, 0)
  const refunds = payments.filter((p) => p.status === 'refunded').reduce((s, p) => s + p.amount, 0)

  // Series by range
  const series: { label: string; revenue: number; orders: number; tax: number }[] = []
  const now = new Date()
  if (range === 'daily') {
    for (let i = 13; i >= 0; i--) {
      const d = new Date(now); d.setHours(0,0,0,0); d.setDate(d.getDate() - i)
      const next = new Date(d); next.setDate(d.getDate() + 1)
      const dayOrders = orders.filter((o) => { const c = new Date(o.createdAt); return c >= d && c < next })
      series.push({
        label: d.toLocaleDateString('en', { month: 'short', day: 'numeric' }),
        revenue: Math.round(dayOrders.filter((o) => o.paymentStatus === 'paid').reduce((s,o)=>s+o.total,0)*100)/100,
        orders: dayOrders.length,
        tax: Math.round(dayOrders.reduce((s,o)=>s+o.tax,0)*100)/100,
      })
    }
  } else if (range === 'weekly') {
    for (let i = 11; i >= 0; i--) {
      const d = new Date(now); d.setHours(0,0,0,0); d.setDate(d.getDate() - i*7)
      const next = new Date(d); next.setDate(d.getDate() + 7)
      const wOrders = orders.filter((o) => { const c = new Date(o.createdAt); return c >= d && c < next })
      series.push({
        label: `W${i === 0 ? '0' : '-' + i}`,
        revenue: Math.round(wOrders.filter((o)=>o.paymentStatus==='paid').reduce((s,o)=>s+o.total,0)*100)/100,
        orders: wOrders.length,
        tax: Math.round(wOrders.reduce((s,o)=>s+o.tax,0)*100)/100,
      })
    }
  } else if (range === 'monthly') {
    for (let i = 11; i >= 0; i--) {
      const d = new Date(now); d.setDate(1); d.setMonth(d.getMonth() - i)
      const label = d.toLocaleString('en', { month: 'short', year: '2-digit' })
      const mOrders = orders.filter((o) => { const c = new Date(o.createdAt); return c.getMonth() === d.getMonth() && c.getFullYear() === d.getFullYear() })
      series.push({
        label,
        revenue: Math.round(mOrders.filter((o)=>o.paymentStatus==='paid').reduce((s,o)=>s+o.total,0)*100)/100,
        orders: mOrders.length,
        tax: Math.round(mOrders.reduce((s,o)=>s+o.tax,0)*100)/100,
      })
    }
  } else {
    for (let i = 4; i >= 0; i--) {
      const y = now.getFullYear() - i
      const yOrders = orders.filter((o) => new Date(o.createdAt).getFullYear() === y)
      series.push({
        label: String(y),
        revenue: Math.round(yOrders.filter((o)=>o.paymentStatus==='paid').reduce((s,o)=>s+o.total,0)*100)/100,
        orders: yOrders.length,
        tax: Math.round(yOrders.reduce((s,o)=>s+o.tax,0)*100)/100,
      })
    }
  }

  // Product sales breakdown
  const productSales = new Map<string, { name: string; qty: number; revenue: number }>()
  for (const o of paidOrders) {
    const items = JSON.parse(o.items || '[]') as any[]
    for (const it of items) {
      const cur = productSales.get(it.productId) || { name: it.name, qty: 0, revenue: 0 }
      cur.qty += it.qty || 0
      cur.revenue += it.total || 0
      productSales.set(it.productId, cur)
    }
  }
  const topSelling = [...productSales.values()].sort((a, b) => b.revenue - a.revenue).slice(0, 10)

  // Customer report
  const customerStats = customers.map((c) => ({
    name: c.name, email: c.email, orders: c.totalOrders, spent: c.totalSpent, status: c.status,
  })).sort((a, b) => b.spent - a.spent).slice(0, 10)

  // Tax by gateway
  const gatewayMap = new Map<string, { gateway: string; revenue: number; count: number }>()
  for (const p of payments) {
    if (p.status !== 'success') continue
    const cur = gatewayMap.get(p.gateway) || { gateway: p.gateway, revenue: 0, count: 0 }
    cur.revenue += p.amount
    cur.count += 1
    gatewayMap.set(p.gateway, cur)
  }
  const byGateway = [...gatewayMap.values()]

  return NextResponse.json({
    summary: {
      totalRevenue: Math.round(totalRevenue * 100) / 100,
      taxCollected: Math.round(taxCollected * 100) / 100,
      totalDiscount: Math.round(totalDiscount * 100) / 100,
      refunds: Math.round(refunds * 100) / 100,
      netRevenue: Math.round((totalRevenue - refunds) * 100) / 100,
      totalOrders: orders.length,
      avgOrderValue: orders.length ? Math.round((totalRevenue / orders.length) * 100) / 100 : 0,
      activeCoupons: coupons.filter((c) => c.status === 'active').length,
      couponUsage: coupons.reduce((s, c) => s + c.usedCount, 0),
    },
    series,
    topSelling,
    customerStats,
    byGateway,
    refundsCount: payments.filter((p) => p.status === 'refunded').length,
    inventoryValue: products.reduce((s, p) => s + p.price * p.stock, 0),
  })
}
