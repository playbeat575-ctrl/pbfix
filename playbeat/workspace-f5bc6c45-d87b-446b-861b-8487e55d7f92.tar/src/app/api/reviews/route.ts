import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url)
  const status = searchParams.get('status') || ''
  const where: any = {}
  if (status) where.status = status
  const reviews = await db.review.findMany({ where, orderBy: { createdAt: 'desc' } })
  return NextResponse.json({ reviews })
}

export async function PUT(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  // handled in [id]
  return NextResponse.json({ ok: true })
}
