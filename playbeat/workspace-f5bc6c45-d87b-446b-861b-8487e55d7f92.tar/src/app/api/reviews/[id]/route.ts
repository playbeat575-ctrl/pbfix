import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function PUT(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  const body = await req.json()
  const review = await db.review.update({ where: { id }, data: { status: body.status } })
  return NextResponse.json({ review })
}

export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  await db.review.delete({ where: { id } })
  return NextResponse.json({ ok: true })
}
