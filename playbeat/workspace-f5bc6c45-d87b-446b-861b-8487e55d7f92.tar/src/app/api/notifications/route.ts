import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET() {
  const notifications = await db.notification.findMany({ orderBy: { createdAt: 'desc' }, take: 30 })
  return NextResponse.json({ notifications })
}

export async function PUT(req: NextRequest) {
  const body = await req.json()
  if (body.markAllRead) {
    await db.notification.updateMany({ where: { read: false }, data: { read: true } })
    return NextResponse.json({ ok: true })
  }
  const n = await db.notification.update({ where: { id: body.id }, data: { read: true } })
  return NextResponse.json({ notification: n })
}
