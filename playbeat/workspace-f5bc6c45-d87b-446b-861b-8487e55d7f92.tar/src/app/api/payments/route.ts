import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url)
  const gateway = searchParams.get('gateway') || ''
  const status = searchParams.get('status') || ''
  const search = searchParams.get('search') || ''
  const where: any = {}
  if (gateway) where.gateway = gateway
  if (status) where.status = status
  if (search) where.OR = [{ orderNumber: { contains: search } }, { transactionId: { contains: search } }]
  const payments = await db.payment.findMany({ where, orderBy: { createdAt: 'desc' } })
  return NextResponse.json({ payments })
}
