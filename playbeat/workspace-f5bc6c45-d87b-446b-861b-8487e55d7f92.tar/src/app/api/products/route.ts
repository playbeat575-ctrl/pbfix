import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url)
  const type = searchParams.get('type') || ''
  const status = searchParams.get('status') || ''
  const search = searchParams.get('search') || ''
  const featured = searchParams.get('featured')
  const trending = searchParams.get('trending')

  const where: any = {}
  if (type) where.type = type
  if (status) where.status = status
  if (featured === 'true') where.featured = true
  if (trending === 'true') where.trending = true
  if (search) {
    where.OR = [
      { name: { contains: search } },
      { sku: { contains: search } },
      { brand: { contains: search } },
      { category: { contains: search } },
    ]
  }

  const products = await db.product.findMany({ where, orderBy: { createdAt: 'desc' } })
  return NextResponse.json({ products })
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const slug = (body.slug || body.name).toLowerCase().replace(/[^a-z0-9]+/g, '-') + '-' + Date.now().toString(36)
    const product = await db.product.create({
      data: {
        name: body.name,
        slug,
        description: body.description || '',
        category: body.category || body.type,
        type: body.type || 'Games',
        brand: body.brand || 'Playbeat',
        price: Number(body.price) || 0,
        comparePrice: body.comparePrice ? Number(body.comparePrice) : null,
        stock: Number(body.stock) || 0,
        sku: body.sku || 'PB-' + Date.now().toString(36).toUpperCase(),
        status: body.status || 'active',
        featured: !!body.featured,
        trending: !!body.trending,
        images: JSON.stringify(body.images || []),
        gallery: JSON.stringify(body.gallery || []),
        videoUrl: body.videoUrl || null,
        tags: JSON.stringify(body.tags || []),
        seoTitle: body.seoTitle || null,
        seoDescription: body.seoDescription || null,
        hasLicenseKeys: !!body.hasLicenseKeys,
      },
    })
    await db.auditLog.create({ data: { action: 'product.create', module: 'Products', user: 'Admin', details: `Created product: ${product.name}` } })
    return NextResponse.json({ product })
  } catch (e) {
    console.error('[products.post]', e)
    return NextResponse.json({ error: 'Failed to create product' }, { status: 500 })
  }
}
