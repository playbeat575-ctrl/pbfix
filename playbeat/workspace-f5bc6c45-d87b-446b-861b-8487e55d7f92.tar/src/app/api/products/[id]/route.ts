import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  const product = await db.product.findUnique({ where: { id } })
  if (!product) return NextResponse.json({ error: 'Not found' }, { status: 404 })
  return NextResponse.json({ product })
}

export async function PUT(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  try {
    const body = await req.json()
    const data: any = { ...body }
    if (data.price !== undefined) data.price = Number(data.price)
    if (data.comparePrice !== undefined) data.comparePrice = data.comparePrice ? Number(data.comparePrice) : null
    if (data.stock !== undefined) data.stock = Number(data.stock)
    if (data.images !== undefined) data.images = JSON.stringify(data.images)
    if (data.gallery !== undefined) data.gallery = JSON.stringify(data.gallery)
    if (data.tags !== undefined) data.tags = JSON.stringify(data.tags)
    if (data.slug !== undefined) delete data.slug
    const product = await db.product.update({ where: { id }, data })
    await db.auditLog.create({ data: { action: 'product.update', module: 'Products', user: 'Admin', details: `Updated product: ${product.name}` } })
    return NextResponse.json({ product })
  } catch (e) {
    console.error('[products.put]', e)
    return NextResponse.json({ error: 'Failed to update' }, { status: 500 })
  }
}

export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  try {
    await db.product.delete({ where: { id } })
    await db.auditLog.create({ data: { action: 'product.delete', module: 'Products', user: 'Admin', details: `Deleted product ${id}` } })
    return NextResponse.json({ ok: true })
  } catch (e) {
    return NextResponse.json({ error: 'Failed to delete' }, { status: 500 })
  }
}
