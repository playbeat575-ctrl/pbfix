import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url)
  const status = searchParams.get('status') || ''
  const paymentStatus = searchParams.get('paymentStatus') || ''
  const search = searchParams.get('search') || ''
  const where: any = {}
  if (status) where.status = status
  if (paymentStatus) where.paymentStatus = paymentStatus
  if (search) {
    where.OR = [
      { orderNumber: { contains: search } },
      { customerName: { contains: search } },
      { customerEmail: { contains: search } },
    ]
  }
  const orders = await db.order.findMany({ where, orderBy: { createdAt: 'desc' } })
  return NextResponse.json({ orders })
}

export async function POST(req: NextRequest) {
  const body = await req.json()
  const count = await db.order.count()
  const orderNumber = 'PB' + (10000 + count + 1)
  const order = await db.order.create({
    data: {
      orderNumber,
      customerName: body.customerName,
      customerEmail: body.customerEmail,
      status: body.status || 'pending',
      paymentStatus: body.paymentStatus || 'unpaid',
      paymentMethod: body.paymentMethod || null,
      subtotal: Number(body.subtotal) || 0,
      tax: Number(body.tax) || 0,
      discount: Number(body.discount) || 0,
      shipping: Number(body.shipping) || 0,
      total: Number(body.total) || 0,
      currency: 'PKR',
      items: JSON.stringify(body.items || []),
      notes: body.notes || null,
    },
  })
  await db.auditLog.create({ data: { action: 'order.create', module: 'Orders', user: 'Admin', details: `Created order ${orderNumber}` } })
  return NextResponse.json({ order })
}
