import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  const order = await db.order.findUnique({ where: { id } })
  if (!order) return NextResponse.json({ error: 'Not found' }, { status: 404 })
  const payments = await db.payment.findMany({ where: { orderId: id } })
  return NextResponse.json({ order, payments })
}

export async function PUT(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  const body = await req.json()
  const order = await db.order.update({ where: { id }, data: { ...body } })
  await db.auditLog.create({ data: { action: 'order.update', module: 'Orders', user: 'Admin', details: `Updated order ${order.orderNumber}` } })
  return NextResponse.json({ order })
}
