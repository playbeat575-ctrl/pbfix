import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function PUT(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  const body = await req.json()
  const user = await db.adminUser.update({ where: { id }, data: { ...body } })
  await db.auditLog.create({ data: { action: 'role.update', module: 'Users', user: 'Admin', details: `Updated admin user ${user.email}` } })
  return NextResponse.json({ user })
}
