import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET() {
  try {
    const [products, orders, customers] = await Promise.all([
      db.product.findMany(),
      db.order.findMany(),
      db.customer.findMany(),
    ])

    const totalRevenue = orders.filter((o) => o.paymentStatus === 'paid').reduce((s, o) => s + o.total, 0)
    const todayStart = new Date()
    todayStart.setHours(0, 0, 0, 0)
    const monthStart = new Date()
    monthStart.setDate(1)
    monthStart.setHours(0, 0, 0, 0)

    const todaysRevenue = orders.filter((o) => o.paymentStatus === 'paid' && new Date(o.createdAt) >= todayStart).reduce((s, o) => s + o.total, 0)
    const monthlyRevenue = orders.filter((o) => o.paymentStatus === 'paid' && new Date(o.createdAt) >= monthStart).reduce((s, o) => s + o.total, 0)

    const pendingOrders = orders.filter((o) => o.status === 'pending').length
    const completedOrders = orders.filter((o) => o.status === 'completed').length
    const failedOrders = orders.filter((o) => o.status === 'failed').length

    const activeUsers = customers.filter((c) => c.status === 'active').length
    const newCustomers = customers.filter((c) => Date.now() - new Date(c.createdAt).getTime() < 14 * 86400000).length

    const topProducts = [...products].sort((a, b) => b.salesCount - a.salesCount).slice(0, 6)

    const catMap = new Map<string, { name: string; revenue: number; orders: number }>()
    for (const o of orders) {
      if (o.paymentStatus !== 'paid') continue
      const items = JSON.parse(o.items || '[]') as any[]
      for (const it of items) {
        const cat = it.type || 'Other'
        const cur = catMap.get(cat) || { name: cat, revenue: 0, orders: 0 }
        cur.revenue += it.total || 0
        cur.orders += it.qty || 0
        catMap.set(cat, cur)
      }
    }
    const bestCategories = [...catMap.values()].sort((a, b) => b.revenue - a.revenue).slice(0, 6)

    const inventoryAlerts = products.filter((p) => p.stock < 15).sort((a, b) => a.stock - b.stock).slice(0, 6)

    const refundRequests = orders.filter((o) => o.status === 'refunded').length

    const conversionRate = orders.length ? (orders.filter((o) => o.paymentStatus === 'paid').length / orders.length) * 100 : 0

    const liveVisitors = Math.floor(80 + Math.random() * 220)

    const days: { date: string; revenue: number; orders: number }[] = []
    for (let i = 29; i >= 0; i--) {
      const d = new Date()
      d.setHours(0, 0, 0, 0)
      d.setDate(d.getDate() - i)
      const next = new Date(d)
      next.setDate(d.getDate() + 1)
      const dayOrders = orders.filter((o) => { const c = new Date(o.createdAt); return c >= d && c < next })
      days.push({
        date: d.toISOString().slice(0, 10),
        revenue: Math.round(dayOrders.filter((o) => o.paymentStatus === 'paid').reduce((s, o) => s + o.total, 0) * 100) / 100,
        orders: dayOrders.length,
      })
    }

    const months: { label: string; revenue: number; orders: number }[] = []
    for (let i = 11; i >= 0; i--) {
      const d = new Date()
      d.setDate(1)
      d.setMonth(d.getMonth() - i)
      const label = d.toLocaleString('en', { month: 'short' })
      const mOrders = orders.filter((o) => { const c = new Date(o.createdAt); return c.getMonth() === d.getMonth() && c.getFullYear() === d.getFullYear() })
      months.push({
        label,
        revenue: Math.round(mOrders.filter((o) => o.paymentStatus === 'paid').reduce((s, o) => s + o.total, 0) * 100) / 100,
        orders: mOrders.length,
      })
    }

    const payMap = new Map<string, number>()
    const payments = await db.payment.findMany()
    for (const p of payments) {
      if (p.status === 'success') payMap.set(p.gateway, (payMap.get(p.gateway) || 0) + p.amount)
    }
    const paymentDistribution = [...payMap.entries()].map(([name, value]) => ({ name, value: Math.round(value * 100) / 100 }))

    const statusMap = new Map<string, number>()
    for (const o of orders) statusMap.set(o.status, (statusMap.get(o.status) || 0) + 1)
    const orderStatusDistribution = [...statusMap.entries()].map(([name, value]) => ({ name, value }))

    const recentOrders = [...orders].sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()).slice(0, 6)

    return NextResponse.json({
      stats: {
        totalRevenue: Math.round(totalRevenue * 100) / 100,
        todaysRevenue: Math.round(todaysRevenue * 100) / 100,
        monthlyRevenue: Math.round(monthlyRevenue * 100) / 100,
        totalOrders: orders.length,
        pendingOrders,
        completedOrders,
        failedOrders,
        activeUsers,
        registeredUsers: customers.length,
        newCustomers,
        totalProducts: products.length,
        inventoryAlertsCount: products.filter((p) => p.stock < 15).length,
        refundRequests,
        supportTickets: (await db.supportTicket.count({ where: { status: 'open' } })),
        liveVisitors,
        conversionRate: Math.round(conversionRate * 100) / 100,
        totalCoupons: await db.coupon.count(),
        pendingReviews: await db.review.count({ where: { status: 'pending' } }),
        licenseKeys: await db.licenseKey.count({ where: { status: 'available' } }),
      },
      deltas: {
        totalRevenue: 18.4, todaysRevenue: 7.2, monthlyRevenue: 12.8, totalOrders: 9.6,
        activeUsers: 14.1, registeredUsers: 6.3, newCustomers: 22.5, conversionRate: 2.4,
        refundRequests: -3.1, supportTickets: -8.0,
      },
      topProducts,
      bestCategories,
      inventoryAlerts,
      revenueSeries: days,
      monthlySeries: months,
      paymentDistribution,
      orderStatusDistribution,
      recentOrders,
    })
  } catch (e) {
    console.error('[dashboard]', e)
    return NextResponse.json({ error: 'Failed to load dashboard' }, { status: 500 })
  }
}
