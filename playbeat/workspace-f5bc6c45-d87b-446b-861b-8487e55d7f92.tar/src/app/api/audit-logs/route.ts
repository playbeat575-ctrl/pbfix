import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url)
  const moduleFilter = searchParams.get('module') || ''
  const where: any = {}
  if (moduleFilter) where.module = moduleFilter
  const logs = await db.auditLog.findMany({ where, orderBy: { createdAt: 'desc' }, take: 200 })
  return NextResponse.json({ logs })
}
