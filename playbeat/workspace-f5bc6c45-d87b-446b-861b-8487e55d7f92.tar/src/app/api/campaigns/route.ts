import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET() {
  const campaigns = await db.campaign.findMany({ orderBy: { createdAt: 'desc' } })
  return NextResponse.json({ campaigns })
}

export async function POST(req: NextRequest) {
  const body = await req.json()
  const campaign = await db.campaign.create({
    data: {
      name: body.name,
      type: body.type,
      channel: body.channel || body.type,
      status: body.status || 'draft',
      audience: body.audience || 'All Customers',
    },
  })
  return NextResponse.json({ campaign })
}
