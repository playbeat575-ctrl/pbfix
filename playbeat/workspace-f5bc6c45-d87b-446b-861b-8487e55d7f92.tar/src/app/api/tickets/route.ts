import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url)
  const status = searchParams.get('status') || ''
  const priority = searchParams.get('priority') || ''
  const where: any = {}
  if (status) where.status = status
  if (priority) where.priority = priority
  const tickets = await db.supportTicket.findMany({ where, orderBy: { createdAt: 'desc' } })
  return NextResponse.json({ tickets })
}
