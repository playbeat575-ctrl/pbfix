import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function PUT(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  const body = await req.json()
  const ticket = await db.supportTicket.update({ where: { id }, data: { status: body.status, priority: body.priority } })
  return NextResponse.json({ ticket })
}
