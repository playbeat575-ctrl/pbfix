import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url)
  const status = searchParams.get('status') || ''
  const productId = searchParams.get('productId') || ''
  const where: any = {}
  if (status) where.status = status
  if (productId) where.productId = productId
  const keys = await db.licenseKey.findMany({ where, orderBy: { createdAt: 'desc' }, take: 300 })
  return NextResponse.json({ keys })
}
