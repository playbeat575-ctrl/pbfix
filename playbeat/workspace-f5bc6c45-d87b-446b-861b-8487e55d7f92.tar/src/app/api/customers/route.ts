import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url)
  const status = searchParams.get('status') || ''
  const search = searchParams.get('search') || ''
  const where: any = {}
  if (status) where.status = status
  if (search) {
    where.OR = [{ name: { contains: search } }, { email: { contains: search } }, { phone: { contains: search } }]
  }
  const customers = await db.customer.findMany({ where, orderBy: { createdAt: 'desc' } })
  return NextResponse.json({ customers })
}

export async function POST(req: NextRequest) {
  const body = await req.json()
  const customer = await db.customer.create({
    data: {
      name: body.name,
      email: body.email,
      phone: body.phone || null,
      country: body.country || null,
      status: body.status || 'active',
      verified: !!body.verified,
    },
  })
  return NextResponse.json({ customer })
}
