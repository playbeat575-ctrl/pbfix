import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  const customer = await db.customer.findUnique({ where: { id } })
  if (!customer) return NextResponse.json({ error: 'Not found' }, { status: 404 })
  const orders = await db.order.findMany({ where: { customerId: id }, orderBy: { createdAt: 'desc' } })
  const reviews = await db.review.findMany({ where: { customerEmail: customer.email }, orderBy: { createdAt: 'desc' } })
  const tickets = await db.supportTicket.findMany({ where: { customerEmail: customer.email }, orderBy: { createdAt: 'desc' } })
  return NextResponse.json({ customer, orders, reviews, tickets })
}

export async function PUT(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  const body = await req.json()
  const data: any = { ...body }
  if (data.walletBalance !== undefined) data.walletBalance = Number(data.walletBalance)
  if (data.rewardPoints !== undefined) data.rewardPoints = Number(data.rewardPoints)
  const customer = await db.customer.update({ where: { id }, data })
  await db.auditLog.create({ data: { action: 'customer.update', module: 'Customers', user: 'Admin', details: `Updated customer ${customer.email}` } })
  return NextResponse.json({ customer })
}
