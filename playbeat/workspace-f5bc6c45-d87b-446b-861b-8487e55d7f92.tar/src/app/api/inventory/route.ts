import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET() {
  const products = await db.product.findMany()
  const licenseKeys = await db.licenseKey.findMany()
  const totalStock = products.reduce((s, p) => s + p.stock, 0)
  const lowStock = products.filter((p) => p.stock > 0 && p.stock < 15)
  const outOfStock = products.filter((p) => p.stock === 0)
  const availableKeys = licenseKeys.filter((l) => l.status === 'available').length
  const usedKeys = licenseKeys.filter((l) => l.status === 'used' || l.status === 'assigned').length
  const totalValue = products.reduce((s, p) => s + p.price * p.stock, 0)
  const items = products.map((p) => ({
    id: p.id,
    name: p.name,
    type: p.type,
    sku: p.sku,
    stock: p.stock,
    price: p.price,
    value: Math.round(p.price * p.stock * 100) / 100,
    status: p.stock === 0 ? 'out-of-stock' : p.stock < 15 ? 'low' : 'healthy',
    hasLicenseKeys: p.hasLicenseKeys,
  }))
  return NextResponse.json({
    summary: {
      totalProducts: products.length,
      totalStock,
      totalValue: Math.round(totalValue * 100) / 100,
      lowStockCount: lowStock.length,
      outOfStockCount: outOfStock.length,
      availableKeys,
      usedKeys,
    },
    lowStock,
    outOfStock,
    items,
  })
}
