import { PrismaClient } from '@prisma/client'

const db = new PrismaClient()

const productTypes = ['Games', 'Gift Cards', 'Software', 'AI Tools', 'Accounts', 'Subscriptions', 'Top-Up', 'Game Items']
const categories = [
  { name: 'PC Games', slug: 'pc-games', type: 'Games', icon: 'Gamepad2', color: 'from-red-500 to-orange-500' },
  { name: 'Console Games', slug: 'console-games', type: 'Games', icon: 'Tv', color: 'from-blue-500 to-cyan-500' },
  { name: 'Steam Gift Cards', slug: 'steam-gift-cards', type: 'Gift Cards', icon: 'Gift', color: 'from-orange-500 to-red-500' },
  { name: 'Google Play', slug: 'google-play', type: 'Gift Cards', icon: 'Smartphone', color: 'from-emerald-500 to-teal-500' },
  { name: 'Antivirus & Security', slug: 'antivirus', type: 'Software', icon: 'ShieldCheck', color: 'from-blue-500 to-indigo-500' },
  { name: 'Productivity', slug: 'productivity', type: 'Software', icon: 'FileText', color: 'from-violet-500 to-purple-500' },
  { name: 'ChatGPT Plus', slug: 'chatgpt-plus', type: 'AI Tools', icon: 'Bot', color: 'from-emerald-500 to-green-500' },
  { name: 'Midjourney', slug: 'midjourney', type: 'AI Tools', icon: 'Sparkles', color: 'from-pink-500 to-rose-500' },
  { name: 'Streaming Accounts', slug: 'streaming-accounts', type: 'Accounts', icon: 'Play', color: 'from-red-500 to-pink-500' },
  { name: 'Cloud Storage', slug: 'cloud-storage', type: 'Accounts', icon: 'Cloud', color: 'from-cyan-500 to-blue-500' },
  { name: 'Netflix', slug: 'netflix', type: 'Subscriptions', icon: 'Film', color: 'from-red-600 to-rose-600' },
  { name: 'Spotify', slug: 'spotify', type: 'Subscriptions', icon: 'Music', color: 'from-green-500 to-emerald-500' },
  { name: 'Mobile Top-Up', slug: 'mobile-topup', type: 'Top-Up', icon: 'Phone', color: 'from-orange-500 to-amber-500' },
  { name: 'Game Top-Up', slug: 'game-topup', type: 'Top-Up', icon: 'Coins', color: 'from-yellow-500 to-orange-500' },
  { name: 'In-Game Items', slug: 'in-game-items', type: 'Game Items', icon: 'Sword', color: 'from-purple-500 to-violet-500' },
  { name: 'Skins & Cosmetics', slug: 'skins', type: 'Game Items', icon: 'Shirt', color: 'from-fuchsia-500 to-pink-500' },
]

const productSeeds: Record<string, { name: string; brand: string; price: number; compare?: number; desc: string }[]> = {
  Games: [
    { name: 'Cyberpunk 2077 (PC)', brand: 'CD Projekt', price: 29.99, compare: 59.99, desc: 'Open-world action adventure RPG set in Night City. Includes Phantom Liberty expansion.' },
    { name: 'Elden Ring (PC)', brand: 'FromSoftware', price: 44.99, compare: 59.99, desc: 'Action RPG by FromSoftware. Explore the Lands Between and become the Elden Lord.' },
    { name: 'Call of Duty: MW3 (PC)', brand: 'Activision', price: 39.99, compare: 69.99, desc: 'First-person shooter. Modern Warfare III campaign plus multiplayer.' },
    { name: 'Red Dead Redemption 2 (PC)', brand: 'Rockstar', price: 24.99, compare: 59.99, desc: 'Epic tale of life in America at the dawn of the modern age.' },
    { name: 'God of War (PC)', brand: 'Sony', price: 19.99, compare: 49.99, desc: 'His vengeance against the Gods of Olympus years behind him, Kratos now lives as a man.' },
  ],
  'Gift Cards': [
    { name: 'Steam Gift Card $50', brand: 'Steam', price: 48.5, compare: 50, desc: 'Steam wallet code worth $50 USD. Redeem on Steam for games and software.' },
    { name: 'Steam Gift Card $100', brand: 'Steam', price: 97, compare: 100, desc: 'Steam wallet code worth $100 USD. Instant digital delivery.' },
    { name: 'Google Play $25', brand: 'Google', price: 24, compare: 25, desc: 'Google Play gift card for apps, games, and in-app purchases.' },
    { name: 'Apple Gift Card $50', brand: 'Apple', price: 49, compare: 50, desc: 'Apple gift card for App Store, iTunes, and iCloud storage.' },
    { name: 'PlayStation $75', brand: 'Sony', price: 73, compare: 75, desc: 'PlayStation Store gift card for games and PS Plus.' },
  ],
  Software: [
    { name: 'Kaspersky Total Security 1Y', brand: 'Kaspersky', price: 19.99, compare: 99.99, desc: 'Award-winning protection for PC, Mac, and mobile. 1 year, 3 devices.' },
    { name: 'Microsoft Office 2021 Pro', brand: 'Microsoft', price: 49.99, compare: 439.99, desc: 'Lifetime license for Office Professional 2021. Word, Excel, PowerPoint, Outlook.' },
    { name: 'NordVPN 2Y Subscription', brand: 'NordVPN', price: 79, compare: 286, desc: '2-year NordVPN subscription with 68% off. Secure your online activity.' },
    { name: 'Adobe Photoshop 2024', brand: 'Adobe', price: 119.99, compare: 239.88, desc: 'Annual subscription. The industry standard for photo editing.' },
    { name: 'Windows 11 Pro Key', brand: 'Microsoft', price: 14.99, compare: 199, desc: 'Genuine Windows 11 Pro activation key. Lifetime activation.' },
  ],
  'AI Tools': [
    { name: 'ChatGPT Plus 1 Month', brand: 'OpenAI', price: 15.99, compare: 20, desc: 'ChatGPT Plus subscription with GPT-4 access. Shared account, 1 month.' },
    { name: 'Midjourney Standard 1M', brand: 'Midjourney', price: 22.99, compare: 30, desc: 'Midjourney Standard plan. 15h fast GPU time, unlimited relax.' },
    { name: 'Claude Pro 1 Month', brand: 'Anthropic', price: 16.99, compare: 20, desc: 'Claude Pro subscription. Priority access to Claude Opus and Sonnet.' },
    { name: 'Grammarly Premium 1Y', brand: 'Grammarly', price: 49.99, compare: 144, desc: 'Grammarly Premium annual subscription. Advanced writing assistance.' },
    { name: 'Perplexity Pro 1M', brand: 'Perplexity', price: 14.99, compare: 20, desc: 'Perplexity AI Pro subscription with Pro Search and file uploads.' },
  ],
  Accounts: [
    { name: 'Netflix Premium 4K 1M', brand: 'Netflix', price: 6.99, compare: 22.99, desc: 'Netflix Premium 4K UHD shared account. 1 month warranty.' },
    { name: 'YouTube Premium 1M', brand: 'Google', price: 4.99, compare: 13.99, desc: 'YouTube Premium + Music. Ad-free, background play, 1 month.' },
    { name: 'Spotify Premium 1M', brand: 'Spotify', price: 3.99, compare: 10.99, desc: 'Spotify Premium individual. Ad-free music streaming, 1 month.' },
    { name: 'Disney+ Premium 1M', brand: 'Disney', price: 5.49, compare: 13.99, desc: 'Disney+ Premium 4K UHD. 1 month subscription.' },
    { name: 'Crunchyroll Mega 1M', brand: 'Crunchyroll', price: 7.99, compare: 15.99, desc: 'Crunchyroll Mega fan. Ad-free anime streaming, 1 month.' },
  ],
  Subscriptions: [
    { name: 'Netflix 1 Year', brand: 'Netflix', price: 69.99, compare: 227.88, desc: 'Netflix Premium 4K annual subscription with discount.' },
    { name: 'Amazon Prime 1Y', brand: 'Amazon', price: 59.99, compare: 139, desc: 'Amazon Prime annual. Free shipping, Prime Video, Music.' },
    { name: 'HBO Max 1Y', brand: 'HBO', price: 79.99, compare: 167.88, desc: 'HBO Max annual subscription with ad-free plan.' },
    { name: 'Spotify Family 1Y', brand: 'Spotify', price: 79.99, compare: 191.88, desc: 'Spotify Premium Family. Up to 6 accounts, 1 year.' },
  ],
  'Top-Up': [
    { name: 'PUBG Mobile 660 UC', brand: 'PUBG', price: 8.99, compare: 9.99, desc: 'PUBG Mobile 660 UC top-up. Instant delivery to your account ID.' },
    { name: 'Free Fire 1080 Diamonds', brand: 'Garena', price: 8.49, compare: 9.99, desc: 'Free Fire 1080 diamonds top-up. Fast and secure delivery.' },
    { name: 'Genshin Impact 980 Crystals', brand: 'miHoYo', price: 13.99, compare: 14.99, desc: 'Genshin Impact 980 Genesis Crystals top-up.' },
    { name: 'Mobile Legends 565 Diamonds', brand: 'Moonton', price: 7.99, compare: 9.99, desc: 'Mobile Legends 565 diamonds. Instant top-up.' },
    { name: 'Valorant 1000 Points', brand: 'Riot', price: 9.49, compare: 9.99, desc: 'Valorant 1000 VP points. Redeem in-game.' },
  ],
  'Game Items': [
    { name: 'CS:GO AK-47 Redline', brand: 'Valve', price: 34.99, compare: 49.99, desc: 'AK-47 Redline FT skin for Counter-Strike 2. Field-tested condition.' },
    { name: 'Fortnite 2500 V-Bucks', brand: 'Epic', price: 17.99, compare: 24.99, desc: 'Fortnite 2500 V-Bucks for skins, emotes, and battle pass.' },
    { name: 'Roblox 4000 Robux', brand: 'Roblox', price: 28.99, compare: 49.99, desc: 'Roblox 4000 Robux for avatar items and game passes.' },
    { name: 'Diablo IV Unique Set', brand: 'Blizzard', price: 44.99, compare: 79.99, desc: 'Diablo IV end-game unique item set bundle.' },
  ],
}

function slugify(s: string) {
  return s.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '')
}

function rand(min: number, max: number) {
  return Math.floor(Math.random() * (max - min + 1)) + min
}

// Convert USD price to PKR (Pakistani Rupee) at ~Rs 280/$, rounded to nearest 10
function pkr(usd: number): number {
  return Math.round((usd * 280) / 10) * 10
}

const firstNames = ['Ali', 'Ahmed', 'Sara', 'Fatima', 'Hassan', 'Ayesha', 'Bilal', 'Zainab', 'Omar', 'Hira', 'Usman', 'Maria', 'Babar', 'Nida', 'Kashif', 'Rabia', 'Tariq', 'Sana', 'Imran', 'Hina']
const lastNames = ['Khan', 'Ahmed', 'Malik', 'Sheikh', 'Raza', 'Iqbal', 'Hussain', 'Akram', 'Butt', 'Cheema', 'Rana', 'Tariq', 'Aslam', 'Javed', 'Nadeem']
const countries = ['Pakistan', 'India', 'USA', 'UK', 'UAE', 'Saudi Arabia', 'Canada', 'Australia', 'Germany', 'Bangladesh']
const gateways = ['Stripe', 'PayPal', 'JazzCash', 'Easypaisa', 'Bank Transfer', 'Manual']
const orderStatuses = ['pending', 'processing', 'completed', 'completed', 'completed', 'failed', 'cancelled', 'refunded']
const ticketCats = ['Refund', 'Delivery', 'Account Access', 'Payment', 'Technical', 'General']
const priorities = ['low', 'medium', 'high', 'urgent']
const roles = ['Super Admin', 'Admin', 'Manager', 'Support', 'Content Editor', 'Finance', 'Marketing']

async function main() {
  console.log('🌱 Seeding Playbeat.Digital database...')

  // Idempotent: skip if database already has data (safe for production rebuilds)
  const existing = await db.product.count()
  if (existing > 0) {
    console.log(`ℹ️  Database already has ${existing} products — skipping seed.`)
    return
  }

  // Categories
  await db.category.deleteMany()
  for (const c of categories) {
    await db.category.create({ data: { ...c, productCount: rand(5, 40) } })
  }

  // Products
  await db.product.deleteMany()
  let productIdx = 0
  for (const type of productTypes) {
    const seeds = productSeeds[type] || []
    for (const s of seeds) {
      const cat = categories.find((c) => c.type === type)
      productIdx++
      await db.product.create({
        data: {
          name: s.name,
          slug: slugify(s.name) + '-' + productIdx,
          description: s.desc,
          category: cat?.name || type,
          type,
          brand: s.brand,
          price: pkr(s.price),
          comparePrice: s.compare ? pkr(s.compare) : null,
          stock: rand(0, 200),
          sku: 'PB-' + type.slice(0, 3).toUpperCase() + '-' + String(1000 + productIdx),
          status: Math.random() > 0.15 ? 'active' : Math.random() > 0.5 ? 'draft' : 'out-of-stock',
          featured: Math.random() > 0.7,
          trending: Math.random() > 0.75,
          images: JSON.stringify([
            `https://picsum.photos/seed/${slugify(s.name)}1/600/600`,
            `https://picsum.photos/seed/${slugify(s.name)}2/600/600`,
          ]),
          gallery: JSON.stringify([
            `https://picsum.photos/seed/${slugify(s.name)}g1/800/600`,
            `https://picsum.photos/seed/${slugify(s.name)}g2/800/600`,
            `https://picsum.photos/seed/${slugify(s.name)}g3/800/600`,
          ]),
          videoUrl: Math.random() > 0.6 ? 'https://www.youtube.com/embed/dQw4w9WgXcQ' : null,
          tags: JSON.stringify([type, s.brand, 'digital']),
          seoTitle: s.name + ' - Playbeat.Digital',
          seoDescription: s.desc,
          rating: Math.round((3.5 + Math.random() * 1.5) * 10) / 10,
          reviewCount: rand(0, 320),
          salesCount: rand(20, 1800),
          hasLicenseKeys: ['Software', 'AI Tools', 'Accounts', 'Gift Cards'].includes(type),
        },
      })
    }
  }

  // License keys
  await db.licenseKey.deleteMany()
  const products = await db.product.findMany()
  for (const p of products) {
    if (p.hasLicenseKeys) {
      for (let i = 0; i < rand(3, 12); i++) {
        await db.licenseKey.create({
          data: {
            productId: p.id,
            productName: p.name,
            key: 'PB-' + p.type.slice(0, 3).toUpperCase() + '-' + Math.random().toString(36).slice(2, 10).toUpperCase() + '-' + Math.random().toString(36).slice(2, 10).toUpperCase(),
            status: Math.random() > 0.4 ? 'available' : Math.random() > 0.5 ? 'assigned' : 'used',
          },
        })
      }
    }
  }

  // Customers
  await db.customer.deleteMany()
  const customersData = []
  for (let i = 0; i < 48; i++) {
    const fn = firstNames[rand(0, firstNames.length - 1)]
    const ln = lastNames[rand(0, lastNames.length - 1)]
    const name = fn + ' ' + ln
    const email = (fn + '.' + ln + rand(1, 99)).toLowerCase() + '@example.com'
    const totalOrders = rand(0, 24)
    const totalSpent = pkr(totalOrders * rand(8, 120))
    customersData.push({
      name, email,
      phone: '+92' + rand(300, 349) + rand(1000000, 9999999),
      avatar: `https://i.pravatar.cc/150?u=${email}`,
      status: Math.random() > 0.12 ? 'active' : Math.random() > 0.5 ? 'pending' : 'blocked',
      verified: Math.random() > 0.3,
      walletBalance: pkr(rand(0, 250)),
      rewardPoints: rand(0, 2400),
      totalOrders,
      totalSpent,
      country: countries[rand(0, countries.length - 1)],
      loginHistory: JSON.stringify([
        { ip: '103.' + rand(0, 255) + '.' + rand(0, 255) + '.' + rand(1, 254), device: 'Chrome / Windows', time: new Date(Date.now() - rand(1, 72) * 3600000).toISOString() },
        { ip: '110.' + rand(0, 255) + '.' + rand(0, 255) + '.' + rand(1, 254), device: 'Safari / iPhone', time: new Date(Date.now() - rand(72, 240) * 3600000).toISOString() },
      ]),
      wishlist: JSON.stringify(products.slice(0, rand(0, 5)).map((p) => p.id)),
    })
  }
  for (const c of customersData) {
    await db.customer.create({ data: c })
  }

  // Orders
  await db.order.deleteMany()
  const dbCustomers = await db.customer.findMany()
  for (let i = 0; i < 120; i++) {
    const cust = dbCustomers[rand(0, dbCustomers.length - 1)]
    const itemCount = rand(1, 4)
    const items = []
    let subtotal = 0
    for (let j = 0; j < itemCount; j++) {
      const p = products[rand(0, products.length - 1)]
      const qty = rand(1, 3)
      const line = p.price * qty
      subtotal += line
      items.push({ productId: p.id, name: p.name, price: p.price, qty, total: line, type: p.type, image: JSON.parse(p.images)[0] })
    }
    const tax = Math.round(subtotal * 0.05 * 100) / 100
    const discount = Math.random() > 0.7 ? Math.round(subtotal * 0.1 * 100) / 100 : 0
    const total = Math.round((subtotal + tax - discount) * 100) / 100
    const status = orderStatuses[rand(0, orderStatuses.length - 1)]
    const paymentStatus = status === 'completed' ? 'paid' : status === 'refunded' ? 'refunded' : status === 'failed' || status === 'cancelled' ? 'unpaid' : 'unpaid'
    const daysAgo = rand(0, 60)
    await db.order.create({
      data: {
        orderNumber: 'PB' + (10000 + i),
        customerName: cust.name,
        customerEmail: cust.email,
        customerId: cust.id,
        status,
        paymentStatus,
        paymentMethod: gateways[rand(0, gateways.length - 1)],
        subtotal,
        tax,
        discount,
        total,
        currency: 'PKR',
        items: JSON.stringify(items),
        fraudScore: rand(0, 100),
        notes: Math.random() > 0.8 ? 'Customer requested fast delivery.' : null,
        createdAt: new Date(Date.now() - daysAgo * 86400000 - rand(0, 86400000)),
      },
    })
  }

  // Payments
  await db.payment.deleteMany()
  const orders = await db.order.findMany()
  for (const o of orders) {
    if (o.paymentStatus === 'paid' || o.paymentStatus === 'refunded' || Math.random() > 0.5) {
      await db.payment.create({
        data: {
          orderId: o.id,
          orderNumber: o.orderNumber,
          gateway: o.paymentMethod || gateways[rand(0, gateways.length - 1)],
          method: 'Card',
          amount: o.total,
          currency: o.currency,
          status: o.paymentStatus === 'refunded' ? 'refunded' : o.paymentStatus === 'paid' ? 'success' : Math.random() > 0.5 ? 'success' : 'failed',
          transactionId: 'txn_' + Math.random().toString(36).slice(2, 14),
          createdAt: o.createdAt,
        },
      })
    }
  }

  // Coupons
  await db.coupon.deleteMany()
  const couponDefs = [
    { code: 'WELCOME10', type: 'percentage', value: 10, minOrder: 20, maxDiscount: 50, limit: 1000 },
    { code: 'PLAYBEAT25', type: 'percentage', value: 25, minOrder: 50, maxDiscount: 100, limit: 500 },
    { code: 'FLAT15', type: 'fixed', value: 15, minOrder: 80, limit: 300 },
    { code: 'SUMMER50', type: 'percentage', value: 50, minOrder: 30, maxDiscount: 80, limit: 200 },
    { code: 'GAMER5', type: 'fixed', value: 5, minOrder: 25, limit: 2000 },
    { code: 'BLACKFRIDAY', type: 'percentage', value: 40, minOrder: 100, maxDiscount: 200, limit: 1000 },
  ]
  for (const c of couponDefs) {
    await db.coupon.create({
      data: {
        code: c.code,
        type: c.type,
        value: c.type === 'fixed' ? pkr(c.value) : c.value,
        minOrder: pkr(c.minOrder),
        maxDiscount: c.maxDiscount ? pkr(c.maxDiscount) : null,
        usageLimit: c.limit,
        usedCount: rand(0, c.limit),
        status: 'active',
        validFrom: new Date(Date.now() - 30 * 86400000),
        validTo: new Date(Date.now() + 60 * 86400000),
      },
    })
  }

  // Reviews
  await db.review.deleteMany()
  const reviewComments = [
    'Great product, instant delivery! Highly recommend.',
    'Works perfectly. Will buy again.',
    'Fast and reliable service.',
    'Good value for money.',
    'Excellent customer support.',
    'Product as described. Satisfied.',
    'Quick delivery, authentic key.',
    'Best price I found online.',
    'Smooth transaction, thank you!',
    'Could be cheaper but quality is good.',
  ]
  for (let i = 0; i < 40; i++) {
    const p = products[rand(0, products.length - 1)]
    const cust = dbCustomers[rand(0, dbCustomers.length - 1)]
    await db.review.create({
      data: {
        productId: p.id,
        productName: p.name,
        customerName: cust.name,
        customerEmail: cust.email,
        rating: rand(3, 5),
        comment: reviewComments[rand(0, reviewComments.length - 1)],
        status: Math.random() > 0.4 ? 'approved' : 'pending',
        createdAt: new Date(Date.now() - rand(0, 30) * 86400000),
      },
    })
  }

  // Support tickets
  await db.supportTicket.deleteMany()
  const ticketSubjects = [
    'License key not received',
    'Refund request for order',
    'Cannot access my account',
    'Payment failed but money deducted',
    'Wrong product delivered',
    'Need invoice for tax',
    'Subscription not activated',
    'Game key invalid',
  ]
  for (let i = 0; i < 24; i++) {
    const cust = dbCustomers[rand(0, dbCustomers.length - 1)]
    await db.supportTicket.create({
      data: {
        subject: ticketSubjects[rand(0, ticketSubjects.length - 1)],
        customerName: cust.name,
        customerEmail: cust.email,
        category: ticketCats[rand(0, ticketCats.length - 1)],
        priority: priorities[rand(0, priorities.length - 1)],
        status: Math.random() > 0.5 ? 'open' : Math.random() > 0.5 ? 'pending' : Math.random() > 0.5 ? 'resolved' : 'closed',
        message: 'Hello, I need help with my recent purchase. Please assist.',
        createdAt: new Date(Date.now() - rand(0, 14) * 86400000),
      },
    })
  }

  // Admin users
  await db.adminUser.deleteMany()
  const adminNames = [
    ['Daniyal Sheikh', 'daniyal@playbeat.digital', 'Super Admin'],
    ['Sara Khan', 'sara@playbeat.digital', 'Admin'],
    ['Omar Ahmed', 'omar@playbeat.digital', 'Manager'],
    ['Hira Malik', 'hira@playbeat.digital', 'Support'],
    ['Bilal Raza', 'bilal@playbeat.digital', 'Content Editor'],
    ['Nida Javed', 'nida@playbeat.digital', 'Finance'],
    ['Usman Akram', 'usman@playbeat.digital', 'Marketing'],
  ]
  for (const [name, email, role] of adminNames) {
    await db.adminUser.create({
      data: {
        name, email, role,
        status: 'active',
        avatar: `https://i.pravatar.cc/150?u=${email}`,
        lastLogin: new Date(Date.now() - rand(0, 48) * 3600000),
        twoFA: Math.random() > 0.5,
      },
    })
  }

  // Campaigns
  await db.campaign.deleteMany()
  const campaignDefs = [
    { name: 'Black Friday Mega Sale', type: 'email', channel: 'Email', status: 'completed', audience: 'All Customers', sent: 12450, opened: 8230, clicked: 3120 },
    { name: 'Winter Game Bundle', type: 'email', channel: 'Email', status: 'active', audience: 'Gamers', sent: 5600, opened: 3400, clicked: 1450 },
    { name: 'Flash Deal SMS Blast', type: 'sms', channel: 'SMS', status: 'completed', audience: 'Pakistan', sent: 8900, opened: 7100, clicked: 2100 },
    { name: 'New AI Tools Launch', type: 'push', channel: 'Push', status: 'scheduled', audience: 'AI Tools Interest', sent: 0, opened: 0, clicked: 0 },
    { name: 'Christmas Gift Cards', type: 'email', channel: 'Email', status: 'draft', audience: 'All', sent: 0, opened: 0, clicked: 0 },
  ]
  for (const c of campaignDefs) {
    await db.campaign.create({ data: c })
  }

  // Notifications
  await db.notification.deleteMany()
  const notifs = [
    { title: 'New Order #PB10120', message: 'A new order worth $89.99 was placed.', type: 'success' },
    { title: 'Low Stock Alert', message: 'ChatGPT Plus 1 Month is running low on stock.', type: 'warning' },
    { title: 'Refund Requested', message: 'Order #PB10098 requested a refund.', type: 'warning' },
    { title: 'New Support Ticket', message: 'High priority ticket: License key not received.', type: 'info' },
    { title: 'Payment Failed', message: 'Payment for order #PB10045 failed via JazzCash.', type: 'error' },
    { title: 'New Review', message: 'A 5-star review was submitted for Elden Ring.', type: 'info' },
    { title: 'Campaign Completed', message: 'Black Friday Mega Sale email campaign finished.', type: 'success' },
  ]
  for (const n of notifs) {
    await db.notification.create({ data: { ...n, read: Math.random() > 0.5, createdAt: new Date(Date.now() - rand(0, 24) * 3600000) } })
  }

  // Audit logs
  await db.auditLog.deleteMany()
  const auditActions = [
    { action: 'login', module: 'Auth', user: 'Daniyal Sheikh', details: 'Logged in from 103.45.12.8' },
    { action: 'product.create', module: 'Products', user: 'Sara Khan', details: 'Created product: ChatGPT Plus 1 Month' },
    { action: 'order.update', module: 'Orders', user: 'Omar Ahmed', details: 'Updated order PB10098 status to completed' },
    { action: 'customer.block', module: 'Customers', user: 'Daniyal Sheikh', details: 'Blocked customer fake.user@example.com' },
    { action: 'coupon.create', module: 'Marketing', user: 'Usman Akram', details: 'Created coupon WELCOME10' },
    { action: 'settings.update', module: 'Settings', user: 'Daniyal Sheikh', details: 'Updated SMTP settings' },
    { action: 'payment.refund', module: 'Payments', user: 'Nida Javed', details: 'Refunded $34.99 for order PB10045' },
    { action: 'role.update', module: 'Users', user: 'Daniyal Sheikh', details: 'Updated role permissions for Support' },
  ]
  for (let i = 0; i < 30; i++) {
    const a = auditActions[rand(0, auditActions.length - 1)]
    await db.auditLog.create({
      data: { ...a, ip: '103.' + rand(0, 255) + '.' + rand(0, 255) + '.' + rand(1, 254), createdAt: new Date(Date.now() - rand(0, 120) * 3600000) },
    })
  }

  // Activities
  await db.activity.deleteMany()
  const actDefs = [
    { type: 'order', description: 'New order #PB10120 received', user: 'System' },
    { type: 'product', description: 'Restocked Elden Ring (PC)', user: 'Sara Khan' },
    { type: 'customer', description: 'New customer registered: hina.khan@example.com', user: 'System' },
    { type: 'payment', description: 'Payment of $89.99 received via Stripe', user: 'System' },
    { type: 'review', description: 'New 5-star review on Cyberpunk 2077', user: 'System' },
    { type: 'ticket', description: 'Support ticket resolved', user: 'Hira Malik' },
  ]
  for (let i = 0; i < 18; i++) {
    const a = actDefs[rand(0, actDefs.length - 1)]
    await db.activity.create({ data: { ...a, createdAt: new Date(Date.now() - i * 3600000) } })
  }

  // Settings
  await db.setting.deleteMany()
  const settings: Record<string, string> = {
    'general.siteName': 'Playbeat.Digital',
    'general.tagline': 'Premium Digital Marketplace',
    'general.supportEmail': 'support@playbeat.digital',
    'general.timezone': 'Asia/Karachi',
    'general.currency': 'PKR',
    'general.region': 'Pakistan',
    'general.language': 'English',
    'general.maintenance': 'false',
    'theme.primary': '#ef4444',
    'theme.mode': 'light',
    'payment.stripe': 'true',
    'payment.paypal': 'true',
    'payment.jazzcash': 'true',
    'payment.easypaisa': 'true',
    'payment.bank': 'true',
    'payment.manual': 'true',
    'security.2fa': 'true',
    'security.rateLimit': 'true',
    'security.ipWhitelist': 'false',
    'smtp.host': 'smtp.gmail.com',
    'smtp.port': '587',
    'smtp.user': 'noreply@playbeat.digital',
  }
  for (const [k, v] of Object.entries(settings)) {
    await db.setting.create({ data: { id: k, value: v } })
  }

  console.log('✅ Seed complete!')
  console.log(`   Products: ${await db.product.count()}`)
  console.log(`   Orders: ${await db.order.count()}`)
  console.log(`   Customers: ${await db.customer.count()}`)
  console.log(`   Payments: ${await db.payment.count()}`)
  console.log(`   License Keys: ${await db.licenseKey.count()}`)
  console.log(`   Coupons: ${await db.coupon.count()}`)
  console.log(`   Reviews: ${await db.review.count()}`)
  console.log(`   Tickets: ${await db.supportTicket.count()}`)
  console.log(`   Admin Users: ${await db.adminUser.count()}`)
  console.log(`   Campaigns: ${await db.campaign.count()}`)
}

main()
  .catch((e) => {
    console.error(e)
    process.exit(1)
  })
  .finally(async () => {
    await db.$disconnect()
  })
