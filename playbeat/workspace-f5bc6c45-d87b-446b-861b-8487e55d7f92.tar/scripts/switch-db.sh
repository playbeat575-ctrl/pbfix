#!/bin/bash
# Switch Prisma provider between SQLite (local dev) and PostgreSQL (Vercel/production).
# Usage: bun scripts/switch-db.sh dev   → use SQLite
#        bun scripts/switch-db.sh prod  → use PostgreSQL (for Vercel deploy)

set -e
cd "$(dirname "$0")/.."

MODE="${1:-dev}"

if [ "$MODE" = "prod" ]; then
  echo "🔄 Switching Prisma to PostgreSQL (production mode)..."
  cp prisma/schema.prod.prisma prisma/schema.prisma
  echo "✅ schema.prisma now uses provider = \"postgresql\""
  echo ""
  echo "Next steps:"
  echo "  1. Set DATABASE_URL to your Neon/Supabase connection string in .env (and on Vercel)"
  echo "  2. Run: bun run db:push   # create tables in Postgres"
  echo "  3. Run: bun run db:seed   # load demo data"
  echo "  4. git push → Vercel auto-deploys"
elif [ "$MODE" = "dev" ]; then
  echo "🔄 Switching Prisma back to SQLite (local dev mode)..."
  if grep -q 'provider = "postgresql"' prisma/schema.prisma; then
    sed -i 's/provider = "postgresql"/provider = "sqlite"/' prisma/schema.prisma
    sed -i '1s|.*/ PostgreSQL, for Vercel/production)|// Playbeat.Digital Admin Panel — Prisma schema (SQLite)|' prisma/schema.prisma
  fi
  echo "✅ schema.prisma now uses provider = \"sqlite\""
else
  echo "Usage: bun scripts/switch-db.sh [dev|prod]"
  exit 1
fi
