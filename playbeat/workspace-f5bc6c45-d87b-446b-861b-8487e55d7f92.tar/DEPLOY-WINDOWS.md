# 🪟 Windows Deployment Guide — Playbeat.Digital → Vercel

This guide fixes the errors you hit (`bun not recognized`, `git not recognized`, `access denied`) and gives you the **simplest possible path** to go live. You do **NOT** need to install bun, run database commands, or even use the command line locally — everything happens in the cloud during the Vercel build.

---

## ❌ Why your commands failed

| Error | Reason | Fix |
|-------|--------|-----|
| `bun not recognized` | Bun isn't installed on Windows (and you don't need it!) | Skip local commands entirely — see below |
| `git not recognized` | Git isn't installed | Install Git for Windows (one installer) — OR use GitHub Desktop (no command line) |
| `Access to the path ... .env is denied` | You were in `C:\Program Files (x86)\...` — a protected system folder | Never run commands there. Use a normal folder like `C:\Users\YourName\Documents\playbeat` |

**Key insight:** You were in the wrong folder AND trying to run tools that aren't installed. The new approach below eliminates almost all local commands.

---

## ✅ The easy path (minimal local tools)

The project is now configured so that **Vercel automatically**:
1. Switches the database to PostgreSQL during build
2. Creates all 15 tables in your database
3. Seeds 38 products, 120 orders, 48 customers, etc.

You just need to: get the code onto GitHub → connect Vercel → add your database URL. That's it.

### What you DO need to install (just one thing)

**GitHub Desktop** — a free GUI app (no command line):
→ Download from **[desktop.github.com](https://desktop.github.com)** and install.

That's the only install. No bun, no Node.js, no command-line git.

---

## 📋 Step-by-step

### Step 1 — Get the project files onto your computer

1. **Download the project as a ZIP** from this sandbox (use the download/export button in your sandbox UI). You'll get a file like `my-project.zip`.
2. On your computer, create a folder: `C:\Users\YourName\Documents\playbeat`
3. Extract the ZIP contents into that folder. You should see `package.json`, `src/`, `prisma/`, etc. inside it.

### Step 2 — Create a free GitHub account (if you don't have one)

Go to **[github.com/signup](https://github.com/signup)** — 30 seconds, free.

### Step 3 — Push the code to GitHub using GitHub Desktop

1. Open **GitHub Desktop** → sign in with your GitHub account
2. Click **"Add" → "Add local repository"**
3. Choose the folder `C:\Users\YourName\Documents\playbeat`
4. GitHub Desktop says "This directory does not appear to be a Git repository" → click **"create a repository here"**
5. Name it `playbeat-admin` → click **"Create repository"**
6. Click **"Publish repository"** → leave it Public (or Private, your choice) → **Publish**

Your code is now on GitHub at `https://github.com/YOUR_USERNAME/playbeat-admin`.

### Step 4 — Create a free PostgreSQL database on Neon

1. Go to **[neon.tech](https://neon.tech)** → **Sign up** (use the "Sign up with GitHub" button)
2. Click **"Create New Project"**
   - Name: `playbeat`
   - Region: **Singapore** (closest to Pakistan) or your nearest
3. On the dashboard, find the **"Connection string"** box — it looks like:
   ```
   postgresql://playbeat_owner:npg_abc123XYZ@ep-cool-name-12345-pooler.ap-southeast-1.aws.neon.tech/playbeat?sslmode=require
   ```
4. **Copy this entire string** — you'll paste it into Vercel in the next step. Keep this tab open.

### Step 5 — Deploy on Vercel

1. Go to **[vercel.com/signup](https://vercel.com/signup)** → **"Continue with GitHub"**
2. Click **"Add New..." → "Project"**
3. Find `playbeat-admin` in the repo list → click **"Import"**
4. Vercel auto-detects Next.js. **Don't click Deploy yet** — first set the database:
5. Expand the **"Environment Variables"** section and add:
   - **Key:** `DATABASE_URL`
   - **Value:** *(paste your Neon connection string from Step 4)*
   - Click **"Add"**
6. Now click **"Deploy"** ⚡

Vercel builds the project (~3 minutes). During the build it automatically:
- ✅ Switches Prisma to PostgreSQL
- ✅ Generates the Prisma client
- ✅ Creates all 15 tables in your Neon database (`prisma db push`)
- ✅ Seeds 38 products, 120 orders, 48 customers, etc. (`prisma db seed`)
- ✅ Builds the Next.js app

When it's done, you get a live URL like:
```
https://playbeat-admin-abc123.vercel.app
```

**Open it — your admin panel is LIVE on the internet!** 🎉 All data is there because the build auto-seeded it.

### Step 6 (optional) — Connect your custom domain

Want `https://playbeat.digital` instead of the `.vercel.app` URL?

1. In Vercel: **Project → Settings → Domains → Add** → type `playbeat.digital`
2. Vercel shows you DNS records to add. Go to wherever you bought the domain (Namecheap, GoDaddy, Cloudflare, etc.):
   - Add **A record**: `@` → `76.76.21.21`
   - Add **CNAME record**: `www` → `cname.vercel-dns.com`
3. Wait 10–30 minutes. Vercel auto-provisions a **free SSL certificate**. Done — `https://playbeat.digital` is live. 🔒

---

## 🎯 Summary — what you actually do

| Step | Action | Time |
|------|--------|------|
| 1 | Download project ZIP from sandbox, extract to `Documents\playbeat` | 2 min |
| 2 | Install GitHub Desktop, publish folder to GitHub | 5 min |
| 3 | Sign up at neon.tech, copy the connection string | 2 min |
| 4 | Sign up at vercel.com, import repo, paste DATABASE_URL, Deploy | 3 min |
| 5 | Open your live URL — it works! | 0 min |
| **Total** | | **~12 min** |

No command line. No bun. No Node.js. No database commands. The Vercel build handles everything.

---

## 🔄 After deploy — how to update your site

Whenever you want to change something:
1. Make changes in this sandbox
2. Download the updated files (or edit directly on GitHub)
3. If using GitHub Desktop: it detects changes → click **"Fetch origin"** → **"Push origin"**
4. Vercel **automatically rebuilds and redeploys** within 60 seconds

Every `git push` = instant update to your live site.

---

## 🆘 Troubleshooting

| Problem | Solution |
|---------|----------|
| **Vercel build fails: "Can't reach database server"** | Your `DATABASE_URL` is wrong or Neon project is paused. Go to neon.tech, make sure the project is active, re-copy the connection string, update it in Vercel → Settings → Environment Variables → Redeploy. |
| **Build succeeds but the site shows "No products"** | The auto-seed was skipped (maybe the DB already had partial data). Go to neon.tech → SQL Editor → run `DELETE FROM "Product";` → then in Vercel click "Redeploy". The build will re-seed. |
| **"Error: Prisma schema validation failed"** | The schema swap didn't happen. Make sure `prisma/schema.prod.prisma` exists in your repo (it's included). Check the Vercel build logs — the first line should be the `cp` command. |
| **GitHub Desktop says "repository too large"** | Make sure `node_modules` is NOT in your folder. The `.gitignore` file excludes it, but if you extracted the ZIP and it included node_modules, delete that folder before publishing. |
| **Custom domain shows "not secured"** | Wait longer — SSL provisioning takes up to 30 min. If still broken after 1 hour, remove and re-add the domain in Vercel. |

---

## 📞 Need help?

If you get stuck, copy the error message and I'll help you fix it. The most common issue is the `DATABASE_URL` — make sure you copied the **entire** connection string from Neon (it's long and includes `?sslmode=require` at the end).
